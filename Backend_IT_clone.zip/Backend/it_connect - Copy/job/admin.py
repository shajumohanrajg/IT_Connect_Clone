from django.contrib import admin

# Register your models here.
# from
from .models import *

admin.site.register(jobfor)
admin.site.register(job)
admin.site.register(jobtype)