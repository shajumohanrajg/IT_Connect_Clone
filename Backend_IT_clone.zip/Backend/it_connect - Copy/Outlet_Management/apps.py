from django.apps import AppConfig


class OutletManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Outlet_Management'
