import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { Card } from '@mui/material';
import { Button, IconButton, useMediaQuery } from '@mui/material';
//import { useNavigate } from 'react-router-dom';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { GridToolbar } from '@mui/x-data-grid';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import withAuth from '../pages/authentication/authentication3/withAuth';
import useStyles from '../styles/styles';
import ApiComponent from '../apicomp/ApiComponent';
import { JobListapi, Jobapi } from '../apicomp/Apiurls';
import style from '../styles/Boxstyle';
import CustomDataGrid from '../customdatagrid/CustomDataGrid';

function DataTable() {
    //const navigate = useNavigate();
    const columns1 = [
        {
            field: 'jobfor',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'Job For',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header',
            //flex: 0.2
            width: 150
            // cellClassName: "name-column--cell",
        },
        {
            field: 'jobtype',
            headerName: 'Job Type',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'designtype',
            headerName: 'Design Type',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'showroom',
            headerName: 'Showroom',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'assigned_to',
            headerName: 'Assign To',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'priority',
            headerName: 'Priority',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'status',
            headerName: 'Status',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'dead_Line',
            headerName: 'Dead Line',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            headerName: 'Actions',
            field: 'action',
            //flex: 1,
            width: 150,
            headerClassName: 'super-app-theme--header',
            renderCell: (params) => (
                <div>
                    <IconButton aria-label="Update" size="large" onClick={() => viewShowrooms(params.id)}>
                        <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton aria-label="delete" size="large" onClick={() => handleDeleteSubmit(params.id)}>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </div>
            )
        }
    ];

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${Jobapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Job Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                //setLoading(false);
                // console.log("deleted",res)
                //enqueueSnackbar('Successfully deleted' , { variant:'success', anchorOrigin:{horizontal: 'right', vertical: 'top'} } );
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/jobassignupdate/${id}`);
        window.location.reload();
    };

    const [matData, setMatData] = React.useState([
        {
            name: '',
            status: null,
            created_by: 1,
            modified_by: 1
        }
    ]);

    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${Jobapi}${id}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                setMatData(data);
                setOpenModal(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [name, setName] = useState('');
    const [status, setStatus] = useState(matData.status);
    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    //const [loading, setLoading] = React.useState(false);
    const [floordiadata, setFloordiadata] = React.useState([]);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setFloordiadata(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setFloordiadata([]);
        };
    }, []);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://127.0.0.1:1212/api/v1/job/job_list/', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setFloordiadata(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', boxShadow: 0 }}>
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}

            <ApiComponent apiUrl={JobListapi} onDataFetched={setFloordiadata} />
            <CustomDataGrid
                isSmallScreen={true}
                rows={floordiadata}
                columns={columns1}
                // Add any additional props you want to pass
                //autoHeight={true}
                //checkboxSelection={true}
                //pageSize={10}
                // ...and other available props
                getRowId={(row) => row.id}
                components={{ Toolbar: GridToolbar, color: 'primary' }}
                componentsProps={{
                    toolbar: {
                        showQuickFilter: true,
                        quickFilterProps: { debounceMs: 500 },
                        color: 'primary'
                    }
                }}
                loading={loading}
                //autoHeight
                //scrollbarSize={100}
                //pageSize={5}
                //checkboxSelection
                //touchRipple
                //disableColumnMenu
                // onRowClick={handleRowClick}
                disableColumnFilter={isSmallScreen ? true : false}
                disableDensitySelector={isSmallScreen ? true : false}
                virtualization
            />

            <Dialog
                open={openDialogdelete}
                onClose={handleCloseDialogdelete}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are you sure want to delete this id #{selectedRowIddel}? </DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure want to Delete this brand id #{selectedRowIddel}?
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialogdelete}>No</Button>
                    <Button onClick={deleteBrand}>Submit</Button>
                </DialogActions>
            </Dialog>
        </Card>
    );
}

export default withAuth(DataTable);
