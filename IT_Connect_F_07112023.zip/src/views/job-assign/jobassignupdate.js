// project imports
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import { Button, Card, FormControl, Grid, InputLabel, MenuItem, Select, Stack, TextField, Typography } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
//import AdapterDateFns from '@mui/lab/AdapterDateFns';

import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import Axios from 'axios';
// import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
// import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';

// import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
// import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import dayjs from 'dayjs';
import utcPlugin from 'dayjs/plugin/utc';
import React, { useEffect, useState } from 'react';
//import Table from './360floordiatable';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import BackButton from 'BackButton';

import ApiComponent from '../apicomp/ApiComponent';
import { Brandapi, DesignTypeapi, Jobapi, JobForapi, JobTypeapi, Showroomapi, Usersapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';

dayjs.extend(utcPlugin);

// import { LocalizationProvider, AdapterDateFns, DateTimePicker } from '@mui/lab';

const selectStyles = {
    backgroundColor: 'white',
    color: 'black'
};
const customStyles = {
    borderRadius: 50,
    animationDuration: '10ms',
    '& .MuiOutlinedInput-root': {
        '& fieldset': {
            borderRadius: 8,
            color: 'white'
        },
        '&:hover fieldset': {
            borderColor: '#999'
        },
        '&.Mui-focused fieldset': {
            borderColor: '#1a5f7a'
        }
    }
};

const SamplePage = () => {
    let { id } = useParams();
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [name, setName] = useState('');
    const [rsm, setRsm] = useState('');
    const [asm, setAsm] = useState('');
    const [manager, setManager] = useState('');
    const [cugNo, setCugNo] = useState('');
    const [landline, setLandline] = useState('');
    const [email, setEmail] = useState('');
    const [region, setRegion] = useState('');
    const [state, setState] = useState('');
    const [address, setAddress] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const [matData, setMatData] = React.useState([
        {
            assigned_to: '',
            comment: '',
            dead_Line: null,
            designtype: '',
            jobfor: '',
            jobtype: '',
            priority: '',
            showroom: '',
            status: '',

            created_by: 1,
            modified_by: 1
        }
    ]);

    const [jobfor1, setJobfor] = useState([]);
    const [jobforvalue, setJobforvalue] = useState('');
    const [jobtype1, setJobtype] = useState([]);
    const [jobtypevalue, setJobtypevalue] = useState('');
    const [designtype1, setDesigntype] = useState([]);
    const [designtypevalue, setDesigntypevalue] = useState('');
    const [showroomnames, setShowroomnames] = useState([]);
    const [showroomvalue, setShowroomvalue] = useState('');
    const [comment, setComment] = useState('');
    const [priority, setPriority] = useState('');
    const [priorityvalue, setPriorityvalue] = useState('');
    const [assignto, setAssignto] = useState([]);
    const [assigntovalue, setAssigntovalue] = useState('');

    const [selectedDate, setSelectedDate] = useState(null);

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/job/jobfor', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setJobfor(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setShowroomnames(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/job/jobtype', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setJobtype(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/job/designtype', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setDesigntype(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://127.0.0.1:1212/api/v1/users/', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setAssignto(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setJobfor(data);
            setJobtype(data);
            setDesigntype(data);
            setShowroomnames(data);
            setAssignto(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setJobfor([]);
            setJobtype([]);
            setDesigntype([]);
            setShowroomnames([]);
            setAssignto([]);
        };
    }, []);
    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/jobassignupdate/${id}`);
        window.location.reload();
    };
    const url = Jobapi;
    useEffect(() => {
        const token = localStorage.getItem('token');
        // const id=props.match.params.id
        Axios.get(url + id, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((res) => {
                // console.log(res.data)
                setMatData(res.data);
            })
            .catch((err) => console.error(err));
    }, [id]);

    const deadline = matData.dead_Line;

    const formattedDeadline = new Date(deadline).toLocaleString([], { dateStyle: 'short', timeStyle: 'short', hour12: true });

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');

        const updatedFormData = {
            assigned_to: matData.assigned_to,
            comment: matData.comment,
            designtype: matData.designtype,
            jobfor: matData.jobfor,
            jobtype: matData.jobtype,
            priority: matData.priority,
            showroom: matData.showroom,
            status: matData.status,
            created_by: 1,
            modified_by: 1,
            dead_Line: selectedDate ? selectedDate.toISOString() : matData.dead_Line
        };

        try {
            const response = await Axios.put(`${Jobapi}${id}/`, updatedFormData, {
                headers: {
                    Authorization: `Token ${token}`
                }
            });
            console.log(response.data);
            setResponseMessage('SuccesssFully Job Updated');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            //console.log(response);
        } catch (error) {
            console.error(error);
        }
    };

    // const handleSubmit = async (e) => {
    //     e.preventDefault();
    //     const token = localStorage.getItem('token');
    //     const formData = new FormData();

    //     // Append other form data fields to the formData object

    //     formData.append('assigned_to', matData.assigned_to);
    //     formData.append('comment', matData.comment);
    //     formData.append('designtype', matData.designtype);
    //     formData.append('jobfor', matData.jobfor);
    //     formData.append('jobtype', matData.jobtype);
    //     formData.append('priority', matData.priority);
    //     formData.append('showroom', matData.showroom);
    //     formData.append('status', matData.status);

    //     formData.append('created_by', 1);
    //     formData.append('modified_by', 1);

    //     if (selectedDate) {
    //         // Both assetImage and document exist
    //         formData.append('dead_Line', selectedDate);

    //         Axios.put(`http://localhost:1212/api/v1/job/job/${id}/`, formData, {
    //             headers: {
    //                 //'Content-Type': 'multipart/form-data',
    //                 Authorization: `Token ${token}`
    //             }
    //         })
    //             .then((response) => {
    //                 // Handle the response
    //                 console.log(response.data);
    //                 //setIsLoading(false);
    //             })
    //             .catch((error) => {
    //                 // Handle the error
    //                 console.error(error);
    //                 //setIsLoading(false);
    //             });
    //     } else {
    //         Axios.put(`http://localhost:1212/api/v1/job/job/${id}/`, formData, {
    //             headers: {
    //                 //'Content-Type': 'multipart/form-data',
    //                 Authorization: `Token ${token}`
    //             }
    //         })
    //             .then((response) => {
    //                 // Handle the response
    //                 console.log(response.data);
    //                 //setIsLoading(false);
    //             })
    //             .catch((error) => {
    //                 // Handle the error
    //                 console.error(error);
    //                 //setIsLoading(false);
    //             });
    //     }
    // };

    // const handleSubmit = (e) => {
    //     const token = localStorage.getItem('token');
    //     e.preventDefault();

    //     Axios.put(`http://localhost:1212/api/v1/job/job/${id}/`, matData, {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     })
    //         .then((response) => {
    //             console.log('Data updated successfully:', response.data);

    //             // Perform any necessary actions after successful data update
    //         })
    //         .catch((error) => {
    //             console.log('Error updating data:', error);
    //             // Handle any errors that occur during the update process
    //         });
    // };

    // const handleSubmit = (e) => {
    //     const token = localStorage.getItem('token');
    //     e.preventDefault();
    //     Axios.put(
    //         'http://localhost:1212/api/v1/OMM2/showroom_mgmt/',
    //         {
    //             // id: id,
    //             name: name,
    //             rsm: rsm,
    //             asm: asm,
    //             manager: manager,
    //             cug_no: cugNo,
    //             landline: landline,
    //             e_mail: email,
    //             region: region,
    //             state: state,
    //             address: address,
    //             created_by: 1,
    //             modified_by: 1
    //         },
    //         {
    //             headers: {
    //                 Authorization: `Token ${token}` // Include the token in the request headers
    //             }
    //         }
    //     ).then(
    //         (response) => {
    //             // enqueueSnackbar('Data Entry Successful', {
    //             //     variant: 'success',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(response);
    //             // history.push('/dashboard/bomat_table2');
    //             // setTimeout(() => {
    //             //     window.location.reload();
    //             // }, 1000);
    //         },
    //         (error) => {
    //             // enqueueSnackbar('Check Data and Try Again', {
    //             //     variant: 'Error',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(error);
    //         }
    //     );
    // };
    return (
        <div>
            <ApiComponent apiUrl={Usersapi} onDataFetched={setAssignto} />
            <ApiComponent apiUrl={JobForapi} onDataFetched={setJobfor} />
            <ApiComponent apiUrl={JobTypeapi} onDataFetched={setJobtype} />
            <ApiComponent apiUrl={DesignTypeapi} onDataFetched={setDesigntype} />
            <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Job Assign
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <BackButton />
                    {/* <Button
                className={classes.Button}
                variant="contained"
                //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                //onClick={handleOpen}
                href="/hoardingform"
                startIcon={<AddCircleOutlinedIcon />}
            >
                Hoarding
            </Button> */}
                </Stack>
            </Card>
            <br></br>
            <Card sx={{ width: '100%', boxShadow: 0, p: 3 }}>
                {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/outletadform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Asset
                    </Button>
                </Stack> */}
                {/* <List sx={{ width: '100%', maxWidth: 360 }}>
                    <ListItem>
                        <ListItemAvatar>
                            <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                <AddAPhotoOutlinedIcon />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText>
                            <Typography variant="h3">Create Job assign</Typography>
                        </ListItemText>
                    </ListItem>
                </List> */}
                <Grid container spacing={3} justifyContent="center" alignItems="center">
                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="jobfor-select-label">
                                Job For
                            </InputLabel>
                            <Select
                                labelId="jobfor-select-label"
                                id="jobfor"
                                name="jobfor"
                                value={matData.jobfor || ''}
                                onChange={(e) => setMatData({ ...matData, jobfor: e.target.value })}
                                // value={jobforvalue}
                                // onChange={(e) => setJobforvalue(e.target.value)}
                                label="Job For"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select Job For</em>
                                </MenuItem>
                                {jobfor1 && jobfor1 !== undefined
                                    ? jobfor1.map((option, index) => (
                                          <MenuItem key={index} value={option.id}>
                                              {option.name}
                                          </MenuItem>
                                      ))
                                    : 'No Data'}
                                {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="jobtype-select-label">
                                Job Type
                            </InputLabel>
                            <Select
                                labelId="jobtype-select-label"
                                id="jobtype"
                                name="jobtype"
                                value={matData.jobtype || ''}
                                onChange={(e) => setMatData({ ...matData, jobtype: e.target.value })}
                                // value={jobtypevalue}
                                // onChange={(e) => setJobtypevalue(e.target.value)}
                                label="Job Type"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select Job For</em>
                                </MenuItem>
                                {jobtype1 && jobtype1 !== undefined
                                    ? jobtype1.map((option, index) => (
                                          <MenuItem key={index} value={option.id}>
                                              {option.name}
                                          </MenuItem>
                                      ))
                                    : 'No Data'}
                                {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="designtype-select-label">
                                Design Type
                            </InputLabel>
                            <Select
                                labelId="designtype-select-label"
                                id="designtype"
                                name="designtype"
                                value={matData.designtype || ''}
                                onChange={(e) => setMatData({ ...matData, designtype: e.target.value })}
                                // value={designtypevalue}
                                // onChange={(e) => setDesigntypevalue(e.target.value)}
                                label="Design Type"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select Design Type</em>
                                </MenuItem>
                                {designtype1 && designtype1 !== undefined
                                    ? designtype1.map((option, index) => (
                                          <MenuItem key={index} value={option.id}>
                                              {option.name}
                                          </MenuItem>
                                      ))
                                    : 'No Data'}
                                {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="location-select-label">
                                Showroom Location
                            </InputLabel>
                            <Select
                                labelId="location-select-label"
                                id="showroom"
                                name="showroom"
                                value={matData.showroom || ''}
                                onChange={(e) => setMatData({ ...matData, showroom: e.target.value })}
                                // value={showroomvalue}
                                // onChange={(e) => setShowroomvalue(e.target.value)}
                                label="Showroom Location"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select a location</em>
                                </MenuItem>
                                {showroomnames && showroomnames !== undefined
                                    ? showroomnames.map((option, index) => (
                                          <MenuItem key={index} value={option.id}>
                                              {option.name}
                                          </MenuItem>
                                      ))
                                    : 'No Data'}
                            </Select>
                        </FormControl>
                    </Grid>

                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="priority-select-label">
                                Priority
                            </InputLabel>
                            <Select
                                labelId="priority-select-label"
                                id="priority"
                                value={matData.priority || ''}
                                onChange={(e) => setMatData({ ...matData, priority: e.target.value })}
                                // value={priority}
                                // onChange={(e) => setPriority(e.target.value)}
                                label="Priority"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select a Priority</em>
                                </MenuItem>
                                <MenuItem value="Medium">Medium</MenuItem>
                                <MenuItem value="TOP">Top</MenuItem>
                                <MenuItem value="Urgent">Urgent</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>

                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="assignto-select-label">
                                Assign To
                            </InputLabel>
                            <Select
                                labelId="assignto-select-label"
                                id="assigned_to"
                                name="assigned_to"
                                value={matData.assigned_to || ''}
                                onChange={(e) => setMatData({ ...matData, assigned_to: e.target.value })}
                                // value={assigntovalue}
                                // onChange={(e) => setAssigntovalue(e.target.value)}
                                label="Assign To"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select a User</em>
                                </MenuItem>
                                {assignto && assignto !== undefined
                                    ? assignto.map((option, index) => (
                                          <MenuItem key={index} value={option.id}>
                                              {option.username}
                                          </MenuItem>
                                      ))
                                    : 'No Data'}
                            </Select>
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="status-select-label">
                                Status
                            </InputLabel>
                            <Select
                                labelId="status-select-label"
                                id="status-select"
                                value={matData.status || ''}
                                onChange={(e) => setMatData({ ...matData, status: e.target.value })}
                                // value={status}
                                // onChange={(e) => setStatus(e.target.value)}
                                label="Status"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select a Status</em>
                                </MenuItem>
                                <MenuItem value="Pending">Pending</MenuItem>
                                <MenuItem value="Follow Up">Follow Up</MenuItem>
                                <MenuItem value="Completed">Completed</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                    {/* <Grid item xs={12} md={6} xl={6}>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DemoItem label="Expiry On" fullWidth>
                                <MobileDateTimePicker
                                    defaultValue={dayjs(matData.dead_Line, matData.dead_Line)}
                                    onChange={(e) => setMatData({ ...matData, dead_Line: e.target.value })}
                                    fullWidth
                                />
                            </DemoItem>
                        </LocalizationProvider>
                    </Grid> */}
                    {/* <Grid item xs={12} md={6} xl={6}>
                        <LocalizationProvider dateAdapter={AdapterDateFns} className={classes.select}>
                            <DateTimePicker
                                className={classes.label}
                                renderInput={(props) => <TextField {...props} fullWidth />}
                                label="Date and Time"
                                // value={selectedDate}
                                value={selectedDate ? format(selectedDate, "yyyy-MM-dd'T'HH:mm:ss") : null}
                                //value={selectedDate ? selectedDate.toISOString() : null}
                                onChange={handleDateChange}
                                fullWidth
                                //inputFormat="YYYY-MM-DDThh:mm[:ss[.uuuuuu]][+HH:MM|-HH:MM|Z]"
                            />
                        </LocalizationProvider>
                    </Grid> */}
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Comments"
                            id="comment"
                            // value={comment}
                            // onChange={(e) => setComment(e.target.value)}
                            value={matData.comment || ''}
                            onChange={(e) => setMatData({ ...matData, comment: e.target.value })}
                            fullWidth
                            //type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                shrink: 'true',
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    {/* <Grid item xs={12} md={6} xl={6}>
                        <Typography variant="h5">Dead Line is : {formattedDeadline}</Typography>
                    </Grid> */}
                    <Grid item xs={12} md={6} xl={6}>
                        <Typography variant="h5">Dead Line is : {formattedDeadline}</Typography>
                        <br></br>
                        <LocalizationProvider dateAdapter={AdapterDateFns} className={classes.select}>
                            <DateTimePicker
                                className={classes.label}
                                renderInput={(props) => <TextField {...props} fullWidth />}
                                label="Dead Line"
                                //defaultValue={matData.dead_Line}
                                //value={selectedDate instanceof Date ? selectedDate : null}
                                value={selectedDate ? selectedDate : null}
                                onChange={handleDateChange}
                                fullWidth
                                focused
                            />
                        </LocalizationProvider>
                    </Grid>

                    {/* <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DateTimePicker label="Basic date time picker" value={selectedDate} onChange={handleDateChange} />
                    </LocalizationProvider> */}

                    {/* <input type="datetime-local" id="datetime" value={selectedDate} onChange={handleDateChange} /> */}
                    {/* <Grid item xs={12} md={6} xl={6}>
                        <LocalizationProvider dateAdapter={AdapterDayjs} fullWidth className={classes.select}>
                            <DateTimePicker
                                className={classes.label}
                                renderInput={(props) => <TextField {...props} fullWidth />}
                                label="Date and Time"
                                // value={selectedDate}
                                // onChange={handleDateChange}
                                //value={matData.dead_Line || ''}
                                onChange={(e) => setMatData({ ...matData, dead_Line: e.target.value })}
                                fullWidth
                            />
                        </LocalizationProvider>
                    </Grid> */}

                    {/* <Grid item xs={12} md={6} xl={6}>
                        <LocalizationProvider dateAdapter={AdapterDateFns} className={classes.select}>
                            <DateTimePicker
                                className={classes.label}
                                renderInput={(props) => <TextField {...props} fullWidth />}
                                label="Date and Time"
                                value={selectedDate}
                                onChange={handleDateChange}
                                fullWidth
                            />
                        </LocalizationProvider>
                    </Grid> */}
                    {/* <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DateTimePicker
                        renderInput={(props) => <TextField {...props} fullWidth />}
                        label="Date and Time"
                        //value={matData.dead_Line || null}
                        onChange={handleDateChange}
                        //onChange={(e) => setMatData({ ...matData, dead_Line: e.target.value })}
                        fullWidth
                    />
                </LocalizationProvider> */}
                    {/* <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <DateTimePicker
                                        renderInput={(props) => <TextField {...props} fullWidth />}
                                        label="Date and Time"
                                        //value={matData.dead_Line || null}
                                        onChange={handleDateChange}
                                        inputFormat="yyyy-MM-dd'T'HH:mm:ss"
                                        parseInput={parseISO}
                                        fullWidth
                                    />
                                </LocalizationProvider> */}
                    {/* <DateTimePicker
                                    renderInput={(props) => <TextField {...props} />}
                                    label="Select Date and Time"
                                    value={matData.dead_Line || null}
                                    onChange={handleDateChange}
                                /> */}

                    <Grid item xs={12} md={6} xl={6} sx={{ mt: 3 }}>
                        <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                            {' '}
                            <Button
                                className={classes.Button}
                                variant="contained"
                                onClick={handleSubmit}
                                //startIcon={<FileUploadOutlinedIcon />}
                            >
                                Update
                            </Button>
                        </Stack>
                    </Grid>
                </Grid>
            </Card>{' '}
        </div>
    );
};

export default withAuth(SamplePage);
