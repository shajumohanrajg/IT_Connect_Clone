// project imports
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import { Box, Button, Card, Grid, Stack, TextField, Typography } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import BackButton from 'BackButton';

import { Brandapi, Showroomapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';

const selectStyles = {
    backgroundColor: 'white',
    color: 'black'
};
const customStyles = {
    borderRadius: 50,
    animationDuration: '10ms',
    '& .MuiOutlinedInput-root': {
        '& fieldset': {
            borderRadius: 8,
            color: 'white'
        },
        '&:hover fieldset': {
            borderColor: '#999'
        },
        '&.Mui-focused fieldset': {
            borderColor: '#1a5f7a'
        }
    }
};

const SamplePage = () => {
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [name, setName] = useState('');
    const [rsm, setRsm] = useState('');
    const [asm, setAsm] = useState('');
    const [manager, setManager] = useState('');
    const [cugNo, setCugNo] = useState('');
    const [landline, setLandline] = useState('');
    const [email, setEmail] = useState('');
    const [region, setRegion] = useState('');
    const [state, setState] = useState('');
    const [address, setAddress] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();
        Axios.post(
            Showroomapi,
            {
                // id: id,
                name: name,
                rsm: rsm,
                asm: asm,
                manager: manager,
                cug_no: cugNo,
                landline: landline,
                e_mail: email,
                region: region,
                state: state,
                address: address,
                created_by: 1,
                modified_by: 1
            },
            {
                headers: {
                    Authorization: `Token ${token}` // Include the token in the request headers
                }
            }
        ).then(
            (response) => {
                setResponseMessage('SuccesssFully Showrooms Created');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                console.log(response);
                // enqueueSnackbar('Data Entry Successful', {
                //     variant: 'success',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(response);
                // history.push('/dashboard/bomat_table2');
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            },
            (error) => {
                // enqueueSnackbar('Check Data and Try Again', {
                //     variant: 'Error',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(error);
            }
        );
    };
    return (
        <div>
            {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/outletadform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Asset
                    </Button>
                </Stack> */}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                {responseMessage &&
                    Swal.fire({
                        title: 'success',
                        text: responseMessage,
                        icon: 'success',
                        confirmButtonText: 'OK'
                        //onClose: handleClose
                    })}
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Showrooms
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <BackButton />
                    {/* <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/hoardingform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Hoarding
                    </Button> */}
                </Stack>
            </Card>
            <br></br>
            <Card sx={{ width: '100%', boxShadow: 0, p: 5 }}>
                <Box>
                    {/* <List sx={{ width: '100%', maxWidth: 360 }}>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                    <AddAPhotoOutlinedIcon />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                <Typography variant="h3">Add Showroom</Typography>
                            </ListItemText>
                        </ListItem>
                    </List> */}
                    <Grid container spacing={3} justifyContent="center" alignItems="center">
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Showroom Name"
                                id="name"
                                name="name"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Rsm"
                                id="rsm"
                                name="rsm"
                                value={rsm}
                                onChange={(e) => setRsm(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Asm"
                                id="asm"
                                name="asm"
                                value={asm}
                                onChange={(e) => setAsm(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Manager"
                                id="manager"
                                name="manager"
                                value={manager}
                                onChange={(e) => setManager(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="CUG No"
                                id="cug_no"
                                name="cug_no"
                                value={cugNo}
                                onChange={(e) => setCugNo(e.target.value)}
                                fullWidth
                                type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Landline"
                                id="landline"
                                name="landline"
                                value={landline}
                                onChange={(e) => setLandline(e.target.value)}
                                fullWidth
                                type="tel"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Email"
                                id="e_mail"
                                name="e_mail"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                fullWidth
                                type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Region"
                                id="region"
                                name="region"
                                value={region}
                                onChange={(e) => setRegion(e.target.value)}
                                fullWidth
                                //type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>

                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="State"
                                id="state"
                                name="state"
                                value={state}
                                onChange={(e) => setState(e.target.value)}
                                fullWidth
                                //type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={12}>
                            <TextField
                                //size="small"
                                label="Address"
                                id="address"
                                name="address"
                                value={address}
                                onChange={(e) => setAddress(e.target.value)}
                                fullWidth
                                multiline={4}
                                //type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                    onClick={handleSubmit}
                                    startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Add
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Card>
        </div>
    );
};

export default withAuth(SamplePage);
