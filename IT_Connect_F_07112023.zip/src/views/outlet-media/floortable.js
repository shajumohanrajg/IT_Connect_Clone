//import { OutlinedInput } from 'tabler-icons-react';
import { OutlinedInput } from '@material-ui/core';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import CloseIcon from '@mui/icons-material/Close';
//import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
// eslint-disable-next-line prettier/prettier
import { Box, Button, Card, FormControl, Grid, InputAdornment, InputLabel, MenuItem, Modal, Select, Stack, Typography } from '@mui/material';
import { IconButton, useMediaQuery } from '@mui/material';
import Avatar from '@mui/material/Avatar';
//import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
//import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import ApiComponent from '../apicomp/ApiComponent';
import { Floorapi, Floorlistapi, Showroomapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';

//import { useNavigate } from 'react-router-dom';

function DataTable() {
    const navigate = useNavigate();
    const columns1 = [
        {
            field: 'name',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'Name',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header',
            //flex: 0.2
            width: 200
            // cellClassName: "name-column--cell",
        },
        {
            field: 'floor_image',
            headerName: 'Floor Image',
            width: 100,
            renderCell: (params) => (
                // eslint-disable-next-line jsx-a11y/no-noninteractive-element-interactions
                <img
                    src={params.value}
                    alt="Row"
                    style={{ width: '100%', height: 'auto', cursor: 'pointer' }}
                    onClick={() => handleImageClick(params.value)}
                    onKeyDown={(e) => handleImageKeyDown(e, params.value)}
                    // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
                    tabIndex="0"
                />
            )
            // renderCell: (params) => (
            //     <IconButton
            //         onClick={() => handleImageClick(params.value)}
            //         onKeyDown={(e) => handleImageKeyDown(e, params.value)}
            //         role="button"
            //         tabIndex={0}
            //         style={{ padding: 0 }}
            //     >
            //         <ImageIcon />
            //     </IconButton>
            // )
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            renderCell: (params) => (
                // <Button variant="outlined" onClick={() => handleEditClick(params.id)}>
                //     Edit
                // </Button>
                <>
                    <IconButton aria-label="update" size="large" onClick={() => handleEditClick(params.id)}>
                        <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton aria-label="delete" size="large" onClick={() => handleDeleteSubmit(params.id)}>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </>
            )
        }
    ];

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${Floorapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Floor Diagram Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                //setLoading(false);

                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const [matData, setMatData] = React.useState([
        {
            name: '',
            floor_image: null,
            created_by: 1,
            modified_by: 1
        }
    ]);

    const [floorImage, setFloorImage] = useState(null);

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setFloorImage(file);
    };

    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${Floorapi}${id}/`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                setMatData(data);
                setOpenModal(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/floorupdate/${id}`);
        window.location.reload();
    };

    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };

    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    //const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    //const [loading, setLoading] = React.useState(false);

    const [showroomnames, setShowroomnames] = React.useState([]);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setShowroomnames(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    const [floordiadata, setFloordiadata] = React.useState([]);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setFloordiadata(data);
            setShowroomnames(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setFloordiadata([]);
            setShowroomnames([]);
        };
    }, []);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setFloordiadata(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    const urlToBlob = (url) => {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.responseType = 'blob';
            xhr.onload = () => {
                if (xhr.status === 200) {
                    resolve(xhr.response);
                } else {
                    reject(new Error('Failed to convert URL to Blob'));
                }
            };
            xhr.onerror = () => {
                reject(new Error('Failed to convert URL to Blob'));
            };
            xhr.send();
        });
    };

    const [openModel, setOpenModal] = React.useState(false);
    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();
        //const token = localStorage.getItem('token');
        const formData = new FormData();

        // Append other form data fields to the formData object

        formData.append('name', matData.name);
        //formData.append('floor_image', floorImage);
        formData.append('created_by', 1);
        formData.append('modified_by', 1);
        //console.log(matData.floor_image);
        // if (floorImage) {
        //     formData.append('floor_image', floorImage);
        // } else {
        //     // Convert the URL to a Blob and append it as a file
        //     const urlBlob = new Blob([matData.floor_image], { type: 'image/jpg' });
        //     formData.append('floor_image', urlBlob, 'floor_image.jpg');
        // }

        // if (floorImage) {
        //     formData.append('floor_image', floorImage);
        // } else {
        //     formData.append('floor_image', matData.floor_image);
        // }
        // if (floorImage) {
        //     formData.append('floor_image', floorImage);
        // } else {
        //     urlToBlob(matData.floor_image).then((blob) => {
        //         formData.append('floor_image', blob, 'floor_image.png');
        //     });
        // }

        // if (floorImage) {
        //     formData.append('floor_image', floorImage);
        //     Axios.put(`http://localhost:1212/api/v1/OMM2/floor_mgnt/${selectedRowId}/`, formData, {
        //         headers: {
        //             'Content-Type': 'multipart/form-data',
        //             Authorization: `Token ${token}`
        //         }
        //     })
        //         .then((response) => {
        //             // Handle the response
        //             console.log(response.data);
        //             //setIsLoading(false);
        //         })
        //         .catch((error) => {
        //             // Handle the error
        //             console.error(error);
        //             //setIsLoading(false);
        //         });
        // } else {
        //     urlToBlob(matData.floor_image)
        //         .then((blob) => {
        //             formData.append('floor_image', blob, 'floor_image.png');

        //             //setIsLoading(true);

        //             // Make the PUT request with the form data
        //             Axios.put(`http://localhost:1212/api/v1/OMM2/floor_mgnt/${selectedRowId}/`, formData, {
        //                 headers: {
        //                     'Content-Type': 'multipart/form-data',
        //                     Authorization: `Token ${token}`
        //                 }
        //             })
        //                 .then((response) => {
        //                     // Handle the response
        //                     console.log(response.data);
        //                     //setIsLoading(false);
        //                 })
        //                 .catch((error) => {
        //                     // Handle the error
        //                     console.error(error);
        //                     //setIsLoading(false);
        //                 });
        //         })
        //         .catch((error) => {
        //             // Handle the error
        //             console.error(error);
        //         });
        // }
        if (floorImage) {
            formData.append('floor_image', floorImage);
            Axios.put(`${Floorapi}${selectedRowId}/`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            })
                .then((response) => {
                    // Handle the response
                    setResponseMessage('SuccesssFully Floor Diagram Updated');
                    //navigate('/brand');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                    console.log(response.data);
                    //setIsLoading(false);
                })
                .catch((error) => {
                    // Handle the error
                    console.error(error);
                    //setIsLoading(false);
                });
        } else {
            //setIsLoading(true);

            // Make the PUT request with the form data
            Axios.put(`${Floorapi}${selectedRowId}/`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            })
                .then((response) => {
                    // Handle the response
                    setResponseMessage('SuccesssFully Floor Diagram Updated');
                    //navigate('/brand');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                    console.log(response.data);
                    //setIsLoading(false);
                })
                .catch((error) => {
                    // Handle the error
                    console.error(error);
                    //setIsLoading(false);
                });
        }
        // Axios.put(`http://localhost:1212/api/v1/OMM2/floor_mgnt/${selectedRowId}/`, formData, {
        //     headers: {
        //         Authorization: `Token ${token}`, // Include the token in the request headers
        //         'Content-Type': 'multipart/form-data'
        //     }
        // })
        //     .then((response) => {
        //         console.log('Data updated successfully:', response.data);
        //         // Perform any necessary actions after successful data update
        //     })
        //     .catch((error) => {
        //         console.log('Error updating data:', error);
        //         // Handle any errors that occur during the update process
        //     });
    };

    const [selectedRowId, setSelectedRowId] = React.useState(null);

    // const handleEditClick = (id) => {
    //     const token = localStorage.getItem('token');
    //     setSelectedRowId(id);

    //     Axios.get(`http://localhost:1212/api/v1/OMM2/class_mgmt/${id}`, {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     })
    //         .then((response) => {
    //             const data = response.data;
    //             // Update your state or perform any necessary actions with the fetched data
    //             // For example, you can set the fetched data to a state variable
    //             setMatData(data);
    //             setOpenModal(true);
    //             //console.log(data);
    //         })
    //         .catch((error) => {
    //             console.log('Error fetching data:', error);
    //         });
    // };
    const [name, setName] = useState('');
    const [status, setStatus] = useState(matData.status);
    const handleClose = () => {
        setSelectedRowId(null);
        setOpenModal(false);
    };

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', boxShadow: 0 }}>
            <ApiComponent apiUrl={Floorlistapi} onDataFetched={setFloordiadata} />
            <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}
            {/* <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center">
                <List>
                    <ListItem>
                        <ListItemAvatar>
                            <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                <StoreOutlinedIcon sx={{ color: 'white' }} />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText>
                            {' '}
                            <Typography variant="h3" color="black">
                                Hoarding Table
                            </Typography>
                        </ListItemText>
                    </ListItem>
                </List>
                <Button
                    className={classes.Button}
                    variant="contained"
                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                    //onClick={handleOpen}
                    href="/hoardingform"
                    startIcon={<AddCircleOutlinedIcon />}
                >
                    Hoarding
                </Button>
            </Stack> */}
            <Modal open={modalOpen} onClose={handleCloseModal}>
                <div>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: 'auto' }} />
                </div>
            </Modal>
            <Card sx={{ boxShadow: 2 }}>
                <Box
                    //id="invoice-container"
                    height="60vh"
                    width="100%"
                    fontWeight={10}
                    //className={classes.customButton}
                    sx={{
                        //width: '100%',
                        //border: '2px solid #fff2ea',
                        p: 2,
                        height: isSmallScreen ? '90vh' : '60vh',
                        width: '100%',
                        borderRadius: 5,
                        '& .MuiDataGrid-root': {
                            border: 'none',
                            padding: 1
                            //border: '2px dashed grey'
                        },
                        '& .super-app-theme--header': {
                            //backgroundColor: 'rgba(255, 7, 0, 0.55)',
                            //color: 'orange !important',
                            //fontWeight: 'bold !important'
                            //fontWeight: '700 !important',
                            //color: 'white !important'
                        },
                        '& .super-app-theme--cell': {
                            //backgroundColor: 'primary',
                            //color: '#1a3e72 !important',
                            //fontWeight: '600 !important',
                            //border: 1
                        },
                        '& .MuiDataGrid-cell': {
                            borderBottom: 'none !important',
                            //backgroundColor: '#f2f2f2',
                            color: 'black',
                            fontWeight: '550 !important'
                        },
                        '& .name-column--cell': {
                            variant: 'button',
                            fontWeight: 'medium',
                            color: 'ButtonText'
                        },
                        '& .MuiDataGrid-columnHeaders': {
                            //borderLeft: '2px dashed grey',
                            //borderRight: '2px dashed grey',
                            //borderBottom: '2px solid grey',
                            //fontWeight: 'bold !important',
                            //fontWeight: '700 !important',
                            //fontSize: 15,
                            //fontColor: 'red'
                            //backgroundColor: '#ff874b',
                            //borderRadius: 2
                            //color: 'white !important'
                        },

                        '.MuiDataGrid-columnHeaderTitle': {
                            //fontWeight: 'bold !important',
                            //fontWeight: '1000 !important',
                            //overflow: 'visible !important',
                            color: 'white',
                            width: 'auto',
                            paddingTop: '12px',
                            paddingBottom: '10px',
                            //paddingLeft: "8px",
                            //paddingRight: "24px",
                            textAlign: 'left',
                            fontSize: '0.80rem',
                            fontWeight: 700,
                            opacity: 0.7,
                            background: 'transparent',
                            color: '#8392ab',
                            borderRadius: 'none',
                            borderBottom: '0.0625rem solid #e9ecef'
                            //fontSize: 15
                        },
                        '& .MuiDataGrid-virtualScroller': {
                            //opacity: 1,
                            //transition: 'opacity 0.2s',
                            //overflowY: 'auto',
                            overflowX: 'auto',
                            '&::-webkit-scrollbar': {
                                width: '4px',
                                backgroundColor: '#F5F5F5'
                            },
                            '&::-webkit-scrollbar-thumb': {
                                //backgroundColor: '#11cdef',
                                borderRadius: '4px'
                            }
                        },
                        '& .MuiDataGrid-footerContainer': {
                            color: '#8392ab',
                            border: 'none'
                        },
                        '& .MuiDataGrid-columnSeparator': {
                            visibility: 'hidden'
                        },
                        '&.MuiDataGrid-pagination': {
                            //backgroundColor: "red",
                            //padding: "10px",
                            width: '20px !important'
                        },

                        '&.MuiDataGrid-virtualScroller': {
                            opacity: 0,
                            transition: 'opacity 0.2s'
                        },
                        '&.MuiTablePagination-root': {
                            width: '20px'
                        },

                        '&.MuiDataGrid-virtualScroller:hover': {
                            opacity: 1
                        },
                        '& .MuiTablePagination-select': {
                            //paddingRight: 2,
                            width: '10px !important'
                        },
                        '& .MuiTablePagination-selectIcon': {
                            display: 'none'
                        },

                        '&.MuiDataGrid-toolbar .MuiDataGrid-menuList': {
                            padding: 0
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root': {
                            fontSize: '14px',
                            color: '#333'
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root:hover': {
                            backgroundColor: '#f0f0f0'
                        }
                    }}
                >
                    <DataGrid
                        rows={floordiadata}
                        //columns={columns1}
                        columns={columns1}
                        pageSize={5}
                        getRowId={(row) => row.id}
                        components={{ Toolbar: GridToolbar, color: 'primary' }}
                        componentsProps={{
                            toolbar: {
                                showQuickFilter: true,
                                quickFilterProps: { debounceMs: 500 },
                                color: 'primary'
                            }
                        }}
                        loading={loading}
                        //autoHeight
                        //scrollbarSize={100}
                        //pageSize={5}
                        //checkboxSelection
                        //touchRipple
                        //disableColumnMenu
                        // onRowClick={handleRowClick}
                        disableColumnFilter={isSmallScreen ? true : false}
                        disableDensitySelector={isSmallScreen ? true : false}
                        virtualization
                    />
                </Box>
            </Card>
            <Modal open={modalOpen} onClose={handleCloseModal} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ maxWidth: '90vw', maxHeight: '90vh' }}>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                    <IconButton
                        onClick={handleCloseModal}
                        style={{ position: 'absolute', top: 10, right: 10, color: 'white', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </div>
            </Modal>
            <Modal open={!!selectedRowId} onClose={handleClose}>
                <Box sx={style}>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <List sx={{ width: '100%', maxWidth: 360 }}>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar className={classes.Button} sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                        <AddAPhotoOutlinedIcon />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    <Typography variant="h3">Update Floor Diagram #{selectedRowId}</Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="location-select-label">
                                    Showroom Location
                                </InputLabel>
                                <Select
                                    labelId="location-select-label"
                                    id="name"
                                    // value={location}
                                    // onChange={(e) => setLocation(e.target.value)}
                                    value={matData.name || ''}
                                    onChange={(e) => setMatData({ ...matData, name: e.target.value })}
                                    // value={matData.name}
                                    // onChange={(e) => setMatData({ ...matData, name: e.target.value })}
                                    label="Showroom Location"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    {showroomnames && showroomnames !== undefined
                                        ? showroomnames.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 2 }}>
                            <Card sx={{ maxWidth: 345, boxShadow: 2 }}>
                                <CardMedia sx={{ height: 140 }} image={matData.floor_image} title="green iguana" />
                                <CardContent>
                                    <Typography gutterBottom variant="h6" component="div">
                                        Floor Diagram
                                    </Typography>
                                </CardContent>
                            </Card>
                            {/* <img src={matData.floor_image} alt="floor" style={{ width: 'auto', height: '100px' }} /> */}
                        </Grid>
                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 2 }}>
                            <FormControl fullWidth variant="outlined" size="small" className={classes.select1}>
                                <InputLabel className={classes.label} id="floor_image">
                                    Change Floor Diagram
                                </InputLabel>
                                <OutlinedInput
                                    labelId="floor_image"
                                    id="floor_image"
                                    type="file"
                                    name="floor_image"
                                    //className={classes.select}
                                    inputProps={{ accept: 'image/*' }}
                                    startAdornment={
                                        <InputAdornment position="start">
                                            <PhotoCameraIcon />
                                        </InputAdornment>
                                    }
                                    onChange={handleImageChange}
                                    fullWidth
                                    //margin="normal"
                                    variant="outlined"
                                    label="Change Floor Diagram"
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            //focused: classes.label
                                        }
                                    }}
                                />
                            </FormControl>
                        </Grid>

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    onClick={handleConfirmSubmit}
                                    //startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Update
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Modal>

            <Dialog
                open={openDialogdelete}
                onClose={handleCloseDialogdelete}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are you sure want to delete this id #{selectedRowIddel}? </DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure want to Delete this Floor Diagram id #{selectedRowIddel}?
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialogdelete}>No</Button>
                    <Button onClick={deleteBrand}>Submit</Button>
                </DialogActions>
            </Dialog>

            <Dialog
                open={openDialog}
                onClose={handleCloseDialog}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are You Sure want to update this id data</DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">Are you sure want to update this Floor Diagram?</DialogContentText>
                    {/* <DialogContentText id="alert-dialog-description">
            <Typography variant="h5">Are you sure want to update this brand id #{selectedRowId}? </Typography>
        </DialogContentText> */}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog}>No</Button>
                    <Button onClick={handleSubmit}>Submit</Button>
                </DialogActions>
            </Dialog>
        </Card>
    );
}

export default withAuth(DataTable);
