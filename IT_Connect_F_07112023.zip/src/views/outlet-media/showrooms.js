// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import { Button } from '@mui/material';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import { Brandapi } from '../apicomp/Apiurls';
import CustomList from '../headers/headercard';
import CustomCard from '../headers/HeaderCustomCard';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';
import Showroomstable from './showroomstable';

const SamplePage = () => {
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = useState(false);
    const [responseMessage, setResponseMessage] = useState('');

    return (
        <div>
            <CustomCard>
                <CustomList icon={<StoreOutlinedIcon />} text="Showrooms" iconColor="#ffffff" variant="h3" />
                <Button className={classes.Button} variant="contained" startIcon={<AddCircleOutlinedIcon />} href="/showroomadd">
                    Showrooms
                </Button>
            </CustomCard>
            <br></br>
            <Showroomstable />
        </div>
    );
};

export default withAuth(SamplePage);
