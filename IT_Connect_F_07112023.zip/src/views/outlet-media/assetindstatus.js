import { OutlinedInput } from '@material-ui/core';
import { CheckCircle } from '@mui/icons-material';
import { KeyboardArrowDown, KeyboardArrowUp } from '@mui/icons-material';
//import { Typography } from 'tabler-icons-react';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';
import AdjustOutlinedIcon from '@mui/icons-material/AdjustOutlined';
import ArrowLeftOutlinedIcon from '@mui/icons-material/ArrowLeftOutlined';
import ArrowRightOutlinedIcon from '@mui/icons-material/ArrowRightOutlined';
import CloseIcon from '@mui/icons-material/Close';
//import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import DraftsIcon from '@mui/icons-material/Drafts';
import EditIcon from '@mui/icons-material/Edit';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FavoriteIcon from '@mui/icons-material/Favorite';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import InboxIcon from '@mui/icons-material/Inbox';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import SearchIcon from '@mui/icons-material/Search';
import ShareIcon from '@mui/icons-material/Share';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import TableChartIcon from '@mui/icons-material/TableChart';
import TripOriginTwoToneIcon from '@mui/icons-material/TripOriginTwoTone';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import { Box, Button, Card, CardContent, CardMedia, Link, Modal, Stack, Typography, useTheme } from '@mui/material';
import { IconButton, useMediaQuery } from '@mui/material';
// material-ui

//import React, { FormControl, Grid, InputAdornment, InputLabel, MenuItem, Select, TextField } from 'react';
//import { makeStyles } from '@mui/styles';
import {
    FormControl,
    // Typography,
    Grid,
    // Box,
    InputAdornment,
    // Stack,
    // Card
    InputLabel,
    MenuItem,
    Select,
    TextField
} from '@mui/material';
import { Pagination, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import Avatar from '@mui/material/Avatar';
//import Avatar from '@mui/material/Avatar';
//import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
//import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
//import CardMedia from '@mui/material/CardMedia';
import Collapse from '@mui/material/Collapse';
import { red } from '@mui/material/colors';
//import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Divider from '@mui/material/Divider';
//import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
// import ListItemText from '@mui/material/ListItemText';
//import Pagination from '@mui/material/Pagination';
import PaginationItem from '@mui/material/PaginationItem';
import { styled } from '@mui/material/styles';
import TablePagination from '@mui/material/TablePagination';
//import Typography from '@mui/material/Typography';
import { makeStyles } from '@mui/styles';
import { DataGrid, GridRowParams, GridToolbar } from '@mui/x-data-grid';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import Branding from '../../../src/assets/images/branding.png';
import Branding1 from '../../../src/assets/images/branding1.png';
import Branding2 from '../../../src/assets/images/branding2.png';
import ApiComponent from '../apicomp/ApiComponent';
import { Brandapi, Statusapi, Vendorapi } from '../apicomp/Apiurls';
import { AddAdvertisementFormapi, OutletMediaDetailapi, OutletMediaFormapi, OutletMediaListapi, Showroomapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import { BlogCardDemo } from './card';

//import useStyles from '../styles/styles';

//import { useNavigate } from 'react-router-dom';

const ExpandMore = styled((props) => {
    const { expand, ...other } = props;
    return <IconButton {...other} />;
})(({ theme, expand }) => ({
    transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
        duration: theme.transitions.duration.shortest
    })
}));
const useStyles = makeStyles((theme) => ({
    tableContainer: {
        marginTop: theme.spacing(2),
        [theme.breakpoints.down('sm')]: {
            marginTop: theme.spacing(1)
        }
    },
    searchField: {
        marginBottom: theme.spacing(2),
        [theme.breakpoints.down('sm')]: {
            marginBottom: theme.spacing(1)
        }
    },
    pagination: {
        marginTop: theme.spacing(2),
        display: 'flex',
        justifyContent: 'center'
    }
}));
function DataTable() {
    //const classes = useStyles();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const navigate = useNavigate();
    const [nestopen, setnestOpen] = useState(false);

    const [expanded, setExpanded] = React.useState(false);

    const handleExpandClick = () => {
        setExpanded(!expanded);
    };
    // const theme = useTheme();
    //const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const handlenestOpen = () => {
        setnestOpen(true);
    };

    const handlenestClose = () => {
        setnestOpen(false);
    };

    const columns1 = [
        {
            field: 'name',
            headerName: 'Showroom',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 100 : 120
        },
        {
            field: 'branding_type',
            headerName: 'Total',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'branding_location',
            headerName: 'Active',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'brand',
            headerName: 'Expired',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'brandi',
            headerName: 'Empty',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        }
    ];

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${OutletMediaFormapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Light Type Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const rowClassName = (params) => {
        return {
            backgroundColor: params.rowIndex % 2 === 0 ? '#f5f5f5' : 'inherit'
        };
    };
    const [showroomnames, setShowroomnames] = React.useState([]);
    const [showroomlocation, setShowroomlocation] = React.useState('');
    const [classname, setClassname] = useState('');
    const [classvalue, setClassvalue] = useState('');
    const [width, setWidth] = useState('');
    const [height, setHeight] = useState('');
    const [modelname, setModelname] = useState('');
    const [brandname, setBrandname] = useState('');
    const [brandvalue, setBrandvalue] = useState('');
    const [brandtype, setBrandtype] = useState('');
    const [brandtypevalue, setBrandtypevalue] = useState('');
    const [vendor, setVendor] = useState('');
    const [vendorvalue, setVendorvalue] = useState('');
    const [brandlocation, setBrandlocation] = useState('');
    const [brandlocationvalue, setBrandlocationvalue] = useState('');
    const [lighttype, setLighttype] = useState('');
    const [lighttypevalue, setLighttypevalue] = useState('');
    const [material, setMaterial] = useState('');
    const [materialvalue, setMaterialvalue] = useState('');
    const [expirevalue, setExpirevalue] = useState('');
    const [image, setImage] = useState([]);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const handleSubmit = async (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        const formData = new FormData();
        //formData.append('name', classvalue);
        formData.append('outlet_media', selectedRowId);
        formData.append('asset_image', image);

        formData.append('ad_status', status);
        formData.append('comment', comments);
        formData.append('model_product_name', modelname);

        formData.append('brand', brandvalue);

        formData.append('vendor', vendorvalue);
        formData.append('expiry_on', expirevalue);
        formData.append('created_by', 1);
        formData.append('modified_by', 1);

        try {
            const response = await Axios.post(AddAdvertisementFormapi, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            });
            console.log(response.data);
            setResponseMessage('SuccesssFully Brand Type Created');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            //console.log(response);
        } catch (error) {
            console.error(error);
        }
    };

    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${OutletMediaFormapi}${id}`, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}` // Include the token in the request headers,
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                //setMatData(data);
                setnestOpen(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/outletupdate/${id}`);
        window.location.reload();
    };

    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    //const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    //const [loading, setLoading] = React.useState(false);
    const [hoarding, setHoarding] = React.useState([]);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setBrandname(data);
            setShowroomnames(data);
            setVendor(data);
            setStatus(data);
            setHoarding(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts

            setStatus([]);
            setShowroomnames([]);
            setBrandname([]);
            setVendor([]);
            setHoarding([]);
        };
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get(OutletMediaListapi, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}`
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setHoarding(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    // const [searchQuery, setSearchQuery] = useState('');
    // const [filteredShowrooms, setFilteredShowrooms] = useState(showroomnames);

    // const handleSearchInputChange = (event) => {
    //     const query = event.target.value;
    //     setSearchQuery(query);

    //     const filteredResults = showroomnames.filter((item) => item.name.toLowerCase().includes(query.toLowerCase()));
    //     setFilteredShowrooms(filteredResults);
    // };

    // If no search query, display all data
    //const showroomsToDisplay = searchQuery ? filteredShowrooms : showroomnames;

    const itemsPerPage = 12;
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const [showGrid, setShowGrid] = useState(true);

    const handleSearchInputChange = (event) => {
        const query = event.target.value;
        setSearchQuery(query);
        setCurrentPage(1);
    };

    const handlePageChange = (event, page) => {
        setCurrentPage(page);
    };

    // Filter showrooms based on search query
    const filteredShowrooms = showroomnames.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()));

    const totalItems = filteredShowrooms.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const showroomsToDisplay = filteredShowrooms.slice(startIndex, endIndex);

    const handleToggleDisplay = () => {
        setShowGrid((prevShowGrid) => !prevShowGrid);
    };

    const Assetstatus = [
        {
            id: 1,
            title: 'Wall Branding 2',
            assetid: '11795',
            status: 'Expired',
            location: 'Entry Left',
            material: 'Vinyl With Sunboard',
            brand: 'Vivo',
            model: 'V27/Y100',
            img: Branding,
            icon: <TripOriginTwoToneIcon sx={{ color: 'red' }} fontSize="medium" />
        },
        {
            id: 2,
            title: 'Name Board',
            assetid: '11786',
            status: 'Active',
            location: 'Outide Entrance',
            material: 'LED -Mono',
            brand: 'Vivo',
            model: 'Poorvika',
            img: Branding1,
            icon: <TripOriginTwoToneIcon sx={{ color: 'green' }} fontSize="medium" />
        },
        {
            id: 3,
            title: 'Wall Branding 2',
            assetid: '11795',
            status: 'Expired',
            location: 'Entry Left',
            material: 'Vinyl With Sunboard',
            brand: 'Vivo',
            model: 'V27/Y100',
            img: Branding,
            icon: <TripOriginTwoToneIcon sx={{ color: 'red' }} fontSize="medium" />
        },
        {
            id: 4,
            title: 'Name Board',
            assetid: '11786',
            status: 'Active',
            location: 'Outide Entrance',
            material: 'LED -Mono',
            brand: 'Vivo',
            model: 'Poorvika',
            img: Branding1,
            icon: <TripOriginTwoToneIcon sx={{ color: 'green' }} fontSize="medium" />
        }
    ];
    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <>
            {' '}
            <Box sx={{ m: isMobile ? -2 : 0 }}>
                <Card sx={{ width: '100%', boxShadow: 0 }}>
                    <Stack
                        direction={{ xs: 'column', sm: 'row' }}
                        // justifyContent="space-between"
                        // alignItems="center"
                        justifyContent="space-between"
                        alignItems="center"
                        spacing={2}
                        sx={{ padding: 1 }}
                    >
                        <List>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                        <StoreOutlinedIcon sx={{ color: 'white' }} />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    {' '}
                                    <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 20 : 22 }}>
                                        Marketing Asset Status
                                    </Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        <Button
                            //className={classes.Button}
                            variant="contained"
                            sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                            //onClick={handleOpen}
                            href="/addad"
                            startIcon={<AddCircleOutlineOutlinedIcon />}
                        >
                            Add
                        </Button>
                    </Stack>
                </Card>
                <br></br>
                <Card sx={{ boxShadow: 0, borderTop: '1px solid #ebebeb', p: isMobile ? 0 : 2 }}>
                    <Box>
                        {responseMessage &&
                            Swal.fire({
                                title: 'success',
                                text: responseMessage,
                                icon: 'success',
                                confirmButtonText: 'OK'
                                //onClose: handleClose
                            })}
                        <ApiComponent apiUrl={OutletMediaListapi} onDataFetched={setHoarding} />
                        <ApiComponent apiUrl={Brandapi} onDataFetched={setBrandname} />
                        <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
                        <ApiComponent apiUrl={Statusapi} onDataFetched={setStatus} />
                        <ApiComponent apiUrl={Vendorapi} onDataFetched={setVendor} />{' '}
                        <Grid container spacing={2} direction="row">
                            <Grid item sm={12} xs={12} md={6} lg={3}>
                                <Card sx={{ border: '1px solid #ebebeb', height: '100%' }}>
                                    <CardHeader
                                        // avatar={
                                        //     <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
                                        //         R
                                        //     </Avatar>
                                        // }
                                        action={
                                            <IconButton aria-label="settings">
                                                <MoreVertIcon />
                                            </IconButton>
                                        }
                                        title="Wall Branding 2"
                                        subheader="Expired"
                                    />
                                    <CardMedia component="img" height="" image={Branding2} alt="Paella dish" />
                                    <CardContent>
                                        <Typography variant="body2" color="text.secondary">
                                            Branding Image With Expired Status
                                        </Typography>
                                    </CardContent>
                                    {/* <CardActions disableSpacing>
                                <IconButton aria-label="add to favorites">
                                    <FavoriteIcon />
                                </IconButton>
                                <IconButton aria-label="share">
                                    <ShareIcon />
                                </IconButton>
                                <ExpandMore expand={expanded} onClick={handleExpandClick} aria-expanded={expanded} aria-label="show more">
                                    <ExpandMoreIcon />
                                </ExpandMore>
                            </CardActions>
                            <Collapse in={expanded} timeout="auto" unmountOnExit>
                                <CardContent>
                                    <Typography paragraph>Method:</Typography>
                                    <Typography paragraph>
                                        Heat 1/2 cup of the broth in a pot until simmering, add saffron and set aside for 10 minutes.
                                    </Typography>
                                    <Typography paragraph>
                                        Heat oil in a (14- to 16-inch) paella pan or a large, deep skillet over medium-high heat. Add
                                        chicken, shrimp and chorizo, and cook, stirring occasionally until lightly browned, 6 to 8 minutes.
                                        Transfer shrimp to a large plate and set aside, leaving chicken and chorizo in the pan. Add
                                        pimentón, bay leaves, garlic, tomatoes, onion, salt and pepper, and cook, stirring often until
                                        thickened and fragrant, about 10 minutes. Add saffron broth and remaining 4 1/2 cups chicken broth;
                                        bring to a boil.
                                    </Typography>
                                    <Typography paragraph>
                                        Add rice and stir very gently to distribute. Top with artichokes and peppers, and cook without
                                        stirring, until most of the liquid is absorbed, 15 to 18 minutes. Reduce heat to medium-low, add
                                        reserved shrimp and mussels, tucking them down into the rice, and cook again without stirring, until
                                        mussels have opened and rice is just tender, 5 to 7 minutes more. (Discard any mussels that
                                        don&apos;t open.)
                                    </Typography>
                                    <Typography>Set aside off of the heat to let rest for 10 minutes, and then serve.</Typography>
                                </CardContent>
                            </Collapse> */}
                                </Card>
                            </Grid>

                            <Grid item sm={12} xs={12} md={6} lg={4} direction="column">
                                <Card sx={{ width: '100%', my: 0, border: '1px solid #ebebeb', height: '100%' }}>
                                    <List>
                                        <ListItem>
                                            <ListItemText>
                                                {' '}
                                                <Typography variant="h5" sx={{ color: '#ff8b3d', fontWeight: 'bold' }}>
                                                    Branding Details
                                                </Typography>
                                            </ListItemText>
                                        </ListItem>
                                    </List>
                                    <Card sx={{ boxShadow: 0, p: 0, borderTop: '1px solid #ebebeb' }}>
                                        <Grid container spacing={0} direction="row">
                                            <Grid item sm={12} xs={12} md={6} lg={6}>
                                                <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                                                    <ListItem>
                                                        <ListItemText primary="Asset ID" secondary="11795" />
                                                    </ListItem>
                                                    <ListItem>
                                                        <ListItemText primary="Size(W x H x D)" secondary="160 x 92" />
                                                    </ListItem>
                                                    <ListItem>
                                                        <ListItemText primary="Location" secondary="Entry Left" />
                                                    </ListItem>
                                                    <ListItem>
                                                        <ListItemText primary="Material" secondary="Vinyl With Sunboard" />
                                                    </ListItem>
                                                </List>
                                            </Grid>
                                            <Grid item sm={12} xs={12} md={6} lg={6}>
                                                <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                                                    <ListItem>
                                                        <ListItemText primary="Brand" secondary="Vivo" />
                                                    </ListItem>
                                                    <ListItem>
                                                        <ListItemText primary="Model" secondary="V27/Y100" />
                                                    </ListItem>
                                                    <ListItem>
                                                        <ListItemText primary="Vendor" secondary="Techno Signs Pvt Ltd" />
                                                    </ListItem>
                                                    <ListItem>
                                                        <ListItemText primary="Status" secondary="Expired" />
                                                    </ListItem>
                                                </List>
                                            </Grid>
                                            {/* <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                                            <ListItem>
                                                <ListItemText primary="Asset ID" secondary="11795" />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemText primary="Size(W x H x D)" secondary="160 x 92" />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemText primary="Location" secondary="Entry Left" />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemText primary="Material" secondary="Vinyl With Sunboard" />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemText primary="Brand" secondary="Vivo" />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemText primary="Model" secondary="V27/Y100" />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemText primary="Vendor" secondary="Techno Signs Pvt Ltd" />
                                            </ListItem>
                                        </List> */}
                                        </Grid>
                                    </Card>
                                </Card>
                            </Grid>

                            <Grid item sm={12} xs={12} md={6} lg={4}>
                                <Card sx={{ width: '100%', my: 0, border: '1px solid #ebebeb', height: '100%' }}>
                                    <List>
                                        <ListItem>
                                            <ListItemText>
                                                {' '}
                                                <Typography variant="h5" sx={{ color: '#ff8b3d', fontWeight: 'bold' }}>
                                                    Ticket Details
                                                </Typography>
                                            </ListItemText>
                                        </ListItem>
                                    </List>
                                    <Card sx={{ boxShadow: 0, p: 0, borderTop: '1px solid #ebebeb', height: '100%' }}>
                                        <ListItem>
                                            <ListItemText primary="Created By" secondary="Vijay - Manager" />
                                        </ListItem>
                                        <Divider />
                                        <ListItem>
                                            <ListItemText primary="Ticket Date" secondary="31-04-2023" />
                                        </ListItem>
                                        <Divider />
                                        <ListItem>
                                            <ListItemText primary="Remarks" secondary="Old inshop, need to change to new model" />
                                        </ListItem>
                                    </Card>
                                </Card>
                            </Grid>
                        </Grid>
                    </Box>
                </Card>
            </Box>
        </>
    );
}

export default withAuth(DataTable);
