// material-ui
import { Typography } from '@mui/material';

// project imports
import MainCard from 'ui-component/cards/MainCard';

// ==============================|| SAMPLE PAGE ||============================== //

const SamplePage = () => {
    // const [location, setLocation] = useState('');
    // const [images, setImages] = useState([]);

    // const handleLocationChange = (event) => {
    //     setLocation(event.target.value);
    // };

    // const handleImagesChange = (event) => {
    //     setImages(event.target.files);
    // };

    // const handleSubmit = (event) => {
    //     event.preventDefault();
    //     // handle form submission logic here
    // };
    return (
        <MainCard title="Sample Card">
            <Typography variant="body2">
                Lorem ipsum dolor sit amen, consenter nipissing eli, sed do elusion tempos incident ut laborers et doolie magna alissa. Ut
                enif ad minim venice, quin nostrum exercitation illampu laborings nisi ut liquid ex ea commons construal. Duos aube grue
                dolor in reprehended in voltage veil esse colum doolie eu fujian bulla parian. Exceptive sin ocean cuspidate non president,
                sunk in culpa qui officiate descent molls anim id est labours.
            </Typography>
        </MainCard>
    );
};

export default SamplePage;
