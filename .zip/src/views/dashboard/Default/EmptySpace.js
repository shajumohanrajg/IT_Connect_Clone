import PropTypes from 'prop-types';

// material-ui
import StorefrontOutlinedIcon from '@mui/icons-material/StorefrontOutlined';
import { Avatar, Box, List, ListItem, ListItemAvatar, ListItemText, Typography } from '@mui/material';
import { styled, useTheme } from '@mui/material/styles';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import TotalIncomeCard from 'ui-component/cards/Skeleton/TotalIncomeCard';

// assets
//import { Animate } from '@mui/material';
import { animated, useSpring } from 'react-spring';

// styles
const CardWrapper = styled(MainCard)(({ theme }) => ({
    overflow: 'hidden',
    position: 'relative',
    '&:after': {
        content: '""',
        position: 'absolute',
        width: 210,
        height: 210,
        //background: `linear-gradient(210.04deg, ${theme.palette.warning.dark} -50.94%, rgba(144, 202, 249, 0) 83.49%)`,
        background: `linear-gradient(210.04deg, #fb6340 -50.94%, rgba(144, 202, 249, 0) 83.49%)`,
        borderRadius: '50%',
        top: -30,
        right: -180
    },
    '&:before': {
        content: '""',
        position: 'absolute',
        width: 210,
        height: 210,
        background: `linear-gradient(140.9deg, ${theme.palette.warning.dark} -14.02%, rgba(144, 202, 249, 0) 70.50%)`,
        borderRadius: '50%',
        top: -160,
        right: -130
    }
}));

// ==============================|| DASHBOARD - TOTAL INCOME LIGHT CARD ||============================== //
function AnimatedNumber({ number }) {
    const { value } = useSpring({
        from: { value: 0 },
        to: { value: 750 }, // Change this value to your desired final number
        config: { duration: 1500 } // Change this value to modify the animation duration
    });

    return <animated.span>{value.to((val) => Math.floor(val))}</animated.span>;
}
const EmptySpace = ({ isLoading }) => {
    const theme = useTheme();

    return (
        <>
            {isLoading ? (
                <TotalIncomeCard />
            ) : (
                <CardWrapper border={false} content={false}>
                    <Box sx={{ p: 2 }}>
                        <List sx={{ py: 1.5 }}>
                            <ListItem alignItems="center" disableGutters sx={{ py: 0, px: 3 }}>
                                <ListItemAvatar>
                                    <Avatar
                                        variant="rounded"
                                        sx={{
                                            ...theme.typography.commonAvatar,
                                            ...theme.typography.largeAvatar,
                                            //backgroundColor: theme.palette.warning.light
                                            // backgroundColor: theme.palette.warning.light
                                            background: 'linear-gradient(to right bottom, #fb6340, #fbb140)',
                                            color: 'whitesmoke'
                                            //color: theme.palette.warning.dark
                                        }}
                                    >
                                        <StorefrontOutlinedIcon sx={{ fontSize: 35 }} />
                                    </Avatar>
                                </ListItemAvatar>

                                <ListItemText
                                    sx={{
                                        py: 0,
                                        mt: 0.45,
                                        mb: 0.45
                                    }}
                                    primary={
                                        <Typography
                                            variant="h4"
                                            sx={{
                                                //color: theme.palette.grey[500],
                                                mt: 0.5
                                            }}
                                        >
                                            <AnimatedNumber number="486" />
                                        </Typography>
                                    }
                                    secondary={
                                        <Typography
                                            variant="h5"
                                            sx={{
                                                color: theme.palette.grey[500],
                                                mt: 0.5
                                            }}
                                        >
                                            Empty Space
                                        </Typography>
                                    }
                                />
                            </ListItem>
                        </List>
                    </Box>
                </CardWrapper>
            )}
        </>
    );
};

EmptySpace.propTypes = {
    isLoading: PropTypes.bool
};

export default EmptySpace;
