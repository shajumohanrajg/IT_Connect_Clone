import { OutlinedInput } from '@material-ui/core';
import { CheckCircle } from '@mui/icons-material';
import { KeyboardArrowDown, KeyboardArrowUp } from '@mui/icons-material';
import { ArrowDownward, ArrowUpward } from '@mui/icons-material';
//import { Typography } from 'tabler-icons-react';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';
import AdjustOutlinedIcon from '@mui/icons-material/AdjustOutlined';
import ArrowLeftOutlinedIcon from '@mui/icons-material/ArrowLeftOutlined';
import ArrowRightOutlinedIcon from '@mui/icons-material/ArrowRightOutlined';
import CloseIcon from '@mui/icons-material/Close';
//import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import DraftsIcon from '@mui/icons-material/Drafts';
import EditIcon from '@mui/icons-material/Edit';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import FactCheckOutlinedIcon from '@mui/icons-material/FactCheckOutlined';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import InboxIcon from '@mui/icons-material/Inbox';
import NotInterestedIcon from '@mui/icons-material/NotInterested';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import PlaylistAddCheckCircleIcon from '@mui/icons-material/PlaylistAddCheckCircle';
import PlaylistAddCheckCircleOutlinedIcon from '@mui/icons-material/PlaylistAddCheckCircleOutlined';
import SearchIcon from '@mui/icons-material/Search';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import TableChartIcon from '@mui/icons-material/TableChart';
import TableRowsTwoToneIcon from '@mui/icons-material/TableRowsTwoTone';
import TaskAltOutlinedIcon from '@mui/icons-material/TaskAltOutlined';
import TripOriginIcon from '@mui/icons-material/TripOrigin';
import TripOriginTwoToneIcon from '@mui/icons-material/TripOriginTwoTone';
import UnpublishedIcon from '@mui/icons-material/Unpublished';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import ViewWeekTwoToneIcon from '@mui/icons-material/ViewWeekTwoTone';
import { Badge, Box, Button, Card, CardContent, CardMedia, Chip, Link, Modal, Stack, Typography, useTheme } from '@mui/material';
import { IconButton, useMediaQuery } from '@mui/material';
import Fab from '@mui/material/Fab';
import AddIcon from '@mui/icons-material/Add';
import { withStyles } from '@mui/styles';
// material-ui

//import React, { FormControl, Grid, InputAdornment, InputLabel, MenuItem, Select, TextField } from 'react';
//import { makeStyles } from '@mui/styles';
import {
    FormControl,
    // Typography,
    Grid,
    // Box,
    InputAdornment,
    // Stack,
    // Card
    InputLabel,
    MenuItem,
    Select,
    TextField
} from '@mui/material';
import { Pagination, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';
// import { Button, Card, CardContent, Grid, Stack, Typography } from '@mui/material';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Avatar from '@mui/material/Avatar';
//import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
// import ListItemText from '@mui/material/ListItemText';
//import Pagination from '@mui/material/Pagination';
import PaginationItem from '@mui/material/PaginationItem';
// material-ui
import { styled } from '@mui/material/styles';
import TablePagination from '@mui/material/TablePagination';
//import Typography from '@mui/material/Typography';
import { makeStyles } from '@mui/styles';
import { borderRadius } from '@mui/system';
import { DataGrid, GridRowParams, GridToolbar } from '@mui/x-data-grid';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

// project imports
import AnimateButton from 'ui-component/extended/AnimateButton';

import Branding from '../../../src/assets/images/branding.png';
import ApiComponent from '../apicomp/ApiComponent';
import { Brandapi, Statusapi, Vendorapi } from '../apicomp/Apiurls';
import { AddAdvertisementFormapi, OutletMediaDetailapi, OutletMediaFormapi, OutletMediaListapi, Showroomapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import Assetfilter from './assetfilter';
import { BlogCardDemo } from './card';
//import Fab from '@mui/material/Fab';
//import AddIcon from '@mui/icons-material/Add';
import './FloatingActionButton.css';

//import useStyles from '../styles/styles';

//import { useNavigate } from 'react-router-dom';

const styles = {
    card: {
        width: 200,
        height: 200,
        background: 'lightblue',
        borderRadius: 10,
        boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
        transition: 'transform 0.3s ease',
        '&:hover': {
            transform: 'scale(1.1)'
        }
    }
};

const CardStyle = styled(Card)(({ theme }) => ({
    //background: theme.palette.warning.light,
    // marginTop: '16px',
    //marginBottom: '16px',
    overflow: 'hidden',
    position: 'relative',
    borderRadius: 10,
    boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
    transition: 'transform 0.3s ease-in-out',
    '&:hover': {
        transform: 'scale(0.9)'
        // border: '1px solid gray'
    },
    // '&::after': {
    //     content: '""',
    //     position: 'absolute',
    //     width: '11px',
    //     height: '11px',
    //     //backgroundColor: theme.palette.warning.dark,
    //     backgroundColor: 'black',
    //     borderRadius: '50%',
    //     top: '50%',
    //     right: '10px',
    //     transform: 'translateY(-50%)'
    // },
    // '&::after': {
    //     content: '""',
    //     position: 'absolute',
    //     width: '7px',
    //     height: '15%',
    //     backgroundColor: theme.palette.primary.light,
    //     top: '0',
    //     right: '20px'
    //     //borderRadius: 5
    // },
    '&::before': {
        content: '""',
        position: 'absolute',
        width: '7px',
        height: '20%',
        backgroundColor: theme.palette.primary.light,
        bottom: '0',
        right: '20px'
        //borderRadius: 5
    },

    '&:before': {
        content: '""',
        position: 'absolute',
        width: '0',
        height: '20',
        borderLeft: '4px solid transparent',
        borderRight: '4px solid transparent',
        borderBottom: `7px solid ${theme.palette.primary.dark}`,
        top: '0',
        right: '20px'
    }
    // '&::after': {
    //     content: '""',
    //     position: 'absolute',
    //     width: '7px',
    //     height: '20%',
    //     backgroundColor: theme.palette.primary.light,
    //     top: '0',
    //     right: '20px'
    //     //borderRadius: 5
    // },

    // '&:after': {
    //     content: '""',
    //     position: 'absolute',
    //     width: '0',
    //     height: '20',
    //     borderLeft: '4px solid transparent',
    //     borderRight: '4px solid transparent',
    //     borderBottom: `7px solid ${theme.palette.primary.dark}`,
    //     top: '0',
    //     right: '20px'
    // }

    // '&:after': {
    //     content: '""',
    //     position: 'absolute',
    //     width: '200px',
    //     height: '200px',
    //     border: '5px solid ',
    //     borderColor: theme.palette.warning.main,
    //     borderRadius: '50%',
    //     top: '65px',
    //     right: '-150px'
    // },
    // '&:before': {
    //     content: '""',
    //     position: 'absolute',
    //     width: '200px',
    //     height: '200px',
    //     border: '5px solid ',
    //     borderColor: theme.palette.warning.main,
    //     borderRadius: '50%',
    //     top: '145px',
    //     right: '-70px'
    // }
}));

const useStyles = makeStyles((theme) => ({
    tableContainer: {
        marginTop: theme.spacing(2),
        [theme.breakpoints.down('sm')]: {
            marginTop: theme.spacing(1)
        }
    },
    searchField: {
        marginBottom: theme.spacing(2),
        [theme.breakpoints.down('sm')]: {
            marginBottom: theme.spacing(1)
        }
    },
    pagination: {
        marginTop: theme.spacing(2),
        display: 'flex',
        justifyContent: 'center'
    }
}));
function DataTable() {
    //const classes = useStyles();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const navigate = useNavigate();
    const [nestopen, setnestOpen] = useState(false);
    // const theme = useTheme();
    //const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const handlenestOpen = () => {
        setnestOpen(true);
    };

    const handlenestClose = () => {
        setnestOpen(false);
    };

    const columns1 = [
        {
            field: 'name',
            headerName: 'Showroom',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 100 : 150,
            renderCell: (params) => {
                const name = params.value;
                return (
                    <Link href="/assetstatus" rel="noopener noreferrer" sx={{ textDecoration: 'none' }}>
                        {name}
                    </Link>
                );
            }
        },
        {
            field: 'total',
            headerName: 'Total',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'active',
            headerName: 'Active',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'expired',
            headerName: 'Expired',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'empty',
            headerName: 'Empty',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        }
    ];

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${OutletMediaFormapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Light Type Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const rowClassName = (params) => {
        return {
            backgroundColor: params.rowIndex % 2 === 0 ? '#f5f5f5' : 'inherit'
        };
    };

    const dummydata = [
        {
            id: 1,
            name: 'TN-EKTL',
            total: '16',
            active: '6',
            expired: '7',
            empty: '1'
        },
        {
            id: 2,
            name: 'TN-PORUR',
            total: '8',
            active: '5',
            expired: '2',
            empty: '1'
        },
        {
            id: 3,
            name: 'TN-POONAMALLEE',
            total: '9',
            active: '3',
            expired: '5',
            empty: '0'
        },
        {
            id: 4,
            name: 'TN-KANCHIPURAM',
            total: '20',
            active: '6',
            expired: '9',
            empty: '2'
        },
        {
            id: 5,
            name: 'TN-VADAPALANI',
            total: '4',
            active: '4',
            expired: '0',
            empty: '0'
        },
        {
            id: 6,
            name: 'TN-EKTL',
            total: '16',
            active: '6',
            expired: '7',
            empty: '1'
        },
        {
            id: 7,
            name: 'TN-PORUR',
            total: '8',
            active: '5',
            expired: '2',
            empty: '1'
        },
        {
            id: 8,
            name: 'TN-POONAMALLEE',
            total: '9',
            active: '3',
            expired: '5',
            empty: '0'
        },
        {
            id: 9,
            name: 'TN-KANCHIPURAM',
            total: '20',
            active: '6',
            expired: '9',
            empty: '2'
        },
        {
            id: 10,
            name: 'TN-VADAPALANI',
            total: '4',
            active: '4',
            expired: '0',
            empty: '0'
        }
    ];
    const Assetstatus = [
        {
            id: 1,
            title: 'Wall Branding 2',
            assetid: '11795',
            status: 'Expired',
            location: 'Entry Left',
            material: 'Vinyl With Sunboard',
            brand: 'Vivo',
            model: 'V27/Y100'
        },
        {
            id: 2,
            title: 'Name Board',
            assetid: '11786',
            status: 'Active',
            location: 'Outide Entrance',
            material: 'LED -Mono',
            brand: 'Vivo',
            model: 'Poorvika'
        },
        {
            id: 3,
            title: 'Wall Branding 2',
            assetid: '11795',
            status: 'Expired',
            location: 'Entry Left',
            material: 'Vinyl With Sunboard',
            brand: 'Vivo',
            model: 'V27/Y100'
        },
        {
            id: 4,
            title: 'Name Board',
            assetid: '11786',
            status: 'Active',
            location: 'Outide Entrance',
            material: 'LED -Mono',
            brand: 'Vivo',
            model: 'Poorvika'
        }
    ];
    const [showroomnames, setShowroomnames] = React.useState([]);
    const [showroomlocation, setShowroomlocation] = React.useState('');
    const [classname, setClassname] = useState('');
    const [classvalue, setClassvalue] = useState('');
    const [width, setWidth] = useState('');
    const [height, setHeight] = useState('');
    const [modelname, setModelname] = useState('');
    const [brandname, setBrandname] = useState('');
    const [brandvalue, setBrandvalue] = useState('');
    const [brandtype, setBrandtype] = useState('');
    const [brandtypevalue, setBrandtypevalue] = useState('');
    const [vendor, setVendor] = useState('');
    const [vendorvalue, setVendorvalue] = useState('');
    const [brandlocation, setBrandlocation] = useState('');
    const [brandlocationvalue, setBrandlocationvalue] = useState('');
    const [lighttype, setLighttype] = useState('');
    const [lighttypevalue, setLighttypevalue] = useState('');
    const [material, setMaterial] = useState('');
    const [materialvalue, setMaterialvalue] = useState('');
    const [expirevalue, setExpirevalue] = useState('');
    const [image, setImage] = useState([]);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const handleSubmit = async (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        const formData = new FormData();
        //formData.append('name', classvalue);
        formData.append('outlet_media', selectedRowId);
        formData.append('asset_image', image);

        formData.append('ad_status', status);
        formData.append('comment', comments);
        formData.append('model_product_name', modelname);

        formData.append('brand', brandvalue);

        formData.append('vendor', vendorvalue);
        formData.append('expiry_on', expirevalue);
        formData.append('created_by', 1);
        formData.append('modified_by', 1);

        try {
            const response = await Axios.post(AddAdvertisementFormapi, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            });
            console.log(response.data);
            setResponseMessage('SuccesssFully Brand Type Created');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            //console.log(response);
        } catch (error) {
            console.error(error);
        }
    };

    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${OutletMediaFormapi}${id}`, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}` // Include the token in the request headers,
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                //setMatData(data);
                setnestOpen(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/outletupdate/${id}`);
        window.location.reload();
    };

    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    //const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    //const [loading, setLoading] = React.useState(false);
    const [hoarding, setHoarding] = React.useState([]);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setBrandname(data);
            setShowroomnames(data);
            setVendor(data);
            setStatus(data);
            setHoarding(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts

            setStatus([]);
            setShowroomnames([]);
            setBrandname([]);
            setVendor([]);
            setHoarding([]);
        };
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get(OutletMediaListapi, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}`
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setHoarding(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    // const [searchQuery, setSearchQuery] = useState('');
    // const [filteredShowrooms, setFilteredShowrooms] = useState(showroomnames);

    // const handleSearchInputChange = (event) => {
    //     const query = event.target.value;
    //     setSearchQuery(query);

    //     const filteredResults = showroomnames.filter((item) => item.name.toLowerCase().includes(query.toLowerCase()));
    //     setFilteredShowrooms(filteredResults);
    // };

    // If no search query, display all data
    //const showroomsToDisplay = searchQuery ? filteredShowrooms : showroomnames;

    const itemsPerPage = 12;
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const [showGrid, setShowGrid] = useState(true);

    const handleSearchInputChange = (event) => {
        const query = event.target.value;
        setSearchQuery(query);
        setCurrentPage(1);
    };

    const handlePageChange = (event, page) => {
        setCurrentPage(page);
    };

    // Filter showrooms based on search query
    const filteredShowrooms = showroomnames.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()));

    const totalItems = filteredShowrooms.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const showroomsToDisplay = filteredShowrooms.slice(startIndex, endIndex);

    const handleToggleDisplay = () => {
        setShowGrid((prevShowGrid) => !prevShowGrid);
    };

    const isSmallScreen = useMediaQuery('(max-width:600px)');

    const statusOptions = ['Active', 'Expired', 'Empty Space', 'On Brand Escalation'];
    const brandOptions = ['Apple', 'Samsung', 'LG', 'Sony', 'Haier'];
    const asmOptions = ['Lalitha', 'Ramkumar', 'Rajeshwari', 'Alex', 'Clara', 'Sebastin.A'];
    const storeStatusOptions = ['Active stores', 'Closed stores'];

    const [selectedStatus, setSelectedStatus] = useState([]);
    const [selectedBrands, setSelectedBrands] = useState([]);
    const [selectedASMs, setSelectedASMs] = useState([]);
    const [selectedStoreStatus, setSelectedStoreStatus] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [sortBy, setSortBy] = useState('name');
    const [sortOrder, setSortOrder] = useState('asc');

    const handleResetFilters = () => {
        setSelectedStatus([]);
        setSelectedBrands([]);
        setSelectedASMs([]);
        setSelectedStoreStatus([]);
        setSearchText('');
    };

    const handleStatusChipClick = (option) => {
        if (selectedStatus.includes(option)) {
            setSelectedStatus(selectedStatus.filter((filter) => filter !== option));
        } else {
            setSelectedStatus([...selectedStatus, option]);
        }
    };

    const handleBrandChipClick = (option) => {
        if (selectedBrands.includes(option)) {
            setSelectedBrands(selectedBrands.filter((filter) => filter !== option));
        } else {
            setSelectedBrands([...selectedBrands, option]);
        }
    };

    const handleASMChipClick = (option) => {
        if (selectedASMs.includes(option)) {
            setSelectedASMs(selectedASMs.filter((filter) => filter !== option));
        } else {
            setSelectedASMs([...selectedASMs, option]);
        }
    };

    const handleStoreStatusChipClick = (option) => {
        if (selectedStoreStatus.includes(option)) {
            setSelectedStoreStatus(selectedStoreStatus.filter((filter) => filter !== option));
        } else {
            setSelectedStoreStatus([...selectedStoreStatus, option]);
        }
    };

    const handleSearchTextChange = (event) => {
        setSearchText(event.target.value);
    };

    const handleSortByChipClick = (option) => {
        setSortBy(option);
    };

    // const handleSortOrderToggle = () => {
    //     setSortOrder((prevOrder) => (prevOrder === 'asc' ? 'desc' : 'asc'));
    // };
    const handleSortOrderToggle = () => {
        setSortOrder((prevOrder) => (prevOrder === 'asc' ? 'desc' : 'asc'));
    };

    // Sample data array
    // const data = [
    //     {
    //         id: 1,
    //         name: 'John Doe',
    //         asm: 'ASM1',
    //         status: 'Active',
    //         brand: 'Brand1',
    //         storeStatus: 'Active stores'
    //     },
    //     {
    //         id: 2,
    //         name: 'Jane Smith',
    //         asm: 'ASM2',
    //         status: 'Inactive',
    //         brand: 'Brand2',
    //         storeStatus: 'Closed stores'
    //     },
    //     {
    //         id: 3,
    //         name: 'Bob Johnson',
    //         asm: 'ASM1',
    //         status: 'Pending',
    //         brand: 'Brand3',
    //         storeStatus: 'Active stores'
    //     }
    //     // ... additional data objects
    // ];
    const data = [
        {
            id: 1,
            name: 'TN-EKTL',
            asm: 'Lalitha',
            status: 'Active',
            brand: 'Apple',
            storeStatus: 'Active stores',
            dob: '22-07-2017'
        },
        {
            id: 2,
            name: 'TN-Porur',
            asm: 'Ramkumar',
            status: 'Expired',
            brand: 'Samsung',
            storeStatus: 'Closed stores',
            dob: '22-07-2017'
        },
        {
            id: 3,
            name: 'TN-Poonamallee',
            asm: 'Rajeshwari',
            status: 'Empty Space',
            brand: 'LG',
            storeStatus: 'Active stores',
            dob: '22-07-2017'
        }
        // ... additional data objects
    ];

    // Filtered and sorted data based on selected filters
    const filteredData = data
        .filter((item) => {
            const matchesStatus = selectedStatus.length === 0 || selectedStatus.includes(item.status);
            const matchesBrand = selectedBrands.length === 0 || selectedBrands.includes(item.brand);
            const matchesASM = selectedASMs.length === 0 || selectedASMs.includes(item.asm);
            const matchesStoreStatus = selectedStoreStatus.length === 0 || selectedStoreStatus.includes(item.storeStatus);
            const matchesSearchText =
                searchText === '' ||
                item.brand.toLowerCase().includes(searchText.toLowerCase()) ||
                item.asm.toLowerCase().includes(searchText.toLowerCase()) ||
                item.status.toLowerCase().includes(searchText.toLowerCase());

            return matchesStatus && matchesBrand && matchesASM && matchesStoreStatus && matchesSearchText;
        })
        .sort((a, b) => {
            // Sorting logic based on selected sort option and order
            if (sortBy === 'id') {
                if (sortOrder === 'asc') {
                    return a.id - b.id;
                } else {
                    return b.id - a.id;
                }
            } else {
                const compareResult = a[sortBy].localeCompare(b[sortBy]);
                return sortOrder === 'asc' ? compareResult : -compareResult;
            }
        });
    return (
        <>
            {' '}
            <Box sx={{ m: isMobile ? -2 : 0 }}>
                {responseMessage &&
                    Swal.fire({
                        title: 'success',
                        text: responseMessage,
                        icon: 'success',
                        confirmButtonText: 'OK'
                        //onClose: handleClose
                    })}
                <ApiComponent apiUrl={OutletMediaListapi} onDataFetched={setHoarding} />
                <ApiComponent apiUrl={Brandapi} onDataFetched={setBrandname} />
                <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
                <ApiComponent apiUrl={Statusapi} onDataFetched={setStatus} />
                <ApiComponent apiUrl={Vendorapi} onDataFetched={setVendor} />
                {/* <Assetfilter /> */}

                <Card sx={{ width: '100%', boxShadow: 0 }}>
                    <Box
                        display="flex"
                        //direction={{ sm: 'column', md: 'row' }}
                        alignItems="center"
                        justifyContent="space-between"
                        sx={{
                            //pb: 1,
                            padding: 1
                        }}
                    >
                        <List>
                            <ListItem>
                                {/* <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar> */}
                                <ListItemText>
                                    {' '}
                                    <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 18 : 22 }}>
                                        Store Wise Assets List
                                    </Typography>
                                </ListItemText>
                            </ListItem>
                        </List>

                        <Box sx={{ '& > :not(style)': { m: 1 } }}>
                            <ToggleButtonGroup
                                exclusive
                                value={showGrid ? 'watch_list_columns' : 'watch_list_rows'}
                                onChange={handleToggleDisplay}
                                aria-label="Display"
                            >
                                <ToggleButton disableRipple value="watch_list_columns">
                                    <ViewWeekTwoToneIcon />
                                </ToggleButton>
                                <ToggleButton disableRipple value="watch_list_rows">
                                    <TableRowsTwoToneIcon />
                                </ToggleButton>
                            </ToggleButtonGroup>
                            {/* <TextField
                                // type="text"
                                value={searchQuery}
                                onChange={handleSearchInputChange}
                                placeholder="Search Store name.."
                                id="outlined-search"
                                label="Search"
                                //fullWidth
                                type="search"
                                //size="small"
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <SearchIcon />
                                        </InputAdornment>
                                    )
                                }}
                            /> */}
                            {/* <Fab color="primary" aria-label="add">
                                <AddIcon />
                            </Fab>
                            <Fab color="primary" aria-label="add">
                                <AddIcon />
                            </Fab> */}
                        </Box>
                        {/* <ToggleButtonGroup exclusive>
                        <ToggleButton disableRipple value="watch_list_columns" onClick={handleToggleDisplay}>
                            <ViewWeekTwoToneIcon />
                        </ToggleButton>
                        <ToggleButton disableRipple value="watch_list_rows">
                            <TableRowsTwoToneIcon />
                        </ToggleButton>
                    </ToggleButtonGroup> */}
                    </Box>
                </Card>

                <Card sx={{ width: '100%', boxShadow: 0, backgroundColor: 'transparent' }}>
                    <Box
                        display="flex"
                        //direction={{ sm: 'column', md: 'row' }}
                        alignItems="center"
                        justifyContent={{ sm: 'center', xs: 'center', md: 'flex-end', lg: 'flex-end' }}
                        //maxWidth="xl"
                        sx={{
                            //pb: 1,
                            padding: 1
                            //mt: -4
                        }}
                    >
                        {' '}
                        <TextField
                            // type="text"
                            value={searchQuery}
                            onChange={handleSearchInputChange}
                            placeholder="Search Store name.."
                            id="outlined-search"
                            label="Search"
                            //fullWidth
                            type="search"
                            //size="small"
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <SearchIcon />
                                    </InputAdornment>
                                )
                            }}
                            //sx={{ borderColor: '1px solid black' }}
                        />
                    </Box>
                </Card>
                {/* <Grid container spacing={1} justifyContent="center" alignItems="center">
                    <Grid item xs={10} sm={10} md={10} lg={8}>
                        <Card sx={{ width: '100%', boxShadow: 0, p: 1, mt: -1, borderBottomLeftRadius: 2, borderBottomRightRadius: 2 }}>
                            <Stack
                                direction={{ xs: 'column', sm: 'row' }}
                                justifyContent="space-between"
                                // alignItems="center"
                                //justifyContent="flex-start"
                                alignItems="center"
                                spacing={2}
                                sx={{ padding: 0 }}
                                //divider={<Divider orientation="vertical" flexItem />}
                            >
                                <TextField
                                    // type="text"
                                    value={searchQuery}
                                    onChange={handleSearchInputChange}
                                    placeholder="Search Store name.."
                                    id="outlined-search"
                                    label="Search"
                                    //fullWidth
                                    type="search"
                                    //size="small"
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="end">
                                                <SearchIcon />
                                            </InputAdornment>
                                        )
                                    }}
                                />
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                    // //onClick={handleOpen}
                                    // href="/hoardingform"
                                    //onClick={handleOpen}
                                    startIcon={<AddCircleOutlineOutlinedIcon />}
                                >
                                    Add
                                </Button>
                            </Stack>
                        </Card>
                    </Grid>
                </Grid> */}
                {/* <Card sx={{ width: '100%', boxShadow: 0 }}>
                    <Stack
                        direction={{ xs: 'column', sm: 'row' }}
                        justifyContent="space-between"
                        // alignItems="center"
                        //justifyContent="flex-start"
                        alignItems="center"
                        spacing={2}
                        sx={{ padding: 1 }}
                        divider={<Divider orientation="vertical" flexItem />}
                    >
                        <List>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                        <StoreOutlinedIcon sx={{ color: 'white' }} />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    {' '}
                                    <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 18 : 22 }}>
                                        Store Wise Assets List
                                    </Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        <TextField
                            // type="text"
                            value={searchQuery}
                            onChange={handleSearchInputChange}
                            placeholder="Search Store name.."
                            id="outlined-search"
                            label="Search"
                            type="search"
                            //size="small"
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <SearchIcon />
                                    </InputAdornment>
                                )
                            }}
                        />
                        <div>
                            <IconButton
                                onClick={handleToggleDisplay}
                                //size="large"
                                //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                            >
                                {showGrid ? <TableChartIcon /> : <ViewModuleIcon />}
                            </IconButton>
                            <IconButton
                                onClick={handleToggleDisplay}
                                //size="large"
                                //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                            >
                                {showGrid ? <TableChartIcon /> : <ViewModuleIcon />}
                            </IconButton>
                        </div>
                        <Button
                            className={classes.Button}
                            variant="contained"
                            sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                            // //onClick={handleOpen}
                            // href="/hoardingform"
                            //onClick={handleOpen}
                            startIcon={<AddCircleOutlineOutlinedIcon />}
                        >
                            Add
                        </Button>
                    </Stack>
                </Card> */}

                <Grid container spacing={1} direction="row">
                    <Grid item xs={12} sm={6} md={6} lg={4}>
                        <Link href="/assetstatus" underline="none" sx={{ textTransform: 'none' }}>
                            <CardStyle>
                                <CardContent>
                                    <Grid container direction="column" spacing={1}>
                                        <Grid item>
                                            <Typography variant="h4">TN-EKTL</Typography>
                                        </Grid>
                                        <Grid container spacing={0} direction="row" sx={{ mt: 0, p: 2 }}>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                    <span>DOB :</span> <span style={{ color: '#bfbfbf' }}>13-05-2015</span>
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ whiteSpace: 'nowrap', overflow: 'hidden', fontSize: isMobile ? 13 : 14 }}
                                                >
                                                    <span style={{}}>ASM :</span> <span style={{ color: '#bfbfbf' }}>Marimuthu</span>
                                                </Typography>
                                            </Grid>
                                        </Grid>

                                        <Grid container spacing={0} direction="row" sx={{ mt: 1 }}>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<PlaylistAddCheckCircleIcon fontSize="medium" color="info" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<CheckCircle fontSize="small" color="success" />}
                                                    label="4"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<UnpublishedIcon fontSize="small" color="error" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<TripOriginIcon fontSize="small" color="primary" />}
                                                    label="16"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </CardContent>
                            </CardStyle>
                        </Link>
                    </Grid>
                    <Grid item xs={12} sm={6} md={6} lg={4}>
                        <Link href="/assetstatus" underline="none" sx={{ textTransform: 'none' }}>
                            <CardStyle>
                                <CardContent>
                                    <Grid container direction="column" spacing={2}>
                                        <Grid item>
                                            <Typography variant="h4">TN-EKTL</Typography>
                                        </Grid>
                                        <Grid container spacing={0} direction="row" sx={{ mt: 0, p: 2 }}>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                    <span>DOB :</span> <span style={{ color: '#bfbfbf' }}>13-05-2015</span>
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ whiteSpace: 'nowrap', overflow: 'hidden', fontSize: isMobile ? 13 : 14 }}
                                                >
                                                    <span style={{}}>ASM :</span> <span style={{ color: '#bfbfbf' }}>Marimuthu</span>
                                                </Typography>
                                            </Grid>
                                        </Grid>

                                        <Grid container spacing={0} direction="row" sx={{ mt: 1 }}>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<PlaylistAddCheckCircleIcon fontSize="medium" color="info" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<CheckCircle fontSize="small" color="success" />}
                                                    label="4"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<UnpublishedIcon fontSize="small" color="error" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<TripOriginIcon fontSize="small" color="primary" />}
                                                    label="16"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </CardContent>
                            </CardStyle>
                        </Link>
                    </Grid>
                    <Grid item xs={12} sm={6} md={6} lg={4}>
                        <Link href="/assetstatus" underline="none" sx={{ textTransform: 'none' }}>
                            <CardStyle>
                                <CardContent>
                                    <Grid container direction="column" spacing={2}>
                                        <Grid item>
                                            <Typography variant="h4">TN-EKTL</Typography>
                                        </Grid>
                                        <Grid container spacing={0} direction="row" sx={{ mt: 0, p: 2 }}>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                    <span>DOB :</span> <span style={{ color: '#bfbfbf' }}>13-05-2015</span>
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ whiteSpace: 'nowrap', overflow: 'hidden', fontSize: isMobile ? 13 : 14 }}
                                                >
                                                    <span style={{}}>ASM :</span> <span style={{ color: '#bfbfbf' }}>Marimuthu</span>
                                                </Typography>
                                            </Grid>
                                        </Grid>

                                        <Grid container spacing={0} direction="row" sx={{ mt: 1 }}>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<PlaylistAddCheckCircleIcon fontSize="medium" color="info" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<CheckCircle fontSize="small" color="success" />}
                                                    label="4"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<UnpublishedIcon fontSize="small" color="error" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<TripOriginIcon fontSize="small" color="primary" />}
                                                    label="16"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </CardContent>
                            </CardStyle>
                        </Link>
                    </Grid>
                    <Grid item xs={12} sm={6} md={6} lg={4}>
                        <Link href="/assetstatus" underline="none" sx={{ textTransform: 'none' }}>
                            <CardStyle>
                                <CardContent>
                                    <Grid container direction="column" spacing={2}>
                                        <Grid item>
                                            <Typography variant="h4">TN-EKTL</Typography>
                                        </Grid>
                                        <Grid container spacing={0} direction="row" sx={{ mt: 0, p: 2 }}>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                    <span>DOB :</span> <span style={{ color: '#bfbfbf' }}>13-05-2015</span>
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={12} md={12} xl={6}>
                                                <Typography
                                                    variant="subtitle1"
                                                    sx={{ whiteSpace: 'nowrap', overflow: 'hidden', fontSize: isMobile ? 13 : 14 }}
                                                >
                                                    <span style={{}}>ASM :</span> <span style={{ color: '#bfbfbf' }}>Marimuthu</span>
                                                </Typography>
                                            </Grid>
                                        </Grid>

                                        <Grid container spacing={0} direction="row" sx={{ mt: 1 }}>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<PlaylistAddCheckCircleIcon fontSize="medium" color="info" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<CheckCircle fontSize="small" color="success" />}
                                                    label="4"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<UnpublishedIcon fontSize="small" color="error" />}
                                                    label="16"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                            <Grid item xs={3} sm={3} md={3} lg={3} key="">
                                                <Chip
                                                    icon={<TripOriginIcon fontSize="small" color="primary" />}
                                                    label="16"
                                                    //color="info"
                                                    sx={{ backgroundColor: 'transparent', border: '1px solid #ebebeb' }}
                                                />
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </CardContent>
                            </CardStyle>
                        </Link>
                    </Grid>
                </Grid>

                <br></br>
                {showGrid ? (
                    <Grid container spacing={1}>
                        {showroomsToDisplay.length > 0 ? (
                            showroomsToDisplay.map((item) => (
                                <Grid item xs={12} sm={6} md={6} lg={4} key={item.id}>
                                    <Link href="/assetstatus" underline="none" sx={{ textTransform: 'none' }}>
                                        <Card sx={{ width: '100%', my: 0, border: '1px solid #ebebeb' }}>
                                            <List>
                                                <ListItem>
                                                    <ListItemText>
                                                        {' '}
                                                        <Typography variant="h5" sx={{ color: '#ff8b3d', fontWeight: 'bold' }}>
                                                            {item.name}
                                                        </Typography>
                                                    </ListItemText>
                                                </ListItem>
                                            </List>
                                            <Card sx={{ boxShadow: 0, p: 2, borderTop: '1px solid #ebebeb' }}>
                                                <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                                    <Grid item xs={12} sm={12} md={12} lg={6} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>DOB :</span> <span style={{ color: '#bfbfbf' }}>13-05-2015</span>
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6} key="">
                                                        <Typography
                                                            variant="subtitle1"
                                                            sx={{ whiteSpace: 'nowrap', overflow: 'hidden', fontSize: isMobile ? 13 : 14 }}
                                                        >
                                                            <span style={{}}>ASM :</span>{' '}
                                                            <span style={{ color: '#bfbfbf' }}>{item.asm}</span>
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                                <Grid container spacing={0} direction="row" sx={{ mt: 1 }}>
                                                    <Grid item xs={6} sm={6} md={3} lg={3} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>Total :</span> <span style={{ color: '#bd742a' }}>16</span>
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={6} sm={6} md={3} lg={3} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>Active :</span> <span style={{ color: 'green' }}>4</span>
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={6} sm={6} md={3} lg={3} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>Expired :</span> <span style={{ color: 'red' }}>3</span>
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={6} sm={6} md={3} lg={3} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>Empty :</span> <span style={{ color: 'blue' }}>0</span>
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                            </Card>
                                        </Card>
                                    </Link>
                                </Grid>
                            ))
                        ) : (
                            <Card sx={{ width: '100%', boxShadow: 0, p: 3 }}>
                                <Stack
                                    direction={{ xs: 'column', sm: 'row' }}
                                    justifyContent="space-between"
                                    // alignItems="center"
                                    //justifyContent="flex-start"
                                    alignItems="center"
                                    spacing={2}
                                    sx={{ padding: 1 }}
                                >
                                    <div>
                                        <List>
                                            <ListItem>
                                                {/* <ListItemAvatar>
                                                    <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                                        <StoreOutlinedIcon sx={{ color: 'white' }} />
                                                    </Avatar>
                                                </ListItemAvatar> */}
                                                <ListItemText>
                                                    {' '}
                                                    <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 20 : 22 }}>
                                                        No Results Found.
                                                    </Typography>
                                                </ListItemText>
                                            </ListItem>
                                        </List>
                                    </div>
                                </Stack>
                            </Card>
                        )}
                        <br></br>
                        {totalItems > itemsPerPage && (
                            <Grid item sm={12} xs={12} md={12} lg={12} xl={12} mt={2}>
                                <Card sx={{ width: '100%', boxShadow: 0, p: 3 }}>
                                    <Stack direction="column" justifyContent="center" alignItems="center" spacing={1}>
                                        <Pagination
                                            count={totalPages}
                                            page={currentPage}
                                            onChange={handlePageChange}
                                            shape="rounded"
                                            color="secondary"
                                            renderItem={(item) => (
                                                <PaginationItem
                                                    slots={{ previous: ArrowLeftOutlinedIcon, next: ArrowRightOutlinedIcon }}
                                                    {...item}
                                                />
                                            )}
                                        />
                                    </Stack>
                                </Card>
                            </Grid>
                        )}
                    </Grid>
                ) : (
                    <Box>
                        {' '}
                        {/* <TableContainer component={Paper} className={classes.tableContainer}>
                            <Table striped size={isMobile ? 'small' : 'medium'} aria-label="Showroom Table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell style={{ border: '1px solid #ccc' }}>Showroom</TableCell>
                                        <TableCell style={{ border: '1px solid #ccc' }}>Total</TableCell>
                                        <TableCell style={{ border: '1px solid #ccc' }}>Active</TableCell>
                                        <TableCell style={{ border: '1px solid #ccc' }}>Expired</TableCell>
                                        <TableCell style={{ border: '1px solid #ccc' }}>Empty</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {showroomsToDisplay.map((row) => (
                                        <TableRow key={row.name}>
                                            <TableCell component="th" scope="row" style={{ border: '1px solid #ccc' }}>
                                                <Link href={`/showroom/${row.name}`} underline="none">
                                                    {row.name}
                                                </Link>
                                            </TableCell>
                                            <TableCell style={{ border: '1px solid #ccc' }}>{row.total}</TableCell>
                                            <TableCell style={{ border: '1px solid #ccc' }}>{row.active}</TableCell>
                                            <TableCell style={{ border: '1px solid #ccc' }}>{row.expired}</TableCell>
                                            <TableCell style={{ border: '1px solid #ccc' }}>{row.empty}</TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer> */}
                        <Card sx={{ boxShadow: 0 }}>
                            <Box
                                //id="invoice-container"
                                height="60vh"
                                width="100%"
                                fontWeight={10}
                                //className={classes.customButton}
                                sx={{
                                    //width: '100%',
                                    //border: '2px solid #fff2ea',
                                    //p: 2,

                                    height: isSmallScreen ? '90vh' : '60vh',
                                    width: '100%',
                                    borderRadius: 5,
                                    '& .MuiDataGrid-root': {
                                        border: 'none',
                                        padding: 1
                                        //border: '2px dashed grey'
                                    },
                                    '& .super-app-theme--header': {
                                        //backgroundColor: 'rgba(255, 7, 0, 0.55)',
                                        //color: 'orange !important',
                                        //fontWeight: 'bold !important'
                                        //fontWeight: '700 !important',
                                        //color: 'white !important'
                                    },
                                    '& .super-app-theme--cell': {
                                        //backgroundColor: 'primary',
                                        //color: '#1a3e72 !important',
                                        //fontWeight: '600 !important',
                                        //border: 1
                                    },
                                    '& .MuiDataGrid-cell': {
                                        //borderBottom: 'none !important',
                                        //backgroundColor: '#f2f2f2',
                                        color: 'black',
                                        fontWeight: '550 !important'
                                    },
                                    '& .name-column--cell': {
                                        variant: 'button',
                                        fontWeight: 'medium',
                                        color: 'ButtonText'
                                    },
                                    '& .MuiDataGrid-columnHeaders': {
                                        //borderLeft: '2px dashed grey',
                                        //borderRight: '2px dashed grey',
                                        //borderBottom: '2px solid grey',
                                        //fontWeight: 'bold !important',
                                        //fontWeight: '700 !important',
                                        //fontSize: 15,
                                        //fontColor: 'red'
                                        //backgroundColor: '#ff874b',
                                        //borderRadius: 2
                                        //color: 'white !important'
                                    },

                                    '.MuiDataGrid-columnHeaderTitle': {
                                        //fontWeight: 'bold !important',
                                        //fontWeight: '1000 !important',
                                        //overflow: 'visible !important',
                                        color: 'white',
                                        width: 'auto',
                                        paddingTop: '12px',
                                        paddingBottom: '10px',
                                        //paddingLeft: "8px",
                                        //paddingRight: "24px",
                                        textAlign: 'left',
                                        fontSize: '0.80rem',
                                        fontWeight: 700,
                                        opacity: 0.7,
                                        background: 'transparent',
                                        color: '#8392ab',
                                        borderRadius: 'none',
                                        borderBottom: '0.0625rem solid #e9ecef'
                                        //fontSize: 15
                                    },
                                    '& .MuiDataGrid-virtualScroller': {
                                        //opacity: 1,
                                        //transition: 'opacity 0.2s',
                                        //overflowY: 'auto',
                                        overflowX: 'auto',
                                        '&::-webkit-scrollbar': {
                                            width: '4px',
                                            backgroundColor: '#F5F5F5'
                                        },
                                        '&::-webkit-scrollbar-thumb': {
                                            //backgroundColor: '#11cdef',
                                            borderRadius: '4px'
                                        }
                                    },
                                    '& .MuiDataGrid-footerContainer': {
                                        color: '#8392ab',
                                        border: 'none'
                                    },
                                    '& .MuiDataGrid-columnSeparator': {
                                        visibility: 'hidden'
                                    },
                                    '&.MuiDataGrid-pagination': {
                                        //backgroundColor: "red",
                                        //padding: "10px",
                                        width: '20px !important'
                                    },

                                    '&.MuiDataGrid-virtualScroller': {
                                        opacity: 0,
                                        transition: 'opacity 0.2s'
                                    },
                                    '&.MuiTablePagination-root': {
                                        width: '20px'
                                    },

                                    '&.MuiDataGrid-virtualScroller:hover': {
                                        opacity: 1
                                    },
                                    '& .MuiTablePagination-select': {
                                        //paddingRight: 2,
                                        width: '10px !important'
                                    },
                                    '& .MuiTablePagination-selectIcon': {
                                        display: 'none'
                                    },

                                    '&.MuiDataGrid-toolbar .MuiDataGrid-menuList': {
                                        padding: 0
                                    },

                                    '& .MuiDataGrid-toolbar .MuiButtonBase-root': {
                                        fontSize: '14px',
                                        color: '#333'
                                    },

                                    '& .MuiDataGrid-toolbar .MuiButtonBase-root:hover': {
                                        backgroundColor: '#f0f0f0'
                                    }
                                }}
                            >
                                <DataGrid
                                    rows={dummydata}
                                    columns={columns1}
                                    pagination={false}
                                    pageSize={itemsPerPage}
                                    getRowClassName={rowClassName}
                                    //rowCount={filteredShowrooms.length}
                                    //page={currentPage - 1}
                                    //onPageChange={(params) => setCurrentPage(params.page + 1)}
                                    //disablePagination
                                    disableSelectionOnClick
                                />
                            </Box>
                        </Card>
                    </Box>
                )}
                <div>
                    <br></br>
                    <Card sx={{ width: '100%', boxShadow: 0 }}>
                        <Box
                            display="flex"
                            alignItems="center"
                            justifyContent="space-between"
                            sx={{
                                //pb: 1,
                                padding: 1
                            }}
                        >
                            <List>
                                <ListItem>
                                    {/* <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar> */}
                                    <ListItemText>
                                        {' '}
                                        <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 18 : 22 }}>
                                            Store Wise Assets List with filter (sample data)
                                        </Typography>
                                    </ListItemText>
                                </ListItem>
                            </List>
                            <Chip
                                //label={`Sort Order: ${sortOrder}`}
                                label={sortOrder === 'asc' ? 'A to Z' : 'Z to A'}
                                onClick={handleSortOrderToggle}
                                color="primary"
                                variant="outlined"
                                icon={sortOrder === 'asc' ? <ArrowUpward /> : <ArrowDownward />}
                            />
                            <TextField
                                value={searchText}
                                onChange={handleSearchTextChange}
                                label="Search"
                                variant="outlined"
                                margin="dense"
                            />

                            {/* <ToggleButtonGroup
                                exclusive
                                value={showGrid ? 'watch_list_columns' : 'watch_list_rows'}
                                onChange={handleToggleDisplay}
                                aria-label="Display"
                            >
                                <ToggleButton disableRipple value="watch_list_columns">
                                    <ViewWeekTwoToneIcon />
                                </ToggleButton>
                                <ToggleButton disableRipple value="watch_list_rows">
                                    <TableRowsTwoToneIcon />
                                </ToggleButton>
                            </ToggleButtonGroup> */}

                            {/* <ToggleButtonGroup exclusive>
                        <ToggleButton disableRipple value="watch_list_columns" onClick={handleToggleDisplay}>
                            <ViewWeekTwoToneIcon />
                        </ToggleButton>
                        <ToggleButton disableRipple value="watch_list_rows">
                            <TableRowsTwoToneIcon />
                        </ToggleButton>
                    </ToggleButtonGroup> */}
                        </Box>
                        <Accordion>
                            <AccordionSummary expandIcon={<ExpandMoreIcon />} aria-controls="panel1a-content" id="panel1a-header">
                                <Typography>Search by Filter</Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                                <Grid container spacing={1}>
                                    <Grid item xs={12} sm={12} md={6} lg={6}>
                                        {' '}
                                        <h3>Status:</h3>
                                        {statusOptions.map((option) => (
                                            <Chip
                                                key={option}
                                                label={option}
                                                onClick={() => handleStatusChipClick(option)}
                                                color={selectedStatus.includes(option) ? 'primary' : 'default'}
                                                variant={selectedStatus.includes(option) ? 'filled' : 'outlined'}
                                            />
                                        ))}
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={6}>
                                        <h3>Brand:</h3>
                                        {brandOptions.map((option) => (
                                            <Chip
                                                key={option}
                                                label={option}
                                                onClick={() => handleBrandChipClick(option)}
                                                color={selectedBrands.includes(option) ? 'primary' : 'default'}
                                                variant={selectedBrands.includes(option) ? 'filled' : 'outlined'}
                                            />
                                        ))}
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={6}>
                                        <h3>ASM:</h3>
                                        {asmOptions.map((option) => (
                                            <Chip
                                                key={option}
                                                label={option}
                                                onClick={() => handleASMChipClick(option)}
                                                color={selectedASMs.includes(option) ? 'primary' : 'default'}
                                                variant={selectedASMs.includes(option) ? 'filled' : 'outlined'}
                                            />
                                        ))}
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={6}>
                                        <h3>Store Status:</h3>
                                        {storeStatusOptions.map((option) => (
                                            <Chip
                                                key={option}
                                                label={option}
                                                onClick={() => handleStoreStatusChipClick(option)}
                                                color={selectedStoreStatus.includes(option) ? 'primary' : 'default'}
                                                variant={selectedStoreStatus.includes(option) ? 'filled' : 'outlined'}
                                            />
                                        ))}
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={6}>
                                        <h3>Sort By:</h3>
                                        <div>
                                            {['name', 'asm', 'status', 'brand', 'storeStatus', 'id'].map((option) => (
                                                <Chip
                                                    key={option}
                                                    label={option}
                                                    onClick={() => handleSortByChipClick(option)}
                                                    color={sortBy === option ? 'primary' : 'default'}
                                                    variant={sortBy === option ? 'filled' : 'outlined'}
                                                />
                                            ))}
                                        </div>
                                    </Grid>
                                    <Grid item xs={12} sm={12} md={6} lg={6}>
                                        <br></br>
                                        <Button variant="outlined" onClick={handleResetFilters} size="small">
                                            Reset
                                        </Button>
                                    </Grid>
                                </Grid>
                            </AccordionDetails>
                        </Accordion>
                    </Card>

                    <br></br>
                    <Grid container spacing={1}>
                        {filteredData.length > 0 ? (
                            filteredData.map((item) => (
                                <Grid item xs={12} sm={6} md={6} lg={4} key={item.id}>
                                    <Link href="/assetstatus" underline="none" sx={{ textTransform: 'none' }}>
                                        <Card sx={{ width: '100%', my: 0, border: '1px solid #ebebeb' }}>
                                            <List>
                                                <ListItem>
                                                    {/* <ListItemAvatar>
                                            <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                                <StoreOutlinedIcon sx={{ color: 'white' }} />
                                            </Avatar>
                                        </ListItemAvatar> */}
                                                    <ListItemText>
                                                        {' '}
                                                        <Typography variant="h5" sx={{ color: '#ff8b3d', fontWeight: 'bold' }}>
                                                            {item.name}
                                                        </Typography>
                                                    </ListItemText>
                                                </ListItem>
                                            </List>
                                            <Card sx={{ boxShadow: 0, p: 2, borderTop: '1px solid #ebebeb' }}>
                                                {/* <Grid container spacing={2} direction="row">
                                        <Grid item xs={12} sm={12} md={12} lg={12} key="">
                                            <Typography variant="h5" sx={{ color: '#ff8b3d', fontWeight: 'bold' }}>
                                                {item.name}
                                            </Typography>
                                        </Grid>
                                    </Grid> */}
                                                <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                                    <Grid item xs={12} sm={12} md={12} lg={6} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>DOB :</span> <span style={{ color: '#bfbfbf' }}>{item.dob}</span>
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6} key="">
                                                        <Typography
                                                            variant="subtitle1"
                                                            sx={{
                                                                whiteSpace: 'nowrap',
                                                                overflow: 'hidden',
                                                                fontSize: isMobile ? 13 : 14
                                                            }}
                                                        >
                                                            <span style={{}}>ASM :</span>{' '}
                                                            <span style={{ color: '#bfbfbf' }}>{item.asm}</span>
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                                <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                                    <Grid item xs={12} sm={12} md={12} lg={6} key="">
                                                        <Typography variant="subtitle1" sx={{ fontSize: isMobile ? 13 : 14 }}>
                                                            <span>Status :</span> <span style={{ color: '#bfbfbf' }}>{item.status}</span>
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={12} sm={12} md={12} lg={6} key="">
                                                        <Typography
                                                            variant="subtitle1"
                                                            sx={{
                                                                whiteSpace: 'nowrap',
                                                                overflow: 'hidden',
                                                                fontSize: isMobile ? 13 : 14
                                                            }}
                                                        >
                                                            <span style={{}}>Brand :</span>{' '}
                                                            <span style={{ color: '#bfbfbf' }}>{item.brand}</span>
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                            </Card>
                                        </Card>
                                    </Link>
                                </Grid>
                            ))
                        ) : (
                            <Card sx={{ width: '100%', boxShadow: 0, p: 3 }}>
                                <Stack
                                    direction={{ xs: 'column', sm: 'row' }}
                                    justifyContent="space-between"
                                    // alignItems="center"
                                    //justifyContent="flex-start"
                                    alignItems="center"
                                    spacing={2}
                                    sx={{ padding: 1 }}
                                >
                                    <div>
                                        <List>
                                            <ListItem>
                                                {/* <ListItemAvatar>
                                                    <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                                        <StoreOutlinedIcon sx={{ color: 'white' }} />
                                                    </Avatar>
                                                </ListItemAvatar> */}
                                                <ListItemText>
                                                    {' '}
                                                    <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 20 : 22 }}>
                                                        No Results Found.
                                                    </Typography>
                                                </ListItemText>
                                            </ListItem>
                                        </List>
                                    </div>
                                </Stack>
                            </Card>
                        )}
                        <br></br>
                        {totalItems > itemsPerPage && (
                            <Grid item sm={12} xs={12} md={12} lg={12} xl={12} mt={2}>
                                <Card sx={{ width: '100%', boxShadow: 0, p: 3 }}>
                                    <Stack direction="column" justifyContent="center" alignItems="center" spacing={1}>
                                        <Pagination
                                            count={totalPages}
                                            page={currentPage}
                                            onChange={handlePageChange}
                                            shape="rounded"
                                            color="secondary"
                                            renderItem={(item) => (
                                                <PaginationItem
                                                    slots={{ previous: ArrowLeftOutlinedIcon, next: ArrowRightOutlinedIcon }}
                                                    {...item}
                                                />
                                            )}
                                        />
                                    </Stack>
                                </Card>
                            </Grid>
                        )}
                    </Grid>
                    <Fab color="primary" aria-label="add" size="medium" className="fab-button" href="/addad">
                        <AddIcon sx={{ color: 'white' }} />
                    </Fab>
                    {/* <ul>
                        {filteredData.map((item) => (
                            <li key={item.id}>
                                <div>Name: {item.name}</div>
                                <div>ASM: {item.asm}</div>
                                <div>Status: {item.status}</div>
                                <div>Brand: {item.brand}</div>
                                <div>DOB: {item.storeStatus}</div>
                                <div>ID: {item.id}</div>
                            </li>
                        ))}
                    </ul> */}
                </div>
            </Box>
        </>
    );
}

export default withAuth(DataTable);
