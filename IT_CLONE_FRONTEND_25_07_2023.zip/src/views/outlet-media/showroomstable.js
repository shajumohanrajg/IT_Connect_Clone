import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';
import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
// eslint-disable-next-line prettier/prettier
import { Avatar, Box, Button, Card, Grid, List, ListItem, ListItemAvatar, ListItemText, Modal, Stack, TextField, Typography } from '@mui/material';
import { IconButton, useMediaQuery } from '@mui/material';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { GridToolbar } from '@mui/x-data-grid';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

//import { useNavigate } from 'react-router-dom';

import ApiComponent from '../apicomp/ApiComponent';
import { Showroomapi } from '../apicomp/Apiurls';
import CustomDataGrid from '../customdatagrid/CustomDataGrid';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';

function DataTable() {
    //const navigate = useNavigate();

    const columns1 = [
        {
            field: 'name',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'Showroom Name',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header',
            //flex: 0.2
            width: 200
            // cellClassName: "name-column--cell",
        },
        {
            field: 'rsm',
            headerName: 'Rsm',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'asm',
            headerName: 'Asm',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'manager',
            headerName: 'Manager',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'cug_no',
            headerName: 'Cug No',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'landline',
            headerName: 'Landline',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'e_mail',
            headerName: 'Email',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'region',
            headerName: 'Region',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'state',
            headerName: 'State',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            headerName: 'Actions',
            field: 'action',
            //flex: 1,
            width: 160,
            headerClassName: 'super-app-theme--header',
            renderCell: (params) => (
                <div>
                    <IconButton aria-label="view" size="large" onClick={() => viewShowrooms(params.id)}>
                        <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton aria-label="delete" size="large" onClick={() => handleDeleteSubmit(params.id)}>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </div>
            )
        }

        // {
        //     field: 'actions',
        //     headerName: 'Actions',
        //     width: 150,
        //     renderCell: (params) => (
        //         // <Button variant="outlined" onClick={() => handleEditClick(params.id)}>
        //         //     Edit
        //         // </Button>
        //         <IconButton aria-label="delete" size="large" onClick={() => handleEditClick(params.id)}>
        //             <EditIcon fontSize="small" />
        //         </IconButton>
        //     )
        // }
        // {
        //     headerName: 'Actions',
        //     field: 'action',
        //     flex: 1,
        //     headerClassName: 'super-app-theme--header',
        //     renderCell: (params) => (
        //         <div>
        //             <IconButton aria-label="delete" size="large" onClick={() => updateVendor(params.id)}>
        //                 <EditIcon fontSize="small" />
        //             </IconButton>

        //             {/* <IconButton aria-label="delete" color="error" size="large" onClick={() => deleteVendor(params.id)}>
        //                 <DeleteIcon fontSize="small" />
        //             </IconButton> */}
        //         </div>
        //     )
        // }
    ];

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${Showroomapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Showroom Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                //setLoading(false);
                // console.log("deleted",res)
                //enqueueSnackbar('Successfully deleted' , { variant:'success', anchorOrigin:{horizontal: 'right', vertical: 'top'} } );
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/showroomslistupdate/${id}`);
        window.location.reload();
    };
    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        Axios.put(`${Showroomapi}${selectedRowId}/`, matData, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                console.log('Data updated successfully:', response.data);
                setResponseMessage('SuccesssFully Showrooms Created');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                //console.log(response);
                // Perform any necessary actions after successful data update
            })
            .catch((error) => {
                console.log('Error updating data:', error);
                // Handle any errors that occur during the update process
            });
    };
    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const [matData, setMatData] = React.useState([
        {
            name: '',
            created_by: 1,
            modified_by: 1,

            rsm: '',
            asm: '',
            manager: '',
            cug_no: '',
            landline: '',
            e_mail: '',
            region: '',
            state: '',
            address: ''
        }
    ]);

    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${Showroomapi}${id}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                setMatData(data);
                setOpenModal(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const handleClose = () => {
        setSelectedRowId(null);
        setOpenModal(false);
    };
    const [name, setName] = useState('');
    const [status, setStatus] = useState(matData.status);

    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    // const [loading, setLoading] = React.useState(false);
    const [floordiadata, setFloordiadata] = React.useState([]);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setFloordiadata(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setFloordiadata([]);
        };
    }, []);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setFloordiadata(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <>
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <ApiComponent apiUrl={Showroomapi} onDataFetched={setFloordiadata} />
                <CustomDataGrid
                    isSmallScreen={true}
                    rows={floordiadata}
                    columns={columns1}
                    // Add any additional props you want to pass
                    //autoHeight={true}
                    //checkboxSelection={true}
                    //pageSize={10}
                    // ...and other available props
                    getRowId={(row) => row.id}
                    components={{ Toolbar: GridToolbar, color: 'primary' }}
                    componentsProps={{
                        toolbar: {
                            showQuickFilter: true,
                            quickFilterProps: { debounceMs: 500 },
                            color: 'primary'
                        }
                    }}
                    loading={loading}
                    //autoHeight
                    //scrollbarSize={100}
                    //pageSize={5}
                    //checkboxSelection
                    //touchRipple
                    //disableColumnMenu
                    // onRowClick={handleRowClick}
                    disableColumnFilter={isSmallScreen ? true : false}
                    disableDensitySelector={isSmallScreen ? true : false}
                    virtualization
                />
            </Card>
            <Modal open={!!selectedRowId} onClose={handleClose}>
                <Box sx={style}>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <List sx={{ width: '100%', maxWidth: 360 }}>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar className={classes.Button} sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                        <AddAPhotoOutlinedIcon />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    <Typography variant="h3">Update Showrooms #{selectedRowId}</Typography>
                                </ListItemText>
                            </ListItem>
                        </List>

                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Showroom Name"
                                id="name"
                                name="name"
                                value={matData.name || ''}
                                onChange={(e) => setMatData({ ...matData, name: e.target.value })}
                                // value={name}
                                // onChange={(e) => setName(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Rsm"
                                id="rsm"
                                name="rsm"
                                value={matData.rsm || ''}
                                onChange={(e) => setMatData({ ...matData, rsm: e.target.value })}
                                // value={rsm}
                                // onChange={(e) => setRsm(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Asm"
                                id="asm"
                                name="asm"
                                value={matData.asm || ''}
                                onChange={(e) => setMatData({ ...matData, asm: e.target.value })}
                                // value={asm}
                                // onChange={(e) => setAsm(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="CUG No"
                                id="cug_no"
                                name="cug_no"
                                value={matData.cug_no || ''}
                                onChange={(e) => setMatData({ ...matData, cug_no: e.target.value })}
                                // value={cug_no}
                                // onChange={(e) => setCugNo(e.target.value)}
                                fullWidth
                                type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Landline"
                                id="landline"
                                name="landline"
                                value={matData.landline || ''}
                                onChange={(e) => setMatData({ ...matData, landline: e.target.value })}
                                // value={landline}
                                // onChange={(e) => setLandline(e.target.value)}
                                fullWidth
                                type="tel"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Email"
                                id="e_mail"
                                name="e_mail"
                                value={matData.e_mail || ''}
                                onChange={(e) => setMatData({ ...matData, e_mail: e.target.value })}
                                // value={email}
                                // onChange={(e) => setEmail(e.target.value)}
                                fullWidth
                                type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Region"
                                id="region"
                                name="region"
                                value={matData.region || ''}
                                onChange={(e) => setMatData({ ...matData, region: e.target.value })}
                                // value={region}
                                // onChange={(e) => setRegion(e.target.value)}
                                fullWidth
                                //type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>

                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="State"
                                id="state"
                                name="state"
                                value={matData.state || ''}
                                onChange={(e) => setMatData({ ...matData, state: e.target.value })}
                                // value={state}
                                // onChange={(e) => setState(e.target.value)}
                                fullWidth
                                //type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Address"
                                id="address"
                                name="address"
                                value={matData.address || ''}
                                onChange={(e) => setMatData({ ...matData, address: e.target.value })}
                                // value={address}
                                // onChange={(e) => setAddress(e.target.value)}
                                fullWidth
                                multiline={4}
                                //type="email"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>

                        {/* <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                    onClick={handleSubmit}
                                    startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Add
                                </Button>
                            </Stack>
                        </Grid> */}

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    onClick={handleSubmit}
                                    //startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Update
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Modal>
            <Dialog
                open={openDialogdelete}
                onClose={handleCloseDialogdelete}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are you sure want to delete this id #{selectedRowIddel}? </DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure want to Delete this brand id #{selectedRowIddel}?
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialogdelete}>No</Button>
                    <Button onClick={deleteBrand}>Submit</Button>
                </DialogActions>
            </Dialog>

            <Dialog
                open={openDialog}
                onClose={handleCloseDialog}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are You Sure want to update this id data</DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure want to update this brand id #{selectedRowId}?
                    </DialogContentText>
                    {/* <DialogContentText id="alert-dialog-description">
            <Typography variant="h5">Are you sure want to update this brand id #{selectedRowId}? </Typography>
        </DialogContentText> */}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog}>No</Button>
                    <Button onClick={handleSubmit}>Submit</Button>
                </DialogActions>
            </Dialog>
        </>
    );
}

export default withAuth(DataTable);
