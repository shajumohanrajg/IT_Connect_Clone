import { ArrowDownward, ArrowUpward } from '@mui/icons-material';
import { Button, Chip, FormControl, InputLabel, MenuItem, Select, TextField } from '@mui/material';
import { useState } from 'react';

const YourComponent = () => {
    // Predefined options for status, brand, ASM, and storestatus filters
    const statusOptions = ['Active', 'Expired', 'Empty Space', 'On Brand Escalation'];
    const brandOptions = ['Apple', 'Samsung', 'LG', 'Sony', 'Haier'];
    const asmOptions = ['Lalitha', 'Ramkumar', 'Rajeshwari', 'Alex', 'Clara', 'Sebastin.A'];
    const storeStatusOptions = ['Active stores', 'Closed stores'];

    const [selectedStatus, setSelectedStatus] = useState([]);
    const [selectedBrands, setSelectedBrands] = useState([]);
    const [selectedASMs, setSelectedASMs] = useState([]);
    const [selectedStoreStatus, setSelectedStoreStatus] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [sortBy, setSortBy] = useState('name');
    const [sortOrder, setSortOrder] = useState('asc');

    const handleResetFilters = () => {
        setSelectedStatus([]);
        setSelectedBrands([]);
        setSelectedASMs([]);
        setSelectedStoreStatus([]);
        setSearchText('');
    };

    const handleStatusChipClick = (option) => {
        if (selectedStatus.includes(option)) {
            setSelectedStatus(selectedStatus.filter((filter) => filter !== option));
        } else {
            setSelectedStatus([...selectedStatus, option]);
        }
    };

    const handleBrandChipClick = (option) => {
        if (selectedBrands.includes(option)) {
            setSelectedBrands(selectedBrands.filter((filter) => filter !== option));
        } else {
            setSelectedBrands([...selectedBrands, option]);
        }
    };

    const handleASMChipClick = (option) => {
        if (selectedASMs.includes(option)) {
            setSelectedASMs(selectedASMs.filter((filter) => filter !== option));
        } else {
            setSelectedASMs([...selectedASMs, option]);
        }
    };

    const handleStoreStatusChipClick = (option) => {
        if (selectedStoreStatus.includes(option)) {
            setSelectedStoreStatus(selectedStoreStatus.filter((filter) => filter !== option));
        } else {
            setSelectedStoreStatus([...selectedStoreStatus, option]);
        }
    };

    const handleSearchTextChange = (event) => {
        setSearchText(event.target.value);
    };

    const handleSortByChipClick = (option) => {
        setSortBy(option);
    };

    // const handleSortOrderToggle = () => {
    //     setSortOrder((prevOrder) => (prevOrder === 'asc' ? 'desc' : 'asc'));
    // };
    const handleSortOrderToggle = () => {
        setSortOrder((prevOrder) => (prevOrder === 'asc' ? 'desc' : 'asc'));
    };

    // Sample data array
    // const data = [
    //     {
    //         id: 1,
    //         name: 'John Doe',
    //         asm: 'ASM1',
    //         status: 'Active',
    //         brand: 'Brand1',
    //         storeStatus: 'Active stores'
    //     },
    //     {
    //         id: 2,
    //         name: 'Jane Smith',
    //         asm: 'ASM2',
    //         status: 'Inactive',
    //         brand: 'Brand2',
    //         storeStatus: 'Closed stores'
    //     },
    //     {
    //         id: 3,
    //         name: 'Bob Johnson',
    //         asm: 'ASM1',
    //         status: 'Pending',
    //         brand: 'Brand3',
    //         storeStatus: 'Active stores'
    //     }
    //     // ... additional data objects
    // ];
    const data = [
        {
            id: 1,
            name: 'John Doe',
            asm: 'Lalitha',
            status: 'Active',
            brand: 'Apple',
            storeStatus: 'Active stores'
        },
        {
            id: 2,
            name: 'Jane Smith',
            asm: 'Ramkumar',
            status: 'Expired',
            brand: 'Samsung',
            storeStatus: 'Closed stores'
        },
        {
            id: 3,
            name: 'Bob Johnson',
            asm: 'Rajeshwari',
            status: 'Empty Space',
            brand: 'LG',
            storeStatus: 'Active stores'
        }
        // ... additional data objects
    ];

    // Filtered and sorted data based on selected filters
    const filteredData = data
        .filter((item) => {
            const matchesStatus = selectedStatus.length === 0 || selectedStatus.includes(item.status);
            const matchesBrand = selectedBrands.length === 0 || selectedBrands.includes(item.brand);
            const matchesASM = selectedASMs.length === 0 || selectedASMs.includes(item.asm);
            const matchesStoreStatus = selectedStoreStatus.length === 0 || selectedStoreStatus.includes(item.storeStatus);
            const matchesSearchText =
                searchText === '' ||
                item.brand.toLowerCase().includes(searchText.toLowerCase()) ||
                item.asm.toLowerCase().includes(searchText.toLowerCase()) ||
                item.status.toLowerCase().includes(searchText.toLowerCase());

            return matchesStatus && matchesBrand && matchesASM && matchesStoreStatus && matchesSearchText;
        })
        .sort((a, b) => {
            // Sorting logic based on selected sort option and order
            if (sortBy === 'id') {
                if (sortOrder === 'asc') {
                    return a.id - b.id;
                } else {
                    return b.id - a.id;
                }
            } else {
                const compareResult = a[sortBy].localeCompare(b[sortBy]);
                return sortOrder === 'asc' ? compareResult : -compareResult;
            }
        });

    return (
        <div>
            <h3>Status:</h3>
            {statusOptions.map((option) => (
                <Chip
                    key={option}
                    label={option}
                    onClick={() => handleStatusChipClick(option)}
                    color={selectedStatus.includes(option) ? 'primary' : 'default'}
                    variant={selectedStatus.includes(option) ? 'filled' : 'outlined'}
                />
            ))}

            <h3>Brand:</h3>
            {brandOptions.map((option) => (
                <Chip
                    key={option}
                    label={option}
                    onClick={() => handleBrandChipClick(option)}
                    color={selectedBrands.includes(option) ? 'primary' : 'default'}
                    variant={selectedBrands.includes(option) ? 'filled' : 'outlined'}
                />
            ))}

            <h3>ASM:</h3>
            {asmOptions.map((option) => (
                <Chip
                    key={option}
                    label={option}
                    onClick={() => handleASMChipClick(option)}
                    color={selectedASMs.includes(option) ? 'primary' : 'default'}
                    variant={selectedASMs.includes(option) ? 'filled' : 'outlined'}
                />
            ))}

            <h3>Store Status:</h3>
            {storeStatusOptions.map((option) => (
                <Chip
                    key={option}
                    label={option}
                    onClick={() => handleStoreStatusChipClick(option)}
                    color={selectedStoreStatus.includes(option) ? 'primary' : 'default'}
                    variant={selectedStoreStatus.includes(option) ? 'filled' : 'outlined'}
                />
            ))}

            <h3>Search:</h3>
            <TextField value={searchText} onChange={handleSearchTextChange} label="Search" variant="outlined" margin="dense" />

            <h3>Sort By:</h3>
            <div>
                {['name', 'asm', 'status', 'brand', 'storeStatus', 'id'].map((option) => (
                    <Chip
                        key={option}
                        label={option}
                        onClick={() => handleSortByChipClick(option)}
                        color={sortBy === option ? 'primary' : 'default'}
                        variant={sortBy === option ? 'filled' : 'outlined'}
                    />
                ))}
            </div>

            <h3>Sort Order:</h3>
            <div>
                <Chip
                    //label={`Sort Order: ${sortOrder}`}
                    label={sortOrder === 'asc' ? 'A to Z' : 'Z to A'}
                    onClick={handleSortOrderToggle}
                    color="primary"
                    variant="outlined"
                    icon={sortOrder === 'asc' ? <ArrowUpward /> : <ArrowDownward />}
                />
                {/* <Chip
                    icon={<ArrowUpward />}
                    label="Ascending"
                    onClick={handleSortOrderToggle}
                    color={sortOrder === 'asc' ? 'primary' : 'default'}
                    variant={sortOrder === 'asc' ? 'filled' : 'outlined'}
                />
                <Chip
                    icon={<ArrowDownward />}
                    label="Descending"
                    onClick={handleSortOrderToggle}
                    color={sortOrder === 'desc' ? 'primary' : 'default'}
                    variant={sortOrder === 'desc' ? 'filled' : 'outlined'}
                /> */}
            </div>
            <br></br>
            <Button variant="outlined" onClick={handleResetFilters}>
                Reset
            </Button>

            <h3>Filtered and Sorted Data:</h3>
            <ul>
                {filteredData.map((item) => (
                    <li key={item.id}>
                        <div>Name: {item.name}</div>
                        <div>ASM: {item.asm}</div>
                        <div>Status: {item.status}</div>
                        <div>Brand: {item.brand}</div>
                        <div>DOB: {item.storeStatus}</div>
                        <div>ID: {item.id}</div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default YourComponent;
