// project imports
import { OutlinedInput } from '@material-ui/core';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

// eslint-disable-next-line prettier/prettier
import { Box, Button, Card, FormControl, Grid, InputAdornment, InputLabel, MenuItem, Select, Stack, TextField, Typography } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import BackButton from '../../BackButton';
import ApiComponent from '../apicomp/ApiComponent';
import { Brandapi, OutletMediaFormapi, Statusapi } from '../apicomp/Apiurls';
// eslint-disable-next-line prettier/prettier
import { AddAdvertisementapi, BrandLocationapi, BrandTypeapi, Classapi, HoardingListapi, Lightapi, Materialapi, Showroomapi, Vendorapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';

const selectStyles = {
    backgroundColor: 'white',
    color: 'black'
};
const customStyles = {
    borderRadius: 50,
    animationDuration: '10ms',
    '& .MuiOutlinedInput-root': {
        '& fieldset': {
            borderRadius: 8,
            color: 'white'
        },
        '&:hover fieldset': {
            borderColor: '#999'
        },
        '&.Mui-focused fieldset': {
            borderColor: '#1a5f7a'
        }
    }
};

const SamplePage = () => {
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [showroomnames, setShowroomnames] = React.useState([]);
    const [showroomlocation, setShowroomlocation] = React.useState('');
    const [classname, setClassname] = useState('');
    const [classvalue, setClassvalue] = useState('');
    const [width, setWidth] = useState('');
    const [height, setHeight] = useState('');
    const [modelname, setModelname] = useState('');
    const [brandname, setBrandname] = useState('');
    const [brandvalue, setBrandvalue] = useState('');
    const [brandtype, setBrandtype] = useState('');
    const [brandtypevalue, setBrandtypevalue] = useState('');
    const [vendor, setVendor] = useState('');
    const [vendorvalue, setVendorvalue] = useState('');
    const [brandlocation, setBrandlocation] = useState('');
    const [brandlocationvalue, setBrandlocationvalue] = useState('');
    const [lighttype, setLighttype] = useState('');
    const [lighttypevalue, setLighttypevalue] = useState('');
    const [material, setMaterial] = useState('');
    const [materialvalue, setMaterialvalue] = useState('');
    const [expirevalue, setExpirevalue] = useState('');
    const [image, setImage] = useState([]);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    useEffect(() => {
        const handleDataFetched = (data) => {
            setShowroomnames(data);
            setClassname(data);
            setBrandname(data);
            setBrandtype(data);
            setStatus(data);
            setBrandlocation(data);
            setLighttype(data);
            setVendor(data);
            setMaterial(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setShowroomnames([]);
            setClassname([]);
            setBrandname([]);
            setBrandtype([]);
            setStatus([]);
            setBrandlocation([]);
            setLighttype([]);
            setVendor([]);
            setMaterial([]);
        };
    }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setShowroomnames(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/class_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setClassname(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/brand_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setBrandname(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/brandtype', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setBrandtype(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/brandlocation', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setBrandlocation(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/light ', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setLighttype(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/vendormagnt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setVendor(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/material', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setMaterial(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    const handleSubmit = async (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        const formData = new FormData();
        //formData.append('name', classvalue);
        formData.append('ad_image', image);
        formData.append('Width', width);
        formData.append('Height', height);
        formData.append('status', status);
        formData.append('other_Comments', comments);
        formData.append('class_name', classvalue);
        formData.append('showroom', showroomlocation);
        formData.append('model_product_name', modelname);
        formData.append('branding_type', brandtypevalue);
        formData.append('brand', brandvalue);
        formData.append('branding_location', brandlocationvalue);
        formData.append('material', materialvalue);
        formData.append('light_Type', lighttypevalue);
        formData.append('vendor', vendorvalue);
        formData.append('expiry_on', expirevalue);
        formData.append('created_by', 1);
        formData.append('modified_by', 1);

        try {
            const response = await Axios.post(OutletMediaFormapi, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            });
            console.log(response.data);
            setResponseMessage('SuccesssFully Outlet Ad Created');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            //console.log(response);
        } catch (error) {
            console.error(error);
        }
    };
    return (
        <div>
            {/* <ApiComponent apiUrl={HoardingListapi} onDataFetched={setHoarding} /> */}
            <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
            <ApiComponent apiUrl={Brandapi} onDataFetched={setBrandname} />
            <ApiComponent apiUrl={Classapi} onDataFetched={setClassname} />
            <ApiComponent apiUrl={BrandTypeapi} onDataFetched={setBrandtype} />
            <ApiComponent apiUrl={BrandLocationapi} onDataFetched={setBrandlocation} />
            <ApiComponent apiUrl={Lightapi} onDataFetched={setLighttype} />
            <ApiComponent apiUrl={Vendorapi} onDataFetched={setVendor} />
            <ApiComponent apiUrl={Materialapi} onDataFetched={setMaterial} />
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}

            {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/outletadform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Asset
                    </Button>
                </Stack> */}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Outlet Media
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <BackButton />
                    {/* <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/hoardingform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Hoarding
                    </Button> */}
                </Stack>
            </Card>
            <br></br>
            <Card sx={{ width: '100%', boxShadow: 0, p: 5 }}>
                <Box>
                    {/* <List sx={{ width: '100%', maxWidth: 360 }}>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                    <AddAPhotoOutlinedIcon />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                <Typography variant="h3">Add Media Outlet Form</Typography>
                            </ListItemText>
                        </ListItem>
                    </List> */}
                    <Grid container spacing={3} justifyContent="center" alignItems="center">
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="class-select-label">
                                    class
                                </InputLabel>
                                <Select
                                    labelId="class-select-label"
                                    id="class_name"
                                    value={classvalue}
                                    onChange={(e) => setClassvalue(e.target.value)}
                                    label="Class"
                                    name="class_name"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a class</em>
                                    </MenuItem>
                                    {classname && classname !== undefined
                                        ? classname.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        {/* <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.inputprops}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    labelId="status-select-label"
                                    id="status"
                                    name="status"
                                    value={location}
                                    onChange={handleLocationChange}
                                    label="Status"
                                    selectProps={{
                                        classes: {
                                            root: classes.inputprops
                                        },
                                        sx: selectStyles
                                    }}
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    <MenuItem value="New York">New York</MenuItem>
                                    <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                    <MenuItem value="Chicago">Chicago</MenuItem>
                                    <MenuItem value="Houston">Houston</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid> */}
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="location-select-label">
                                    Showroom Location
                                </InputLabel>
                                <Select
                                    labelId="location-select-label"
                                    id="showroom"
                                    name="showroom"
                                    value={showroomlocation}
                                    onChange={(e) => setShowroomlocation(e.target.value)}
                                    label="Showroom Location"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    {showroomnames && showroomnames !== undefined
                                        ? showroomnames.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>

                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="brandtype-select-label">
                                    Branding Type
                                </InputLabel>
                                <Select
                                    labelId="brandtype-select-label"
                                    id="branding_type"
                                    name="branding_type"
                                    value={brandtypevalue}
                                    onChange={(e) => setBrandtypevalue(e.target.value)}
                                    label="Branding Type"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a brand Type</em>
                                    </MenuItem>
                                    {brandtype && brandtype !== undefined
                                        ? brandtype.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="brandloc-select-label">
                                    Branding Location
                                </InputLabel>
                                <Select
                                    labelId="brandloc-select-label"
                                    id="branding_location"
                                    name="branding_location"
                                    value={brandlocationvalue}
                                    onChange={(e) => setBrandlocationvalue(e.target.value)}
                                    label="Branding Location"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a brand location</em>
                                    </MenuItem>
                                    {brandlocation && brandlocation !== undefined
                                        ? brandlocation.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="brand-select-label">
                                    Brand
                                </InputLabel>
                                <Select
                                    labelId="brand-select-label"
                                    id="brand"
                                    name="brand"
                                    value={brandvalue}
                                    onChange={(e) => setBrandvalue(e.target.value)}
                                    label="Branding Location"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a brand location</em>
                                    </MenuItem>
                                    {brandname && brandname !== undefined
                                        ? brandname.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Model product Name"
                                id="model_product_name"
                                name="model_product_name"
                                value={modelname}
                                onChange={(e) => setModelname(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        {/* <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="brand-select-label">
                                    Brand
                                </InputLabel>
                                <Select
                                    labelId="brand-select-label"
                                    id="brand"
                                    name="brand"
                                    value={location}
                                    onChange={handleLocationChange}
                                    label="Brand"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    <MenuItem value="New York">New York</MenuItem>
                                    <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                    <MenuItem value="Chicago">Chicago</MenuItem>
                                    <MenuItem value="Houston">Houston</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid> */}
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Width"
                                id="Width"
                                name="Width"
                                //className={classes.input1}
                                value={width}
                                onChange={(e) => setWidth(e.target.value)}
                                fullWidth
                                type="number"
                                variant="outlined"
                                InputProps={{
                                    //style: customStyles
                                    classes: {
                                        root: classes.inputprops
                                    }
                                }}
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Height"
                                id="Height"
                                name="Height"
                                value={height}
                                onChange={(e) => setHeight(e.target.value)}
                                fullWidth
                                type="number"
                                variant="outlined"
                                className={classes.input}
                                InputProps={{
                                    //style: customStyles
                                    classes: {
                                        root: classes.inputprops
                                    }
                                }}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        {/* <Grid item xs={12} md={6} xl={4}>
                            <TextField
                                //size="small"
                                label="Model Name"
                                id="modelname"
                                name="modelname"
                                //value={weight}
                                //onChange={(e) => setWeight(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputProps={{
                                    //style: customStyles
                                    classes: {
                                        root: classes.inputprops
                                    }
                                }}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid> */}
                        {/* <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="vendor-select-label">
                                    Vendor
                                </InputLabel>
                                <Select
                                    labelId="vendor-select-label"
                                    id="vendor"
                                    name="vendor"
                                    value={location}
                                    onChange={handleLocationChange}
                                    InputProps={{
                                        //style: customStyles
                                        classes: {
                                            root: classes.inputprops
                                        }
                                    }}
                                    label="Vendor"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    <MenuItem value="New York">New York</MenuItem>
                                    <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                    <MenuItem value="Chicago">Chicago</MenuItem>
                                    <MenuItem value="Houston">Houston</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid> */}
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="material-select-label">
                                    Material
                                </InputLabel>
                                <Select
                                    labelId="material-select-label"
                                    id="material"
                                    name="material"
                                    value={materialvalue}
                                    onChange={(e) => setMaterialvalue(e.target.value)}
                                    label="Material"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    {material && material !== undefined
                                        ? material.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="lighttype-select-label">
                                    Light Type
                                </InputLabel>
                                <Select
                                    labelId="lighttype-select-label"
                                    id="light_Type"
                                    name="light_Type"
                                    value={lighttypevalue}
                                    onChange={(e) => setLighttypevalue(e.target.value)}
                                    label="Light Type"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    {lighttype && lighttype !== undefined
                                        ? lighttype.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth variant="outlined" size="small" className={classes.select1}>
                                <InputLabel className={classes.label} id="adimage">
                                    Ad Image
                                </InputLabel>
                                <OutlinedInput
                                    labelId="adimage"
                                    id="ad_image"
                                    type="file"
                                    name="ad_image"
                                    //className={classes.select}
                                    inputProps={{ accept: 'image/*' }}
                                    startAdornment={
                                        <InputAdornment position="start">
                                            <PhotoCameraIcon />
                                        </InputAdornment>
                                    }
                                    onChange={handleImageChange}
                                    fullWidth
                                    //margin="normal"
                                    variant="outlined"
                                    label="Ad Image"
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            //focused: classes.label
                                        }
                                    }}
                                />
                            </FormControl>
                        </Grid>

                        <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    labelId="status-select-label"
                                    id="status"
                                    name="status"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    label="Status"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a status</em>
                                    </MenuItem>
                                    {/* <MenuItem value="Enable">Enable</MenuItem>
                                    <MenuItem value="Disabled">Disable</MenuItem> */}
                                    {status && Array.isArray(status) && status.length > 0 ? (
                                        status.map((option, index) => (
                                            <MenuItem key={index} value={option.id}>
                                                {option.name}
                                            </MenuItem>
                                        ))
                                    ) : (
                                        <MenuItem disabled>No Data</MenuItem>
                                    )}
                                </Select>
                            </FormControl>
                        </Grid>
                        {/* <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="adstatus-select-label">
                                    Ad Status
                                </InputLabel>
                                <Select
                                    labelId="adstatus-select-label"
                                    id="adstatus"
                                    name="adstatus"
                                    value={location}
                                    onChange={handleLocationChange}
                                    label=" Ad Status"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    <MenuItem value="Active">Enable</MenuItem>
                                    <MenuItem value="Inactive">Disable</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid> */}
                        {/* <Grid item xs={12} md={6} xl={4}>
                            <FormControl fullWidth variant="outlined" size="small" className={classes.select1}>
                                <InputLabel className={classes.label} id="assetimage">
                                    Asset Image
                                </InputLabel>
                                <OutlinedInput
                                    labelId="assetimage"
                                    id="assetimage"
                                    type="file"
                                    name="assetimage"
                                    //className={classes.select}
                                    inputProps={{ accept: 'image/*' }}
                                    startAdornment={
                                        <InputAdornment position="start">
                                            <PhotoCameraIcon />
                                        </InputAdornment>
                                    }
                                    //onChange={handleImageChange2}
                                    fullWidth
                                    //margin="normal"
                                    variant="outlined"
                                    label="Asset Image"
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            //focused: classes.label
                                        }
                                    }}
                                />
                            </FormControl>
                        </Grid> */}
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="vendor-select-label">
                                    Vendor
                                </InputLabel>
                                <Select
                                    labelId="vendor-select-label"
                                    id="vendor"
                                    name="vendor"
                                    value={vendorvalue}
                                    onChange={(e) => setVendorvalue(e.target.value)}
                                    label="Vendor"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a vendor</em>
                                    </MenuItem>
                                    {vendor && vendor !== undefined
                                        ? vendor.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <TextField
                                fullWidth
                                //labelId="expiry_on-select-label"
                                id="expiry_on"
                                name="expiry_on"
                                type="date"
                                value={expirevalue}
                                onChange={(e) => setExpirevalue(e.target.value)}
                                //label="Expiry On"
                                inputProps={{
                                    shrink: 'true'
                                }}
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Other Comments"
                                id="other_Comments"
                                name="other_Comments"
                                value={comments}
                                onChange={(e) => setComments(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                    onClick={handleSubmit}
                                    startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Add
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Card>
        </div>
    );
};

export default withAuth(SamplePage);
