//import React, { useEffect, useState } from 'react';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
//import { Typography } from 'tabler-icons-react';
import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';
import CloseIcon from '@mui/icons-material/Close';
//import ListItem from '@mui/material/ListItem';
//import ListItemText from '@mui/material/ListItemText';
// import ListItemAvatar from '@mui/material/ListItemAvatar';
// import Avatar from '@mui/material/Avatar';
// import ImageIcon from '@mui/icons-material/Image';
// import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// import CloseIcon from '@mui/icons-material/Close';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
//import CloseIcon from '@mui/icons-material/Close';
//import DeleteIcon from '@mui/icons-material/Delete';
//import EditIcon from '@mui/icons-material/Edit';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
// eslint-disable-next-line prettier/prettier
import {
    Box,
    Button,
    Card,
    FormControl,
    Grid,
    InputAdornment,
    InputLabel,
    MenuItem,
    Modal,
    OutlinedInput,
    Select,
    Stack,
    TextField,
    Typography,
    useTheme
} from '@mui/material';
import { IconButton, useMediaQuery } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
//import { DataGrid, GridToolbar } from '@mui/x-data-grid';
//import {   , Stack, Button, Modal, useTheme } from '@mui/material';
//import { Typography } from 'tabler-icons-react';
//import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
//import DialogActions from '@mui/material/DialogActions';
//import DialogContent from '@mui/material/DialogContent';
//import DialogContentText from '@mui/material/DialogContentText';
//import DialogTitle from '@mui/material/DialogTitle';
//import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import ApiComponent from '../apicomp/ApiComponent';
import {
    AddAdvertisementapi,
    HoardingFormapi,
    HoardingListapi,
    Showroomapi,
    BrandLocationapi,
    BrandTypeapi,
    Brandapi,
    Materialapi,
    Lightapi,
    Vendorapi
} from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
// import { Brandapi } from '@mui/material';
// import Axios from 'axios';
// import { makeStyles } from '@mui/styles';
// import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
// import { IconButton } from '@mui/material';
// import CloseIcon from '@mui/icons-material/Close';
// import withAuth from '../pages/authentication/authentication3/withAuth';
//import { Brandapi } from '../apicomp/Apiurls';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';

//import { useNavigate } from 'react-router-dom';

// import { useParams, useNavigat } from 'react-router-dom';
// import useStyles from '../styles/styles';
// import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';

function DataTable() {
    //const navigate = useNavigate();

    const [nestopen, setnestOpen] = useState(false);
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const handlenestOpen = () => {
        setnestOpen(true);
    };

    const handlenestClose = () => {
        setnestOpen(false);
    };
    const columns1 = [
        {
            field: 'id',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'S.NO',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header'
            //flex: 0.2
            // cellClassName: "name-column--cell",
        },
        {
            field: 'site_type',
            headerName: 'Site Type',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
            // renderCell: (params) => {
            //     const type = params.value;
            //     const isRent = type === 'Rent';
            //     const type1 = params.value;
            //     const isOwn = type1 === 'Own';

            //     return (
            //         <div>
            //             <span>{isRent ? 'R' : type}</span>
            //             <span>{isOwn ? 'O' : type1}</span>
            //         </div>
            //     );
            // }
        },
        {
            field: 'site_location',
            headerName: 'Site Location',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'branding_type',
            headerName: 'Brand Type',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'Width',
            headerName: 'width',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'height',
            headerName: 'Height',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'start_Date',
            headerName: 'Start Date',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'asset_image',
            headerName: 'Image',
            width: 100,
            renderCell: (params) => (
                // eslint-disable-next-line jsx-a11y/no-noninteractive-element-interactions
                <img
                    src={params.value}
                    alt="Row"
                    style={{ width: '100%', height: 'auto', cursor: 'pointer' }}
                    onClick={() => handleImageClick(params.value)}
                    onKeyDown={(e) => handleImageKeyDown(e, params.value)}
                    // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
                    tabIndex="0"
                />
            )
            // renderCell: (params) => (
            //     <IconButton
            //         onClick={() => handleImageClick(params.value)}
            //         onKeyDown={(e) => handleImageKeyDown(e, params.value)}
            //         role="button"
            //         tabIndex={0}
            //         style={{ padding: 0 }}
            //     >
            //         <ImageIcon />
            //     </IconButton>
            // )
        },
        // {
        //     field: 'Rent',
        //     headerName: 'Rent',
        //     // valueFormatter: ({ value }) => "PO" + value,
        //     // cellClassName: "name-column--cell",
        //     //flex: 0.2
        //     width: 120
        // },
        // {
        //     field: 'Rent',
        //     headerName: 'Rent',
        //     // valueFormatter: ({ value }) => "PO" + value,
        //     // cellClassName: "name-column--cell",
        //     //flex: 0.2
        //     width: 120
        // },
        {
            field: 'status',
            headerName: 'Status',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'other_comments',
            headerName: 'Comments',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'material',
            headerName: 'Material',
            valueFormatter: ({ value }) => value.name,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            headerName: 'Actions',
            field: 'action',
            //flex: 1,
            width: 150,
            headerClassName: 'super-app-theme--header',
            renderCell: (params) => (
                <div>
                    <IconButton aria-label="view" size="large" onClick={() => viewShowrooms(params.id)}>
                        <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton aria-label="delete" size="large" onClick={() => handleEditClick(params.id)}>
                        <AddCircleOutlineOutlinedIcon fontSize="small" />
                    </IconButton>
                    <IconButton aria-label="delete" size="large" onClick={() => handleDeleteSubmit(params.id)}>
                        <DeleteIcon fontSize="small" />
                    </IconButton>
                </div>
            )
        }
    ];

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/hoardingupdate/${id}`);
        window.location.reload();
    };

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${HoardingFormapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Hoarding Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                //setLoading(false);
                // console.log("deleted",res)
                //enqueueSnackbar('Successfully deleted' , { variant:'success', anchorOrigin:{horizontal: 'right', vertical: 'top'} } );
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };

    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    useEffect(() => {
        const handleDataFetched = (data) => {
            setShowroomnames(data);
            setClassname(data);
            setBrandname(data);
            setBrandtype(data);
            setBrandlocation(data);
            setLighttype(data);
            setVendor(data);
            setMaterial(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setShowroomnames([]);
            setClassname([]);
            setBrandname([]);
            setBrandtype([]);
            setBrandlocation([]);
            setLighttype([]);
            setVendor([]);
            setMaterial([]);
        };
    }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setShowroomnames(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/class_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setClassname(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/brand_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setBrandname(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/brandtype', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setBrandtype(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/brandlocation', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setBrandlocation(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/light ', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setLighttype(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/vendormagnt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setVendor(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://localhost:1212/api/v1/OMM2/material', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setMaterial(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);
    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${HoardingFormapi}${id}`, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}` // Include the token in the request headers,
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                //setMatData(data);
                setnestOpen(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    //const [loading, setLoading] = React.useState(false);
    const [hoarding, setHoarding] = React.useState([]);

    const [showroomnames, setShowroomnames] = React.useState([]);
    const [showroomlocation, setShowroomlocation] = React.useState('');
    const [classname, setClassname] = useState('');
    const [classvalue, setClassvalue] = useState('');
    const [width, setWidth] = useState('');
    const [height, setHeight] = useState('');
    const [modelname, setModelname] = useState('');
    const [brandname, setBrandname] = useState('');
    const [brandvalue, setBrandvalue] = useState('');
    const [brandtype, setBrandtype] = useState('');
    const [brandtypevalue, setBrandtypevalue] = useState('');
    const [vendor, setVendor] = useState('');
    const [vendorvalue, setVendorvalue] = useState('');
    const [brandlocation, setBrandlocation] = useState('');
    const [brandlocationvalue, setBrandlocationvalue] = useState('');
    const [lighttype, setLighttype] = useState('');
    const [lighttypevalue, setLighttypevalue] = useState('');
    const [material, setMaterial] = useState('');
    const [materialvalue, setMaterialvalue] = useState('');
    const [expirevalue, setExpirevalue] = useState('');
    const [image, setImage] = useState([]);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const handleSubmit = async (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        const formData = new FormData();
        //formData.append('name', classvalue);
        formData.append('hoarding', selectedRowId);
        formData.append('image', image);

        // formData.append('Width', width);
        // formData.append('Height', height);
        formData.append('status', status);
        //formData.append('comment', comments);
        formData.append('model_name', modelname);
        //formData.append('showroom', showroomlocation);
        //formData.append('branding_type', brandtypevalue);
        formData.append('brand', brandvalue);
        //formData.append('branding_location', brandlocationvalue);
        //formData.append('material', materialvalue);
        //formData.append('light_Type', lighttypevalue);
        formData.append('vendor', vendorvalue);
        formData.append('expiry_on', expirevalue);
        formData.append('created_by', 1);
        formData.append('modified_by', 1);

        try {
            const response = await Axios.post(AddAdvertisementapi, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            });
            console.log(response.data);
            setResponseMessage('SuccesssFully Hoarding Ad Updated');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            //console.log(response);
        } catch (error) {
            console.error(error);
        }
    };

    // React.useEffect(() => {
    //     setLoading(true);
    //     // const token = 'St3e6u2zYK?L!Aq-*DdBfWGEs5j6e5j$';
    //     fetch('http://localhost:1212/api/v1/hoarding/hoarding_list', {
    //         method: 'GET'
    //         // headers: {
    //         //     authorization: `${token}`,
    //         //     'Content-Type': 'application/json'
    //         // }
    //     })
    //         .then((response) => response.json())
    //         // .then(response => response.data)
    //         .then((res) => {
    //             console.log(res.data);
    //             setHoarding(res.data);
    //             setLoading(false);
    //         })
    //         //.then(data => console.log(data))
    //         // .then(data => setProduct(data))
    //         .catch((error) => console.error(error));
    // }, []);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setHoarding(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setHoarding([]);
        };
    }, []);
    // React.useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     Axios.get('http://127.0.0.1:1212/api/v1/hoarding/hording_list/', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setHoarding(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', boxShadow: 0 }}>
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}

            <ApiComponent apiUrl={HoardingListapi} onDataFetched={setHoarding} />
            <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
            <ApiComponent apiUrl={Brandapi} onDataFetched={setBrandname} />
            <ApiComponent apiUrl={BrandTypeapi} onDataFetched={setBrandtype} />
            <ApiComponent apiUrl={BrandLocationapi} onDataFetched={setBrandlocation} />
            <ApiComponent apiUrl={Lightapi} onDataFetched={setLighttype} />
            <ApiComponent apiUrl={Vendorapi} onDataFetched={setVendor} />
            <ApiComponent apiUrl={Materialapi} onDataFetched={setMaterial} />

            {/* <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center">
                <List>
                    <ListItem>
                        <ListItemAvatar>
                            <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                <StoreOutlinedIcon sx={{ color: 'white' }} />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText>
                            {' '}
                            <Typography variant="h3" color="black">
                                Hoarding Table
                            </Typography>
                        </ListItemText>
                    </ListItem>
                </List>
                <Button
                    className={classes.Button}
                    variant="contained"
                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                    //onClick={handleOpen}
                    href="/hoardingform"
                    startIcon={<AddCircleOutlinedIcon />}
                >
                    Hoarding
                </Button>
            </Stack> */}
            <Modal open={modalOpen} onClose={handleCloseModal}>
                <div>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: 'auto' }} />
                </div>
            </Modal>
            <Card sx={{ boxShadow: 2 }}>
                <Box
                    //id="invoice-container"
                    height="60vh"
                    width="100%"
                    fontWeight={10}
                    //className={classes.customButton}
                    sx={{
                        //width: '100%',
                        //border: '2px solid #fff2ea',
                        p: 2,
                        height: isSmallScreen ? '90vh' : '60vh',
                        width: '100%',
                        borderRadius: 5,
                        '& .MuiDataGrid-root': {
                            border: 'none',
                            padding: 1
                            //border: '2px dashed grey'
                        },
                        '& .super-app-theme--header': {
                            //backgroundColor: 'rgba(255, 7, 0, 0.55)',
                            //color: 'orange !important',
                            //fontWeight: 'bold !important'
                            //fontWeight: '700 !important',
                            //color: 'white !important'
                        },
                        '& .super-app-theme--cell': {
                            //backgroundColor: 'primary',
                            //color: '#1a3e72 !important',
                            //fontWeight: '600 !important',
                            //border: 1
                        },
                        '& .MuiDataGrid-cell': {
                            borderBottom: 'none !important',
                            //backgroundColor: '#f2f2f2',
                            color: 'black',
                            fontWeight: '550 !important'
                        },
                        '& .name-column--cell': {
                            variant: 'button',
                            fontWeight: 'medium',
                            color: 'ButtonText'
                        },
                        '& .MuiDataGrid-columnHeaders': {
                            //borderLeft: '2px dashed grey',
                            //borderRight: '2px dashed grey',
                            //borderBottom: '2px solid grey',
                            //fontWeight: 'bold !important',
                            //fontWeight: '700 !important',
                            //fontSize: 15,
                            //fontColor: 'red'
                            //backgroundColor: '#ff874b',
                            //borderRadius: 2
                            //color: 'white !important'
                        },

                        '.MuiDataGrid-columnHeaderTitle': {
                            //fontWeight: 'bold !important',
                            //fontWeight: '1000 !important',
                            //overflow: 'visible !important',
                            color: 'white',
                            width: 'auto',
                            paddingTop: '12px',
                            paddingBottom: '10px',
                            //paddingLeft: "8px",
                            //paddingRight: "24px",
                            textAlign: 'left',
                            fontSize: '0.80rem',
                            fontWeight: 700,
                            opacity: 0.7,
                            background: 'transparent',
                            color: '#8392ab',
                            borderRadius: 'none',
                            borderBottom: '0.0625rem solid #e9ecef'
                            //fontSize: 15
                        },
                        '& .MuiDataGrid-virtualScroller': {
                            //opacity: 1,
                            //transition: 'opacity 0.2s',
                            //overflowY: 'auto',
                            overflowX: 'auto',
                            '&::-webkit-scrollbar': {
                                width: '4px',
                                backgroundColor: '#F5F5F5'
                            },
                            '&::-webkit-scrollbar-thumb': {
                                //backgroundColor: '#11cdef',
                                borderRadius: '4px'
                            }
                        },
                        '& .MuiDataGrid-footerContainer': {
                            color: '#8392ab',
                            border: 'none'
                        },
                        '& .MuiDataGrid-columnSeparator': {
                            visibility: 'hidden'
                        },
                        '&.MuiDataGrid-pagination': {
                            //backgroundColor: "red",
                            //padding: "10px",
                            width: '20px !important'
                        },

                        '&.MuiDataGrid-virtualScroller': {
                            opacity: 0,
                            transition: 'opacity 0.2s'
                        },
                        '&.MuiTablePagination-root': {
                            width: '20px'
                        },

                        '&.MuiDataGrid-virtualScroller:hover': {
                            opacity: 1
                        },
                        '& .MuiTablePagination-select': {
                            //paddingRight: 2,
                            width: '10px !important'
                        },
                        '& .MuiTablePagination-selectIcon': {
                            display: 'none'
                        },

                        '&.MuiDataGrid-toolbar .MuiDataGrid-menuList': {
                            padding: 0
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root': {
                            fontSize: '14px',
                            color: '#333'
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root:hover': {
                            backgroundColor: '#f0f0f0'
                        }
                    }}
                >
                    <DataGrid
                        rows={hoarding}
                        //columns={columns1}
                        columns={columns1}
                        pageSize={5}
                        getRowId={(row) => row.id}
                        components={{ Toolbar: GridToolbar, color: 'primary' }}
                        componentsProps={{
                            toolbar: {
                                showQuickFilter: true,
                                quickFilterProps: { debounceMs: 500 },
                                color: 'primary'
                            }
                        }}
                        loading={loading}
                        //autoHeight
                        //scrollbarSize={100}
                        //pageSize={5}
                        //checkboxSelection
                        //touchRipple
                        //disableColumnMenu
                        // onRowClick={handleRowClick}
                        disableColumnFilter={isSmallScreen ? true : false}
                        disableDensitySelector={isSmallScreen ? true : false}
                        virtualization
                    />
                </Box>
            </Card>
            <Modal open={modalOpen} onClose={handleCloseModal} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ maxWidth: '90vw', maxHeight: '90vh' }}>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                    <IconButton
                        onClick={handleCloseModal}
                        style={{ position: 'absolute', top: 10, right: 10, color: 'white', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </div>
            </Modal>
            <Modal
                open={nestopen}
                onClose={handlenestClose}
                aria-labelledby="responsive-modal-title"
                aria-describedby="responsive-modal-description"
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}
            >
                <div
                    style={{
                        backgroundColor: 'white',
                        margin: isMobile ? '20px' : '100px',
                        padding: '20px',
                        maxWidth: isMobile ? '90%' : '500px',
                        maxHeight: isMobile ? '85vh' : 'initial',
                        overflowY: isMobile ? 'auto' : 'initial'
                        //maxHeight: isMobile ? '90%' : '500px'
                    }}
                >
                    {/* <Typography variant="h5" id="responsive-modal-title" gutterBottom>
                        Add Advertisement
                    </Typography> */}
                    <List sx={{ width: '100%', maxWidth: 360 }}>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar className={classes.Button} sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                    <AddAPhotoOutlinedIcon />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                <Typography variant="h3"> Add Advertisement</Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <Card sx={{ width: '100%', boxShadow: 0, p: 2 }}>
                        <Box>
                            {/* <List sx={{ width: '100%', maxWidth: 360 }}>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                    <AddAPhotoOutlinedIcon />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                <Typography variant="h3">Add Media Outlet Form</Typography>
                            </ListItemText>
                        </ListItem>
                    </List> */}
                            <Grid container spacing={3} justifyContent="center" alignItems="center">
                                <Grid item xs={12} md={12} xl={12}>
                                    <FormControl fullWidth className={classes.select}>
                                        <InputLabel className={classes.label} id="brand-select-label">
                                            Brand
                                        </InputLabel>
                                        <Select
                                            labelId="brand-select-label"
                                            id="brand"
                                            name="brand"
                                            value={brandvalue}
                                            onChange={(e) => setBrandvalue(e.target.value)}
                                            label="Branding"
                                            //displayEmpty
                                            //className={classes.selectEmpty}
                                            //className={classes.select}
                                        >
                                            <MenuItem value="">
                                                <em>Select a brand location</em>
                                            </MenuItem>
                                            {brandname && brandname !== undefined
                                                ? brandname.map((option, index) => (
                                                      <MenuItem key={index} value={option.id}>
                                                          {option.name}
                                                      </MenuItem>
                                                  ))
                                                : 'No Data'}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} md={12} xl={12}>
                                    <TextField
                                        //size="small"
                                        label="Model product Name"
                                        id="model_product_name"
                                        name="model_product_name"
                                        value={modelname}
                                        onChange={(e) => setModelname(e.target.value)}
                                        fullWidth
                                        //type="number"
                                        variant="outlined"
                                        className={classes.input}
                                        InputLabelProps={{
                                            classes: {
                                                //root: classes.label,
                                                focused: classes.label
                                            }
                                        }}
                                    />
                                </Grid>

                                <Grid item xs={12} md={12} xl={12}>
                                    <FormControl fullWidth variant="outlined" size="small" className={classes.select1}>
                                        <InputLabel className={classes.label} id="adimage">
                                            Ad Image
                                        </InputLabel>
                                        <OutlinedInput
                                            labelId="adimage"
                                            id="ad_image"
                                            type="file"
                                            name="ad_image"
                                            //className={classes.select}
                                            inputProps={{ accept: 'image/*' }}
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <PhotoCameraIcon />
                                                </InputAdornment>
                                            }
                                            onChange={handleImageChange}
                                            fullWidth
                                            //margin="normal"
                                            variant="outlined"
                                            label="Ad Image"
                                            InputLabelProps={{
                                                classes: {
                                                    //root: classes.label,
                                                    //focused: classes.label
                                                }
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} md={12} xl={12}>
                                    <FormControl fullWidth className={classes.select}>
                                        <InputLabel className={classes.label} id="status-select-label">
                                            Status
                                        </InputLabel>
                                        <Select
                                            labelId="status-select-label"
                                            id="status"
                                            name="status"
                                            value={status}
                                            onChange={(e) => setStatus(e.target.value)}
                                            label="Status"
                                            //displayEmpty
                                            //className={classes.selectEmpty}
                                            //className={classes.select}
                                        >
                                            <MenuItem value="">
                                                <em>Select a status</em>
                                            </MenuItem>
                                            <MenuItem value="Active">Active</MenuItem>
                                            <MenuItem value="Inactive">Inactive</MenuItem>
                                        </Select>
                                    </FormControl>
                                </Grid>

                                <Grid item xs={12} md={12} xl={12}>
                                    <FormControl fullWidth className={classes.select}>
                                        <InputLabel className={classes.label} id="vendor-select-label">
                                            Vendor
                                        </InputLabel>
                                        <Select
                                            labelId="vendor-select-label"
                                            id="vendor"
                                            name="vendor"
                                            value={vendorvalue}
                                            onChange={(e) => setVendorvalue(e.target.value)}
                                            label="Vendor"
                                            //displayEmpty
                                            //className={classes.selectEmpty}
                                            //className={classes.select}
                                        >
                                            <MenuItem value="">
                                                <em>Select a vendor</em>
                                            </MenuItem>
                                            {vendor && vendor !== undefined
                                                ? vendor.map((option, index) => (
                                                      <MenuItem key={index} value={option.id}>
                                                          {option.name}
                                                      </MenuItem>
                                                  ))
                                                : 'No Data'}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} md={12} xl={12}>
                                    <TextField
                                        fullWidth
                                        //labelId="expiry_on-select-label"
                                        id="expiry_on"
                                        name="expiry_on"
                                        type="date"
                                        value={expirevalue}
                                        onChange={(e) => setExpirevalue(e.target.value)}
                                        //label="Expiry On"
                                        inputProps={{
                                            shrink: 'true'
                                        }}
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    />
                                </Grid>
                                {/* <Grid item xs={12} md={12} xl={12}>
                                    <TextField
                                        //size="small"
                                        label="Other Comments"
                                        id="other_Comments"
                                        name="other_Comments"
                                        value={comments}
                                        onChange={(e) => setComments(e.target.value)}
                                        fullWidth
                                        //type="number"
                                        variant="outlined"
                                        className={classes.input}
                                        InputLabelProps={{
                                            classes: {
                                                //root: classes.label,
                                                focused: classes.label
                                            }
                                        }}
                                    />
                                </Grid> */}

                                <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                                    <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                        {' '}
                                        <Button
                                            className={classes.Button}
                                            variant="contained"
                                            //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                            onClick={handleSubmit}
                                            startIcon={<FileUploadOutlinedIcon />}
                                        >
                                            Add
                                        </Button>
                                    </Stack>
                                </Grid>
                            </Grid>
                        </Box>
                    </Card>
                    {/* <Button variant="contained" color="primary" onClick={handlenestClose}>
                        Close Modal
                    </Button> */}
                </div>
            </Modal>

            <Dialog
                open={openDialogdelete}
                onClose={handleCloseDialogdelete}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are you sure want to delete this id #{selectedRowIddel}? </DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure want to Delete this brand id #{selectedRowIddel}?
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialogdelete}>No</Button>
                    <Button onClick={deleteBrand}>Submit</Button>
                </DialogActions>
            </Dialog>

            <Dialog
                open={openDialog}
                onClose={handleCloseDialog}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                {/* <DialogTitle id="alert-dialog-title">Are You Sure want to update this id data</DialogTitle> */}
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure want to update this brand id #{selectedRowId}?
                    </DialogContentText>
                    {/* <DialogContentText id="alert-dialog-description">
            <Typography variant="h5">Are you sure want to update this brand id #{selectedRowId}? </Typography>
        </DialogContentText> */}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog}>No</Button>
                    <Button onClick={handleSubmit}>Submit</Button>
                </DialogActions>
            </Dialog>
        </Card>
    );
}

export default withAuth(DataTable);
