import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

const [openDialog, setOpenDialog] = useState(false);

const handleOpenDialog = () => {
    setOpenDialog(true);
};

const handleCloseDialog = () => {
    setOpenDialog(false);
};
const handleConfirmSubmit = () => {
    // Perform the API request and update logic here
    handleOpenDialog();
};
  
  const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };


    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`http://localhost:1212/api/v1/OMM2/brand_mgmt/${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Brand Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                //setLoading(false);
                // console.log("deleted",res)
                //enqueueSnackbar('Successfully deleted' , { variant:'success', anchorOrigin:{horizontal: 'right', vertical: 'top'} } );
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };


    <Dialog
    open={openDialogdelete}
    onClose={handleCloseDialogdelete}
    aria-labelledby="alert-dialog-title"
    aria-describedby="alert-dialog-description"
>
    {/* <DialogTitle id="alert-dialog-title">Are you sure want to delete this id #{selectedRowIddel}? </DialogTitle> */}
    <DialogContent>
        <DialogContentText id="alert-dialog-description">
            Are you sure want to Delete this brand id #{selectedRowIddel}?
        </DialogContentText>
    </DialogContent>
    <DialogActions>
        <Button onClick={handleCloseDialogdelete}>No</Button>
        <Button onClick={deleteBrand}>Submit</Button>
    </DialogActions>
    </Dialog>
    
    <Dialog
    open={openDialog}
    onClose={handleCloseDialog}
    aria-labelledby="alert-dialog-title"
    aria-describedby="alert-dialog-description"
>
    {/* <DialogTitle id="alert-dialog-title">Are You Sure want to update this id data</DialogTitle> */}
    <DialogContent>
        <DialogContentText id="alert-dialog-description">
            Are you sure want to update this brand id #{selectedRowId}?
        </DialogContentText>
        {/* <DialogContentText id="alert-dialog-description">
            <Typography variant="h5">Are you sure want to update this brand id #{selectedRowId}? </Typography>
        </DialogContentText> */}
    </DialogContent>
    <DialogActions>
        <Button onClick={handleCloseDialog}>No</Button>
        <Button onClick={handleSubmit}>Submit</Button>
    </DialogActions>
</Dialog>