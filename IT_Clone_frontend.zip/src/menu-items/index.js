import dashboard from './dashboard';
import pages from './pages';
import utilities from './utilities';
import other from './other';
import job_assign from './job_assign';
import media_connect from './media_connect';
import user_management from './user_management';

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
    items: [dashboard, pages, utilities, job_assign, user_management, media_connect, other]
};

export default menuItems;
