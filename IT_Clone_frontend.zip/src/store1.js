import React, { createContext, useReducer } from 'react';

// export const StoreContext = createContext(null);

const initialState = {
    user: {
        id: '',
        username: ''
    },
    isAuthenticated: false,
    token: ''
};

const reducer = (state, action) => {
    switch (action.type) {
        case 'initializeStore':
            if (localStorage.getItem('token')) {
                return {
                    ...state,
                    token: localStorage.getItem('token'),
                    isAuthenticated: true,
                    user: {
                        id: localStorage.getItem('userid'),
                        username: localStorage.getItem('username')
                    }
                };
            } else {
                return {
                    ...state,
                    user: {
                        id: '',
                        username: ''
                    },
                    token: '',
                    isAuthenticated: false
                };
            }
        case 'setToken':
            return {
                ...state,
                token: action.token,
                isAuthenticated: true
            };
        case 'removeToken':
            return {
                ...state,
                user: {
                    id: '',
                    username: ''
                },
                token: '',
                isAuthenticated: false
            };
        case 'setUser':
            return {
                ...state,
                user: action.user
            };
        default:
            return state;
    }
};

const StoreContext = createContext();

const StoreProvider = ({ children }) => {
    const [state, dispatch] = useReducer(reducer, initialState);

    return <StoreContext.Provider value={{ state, dispatch }}>{children}</StoreContext.Provider>;
};

export { StoreContext, StoreProvider };
