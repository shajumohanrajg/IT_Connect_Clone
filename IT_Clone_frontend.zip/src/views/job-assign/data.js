import { IconButton } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';

const class_columns = [
    {
        field: 'name',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Name',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        //flex: 0.2
        width: 200
        // cellClassName: "name-column--cell",
    },
    {
        field: 'status',
        headerName: 'Status',
        // valueFormatter: ({ value }) => "PO" + value,
        // cellClassName: "name-column--cell",
        //flex: 0.2
        width: 120
        // renderCell: (params) => {
        //     const type = params.value;
        //     const isRent = type === 'Rent';
        //     const type1 = params.value;
        //     const isOwn = type1 === 'Own';

        //     return (
        //         <div>
        //             <span>{isRent ? 'R' : type}</span>
        //             <span>{isOwn ? 'O' : type1}</span>
        //         </div>
        //     );
        // }
    },
    {
        field: 'actions',
        headerName: 'Actions',
        width: 150,
        renderCell: (params) => (
            // <Button variant="outlined" onClick={() => handleEditClick(params.id)}>
            //     Edit
            // </Button>
            <IconButton aria-label="delete" size="large" onClick={() => handleEditClick(params.id)}>
                <EditIcon fontSize="small" />
            </IconButton>
        )
    }
    // {
    //     headerName: 'Actions',
    //     field: 'action',
    //     flex: 1,
    //     headerClassName: 'super-app-theme--header',
    //     renderCell: (params) => (
    //         <div>
    //             <IconButton aria-label="delete" size="large" onClick={() => updateVendor(params.id)}>
    //                 <EditIcon fontSize="small" />
    //             </IconButton>

    //             {/* <IconButton aria-label="delete" color="error" size="large" onClick={() => deleteVendor(params.id)}>
    //                 <DeleteIcon fontSize="small" />
    //             </IconButton> */}
    //         </div>
    //     )
    // }
    // {
    //     field: 'url',
    //     headerName: 'URL',
    //     // valueFormatter: ({ value }) => "PO" + value,
    //     // cellClassName: "name-column--cell",
    //     //flex: 0.2
    //     width: 200
    // }
];

export { class_columns };
