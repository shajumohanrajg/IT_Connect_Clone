// material-ui

import React, { useState, useEffect } from 'react';
import { makeStyles } from '@mui/styles';
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    TextField,
    Button,
    Input,
    Fab,
    Typography,
    Grid,
    Box,
    InputAdornment,
    Stack,
    Card
} from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import WorkIcon from '@mui/icons-material/Work';
import BeachAccessIcon from '@mui/icons-material/BeachAccess';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import Modal from '@mui/material/Modal';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { OutlinedInput } from '@material-ui/core';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import Axios from 'axios';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
//import Table from './360floordiatable';
import withAuth from '../pages/authentication/authentication3/withAuth';
import { MobileDateTimePicker } from '@mui/x-date-pickers/MobileDateTimePicker';
import { useParams } from 'react-router-dom';

import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { parseISO } from 'date-fns';

import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { DemoContainer, DemoItem } from '@mui/x-date-pickers/internals/demo';
import dayjs from 'dayjs';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import utcPlugin from 'dayjs/plugin/utc';

dayjs.extend(utcPlugin);

// import { LocalizationProvider, AdapterDateFns, DateTimePicker } from '@mui/lab';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },

    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                color: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    inputprops: {
        //backgroundColor: 'white',
        //color: 'black'
    },
    input1: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",
        backgroundColor: 'transparent',
        //color: 'black',
        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                fontcolor: 'black',
                backgroundColor: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        animationDuration: '10ms',
        //backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        //backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    borderRadius: 5,
    boxShadow: 30,
    p: 4
};
const selectStyles = {
    backgroundColor: 'white',
    color: 'black'
};
const customStyles = {
    borderRadius: 50,
    animationDuration: '10ms',
    '& .MuiOutlinedInput-root': {
        '& fieldset': {
            borderRadius: 8,
            color: 'white'
        },
        '&:hover fieldset': {
            borderColor: '#999'
        },
        '&.Mui-focused fieldset': {
            borderColor: '#1a5f7a'
        }
    }
};

const SamplePage = () => {
    let { id } = useParams();
    const classes = useStyles();

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [name, setName] = useState('');
    const [rsm, setRsm] = useState('');
    const [asm, setAsm] = useState('');
    const [manager, setManager] = useState('');
    const [cugNo, setCugNo] = useState('');
    const [landline, setLandline] = useState('');
    const [email, setEmail] = useState('');
    const [region, setRegion] = useState('');
    const [state, setState] = useState('');
    const [address, setAddress] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const [matData, setMatData] = React.useState([
        {
            assigned_to: '',
            comment: '',
            dead_Line: null,
            designtype: '',
            jobfor: '',
            jobtype: '',
            priority: '',
            showroom: '',
            status: '',

            created_by: 1,
            modified_by: 1
        }
    ]);

    const [jobfor1, setJobfor] = useState([]);
    const [jobforvalue, setJobforvalue] = useState('');
    const [jobtype1, setJobtype] = useState([]);
    const [jobtypevalue, setJobtypevalue] = useState('');
    const [designtype1, setDesigntype] = useState([]);
    const [designtypevalue, setDesigntypevalue] = useState('');
    const [showroomnames, setShowroomnames] = useState([]);
    const [showroomvalue, setShowroomvalue] = useState('');
    const [comment, setComment] = useState('');
    const [priority, setPriority] = useState('');
    const [priorityvalue, setPriorityvalue] = useState('');
    const [assignto, setAssignto] = useState([]);
    const [assigntovalue, setAssigntovalue] = useState('');

    const [selectedDate, setSelectedDate] = useState(null);

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/jobfor', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobfor(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setShowroomnames(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/jobtype', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobtype(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/designtype', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setDesigntype(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://127.0.0.1:1212/api/v1/users/', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setAssignto(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/jobassignupdate/${id}`);
        window.location.reload();
    };
    const url = 'http://localhost:1212/api/v1/job/job/';
    useEffect(() => {
        const token = localStorage.getItem('token');
        // const id=props.match.params.id
        Axios.get(url + id, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((res) => {
                // console.log(res.data)
                setMatData(res.data);
            })
            .catch((err) => console.error(err));
    }, [id]);

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        Axios.put(`http://localhost:1212/api/v1/job/job/${id}/`, matData, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                console.log('Data updated successfully:', response.data);

                // Perform any necessary actions after successful data update
            })
            .catch((error) => {
                console.log('Error updating data:', error);
                // Handle any errors that occur during the update process
            });
    };

    // const handleSubmit = (e) => {
    //     const token = localStorage.getItem('token');
    //     e.preventDefault();
    //     Axios.put(
    //         'http://localhost:1212/api/v1/OMM2/showroom_mgmt/',
    //         {
    //             // id: id,
    //             name: name,
    //             rsm: rsm,
    //             asm: asm,
    //             manager: manager,
    //             cug_no: cugNo,
    //             landline: landline,
    //             e_mail: email,
    //             region: region,
    //             state: state,
    //             address: address,
    //             created_by: 1,
    //             modified_by: 1
    //         },
    //         {
    //             headers: {
    //                 Authorization: `Token ${token}` // Include the token in the request headers
    //             }
    //         }
    //     ).then(
    //         (response) => {
    //             // enqueueSnackbar('Data Entry Successful', {
    //             //     variant: 'success',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(response);
    //             // history.push('/dashboard/bomat_table2');
    //             // setTimeout(() => {
    //             //     window.location.reload();
    //             // }, 1000);
    //         },
    //         (error) => {
    //             // enqueueSnackbar('Check Data and Try Again', {
    //             //     variant: 'Error',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(error);
    //         }
    //     );
    // };
    return (
        <div>
            {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/outletadform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Asset
                    </Button>
                </Stack> */}
            <List sx={{ width: '100%', maxWidth: 360 }}>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                            <AddAPhotoOutlinedIcon />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText>
                        <Typography variant="h3">Create Job assign</Typography>
                    </ListItemText>
                </ListItem>
            </List>
            <Grid container spacing={2} justifyContent="center" alignItems="center">
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="jobfor-select-label">
                            Job For
                        </InputLabel>
                        <Select
                            labelId="jobfor-select-label"
                            id="jobfor"
                            name="jobfor"
                            value={matData.jobfor || ''}
                            onChange={(e) => setMatData({ ...matData, jobfor: e.target.value })}
                            // value={jobforvalue}
                            // onChange={(e) => setJobforvalue(e.target.value)}
                            label="Job For"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select Job For</em>
                            </MenuItem>
                            {jobfor1 && jobfor1 !== undefined
                                ? jobfor1.map((option, index) => (
                                      <MenuItem key={index} value={option.id}>
                                          {option.name}
                                      </MenuItem>
                                  ))
                                : 'No Data'}
                            {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="jobtype-select-label">
                            Job Type
                        </InputLabel>
                        <Select
                            labelId="jobtype-select-label"
                            id="jobtype"
                            name="jobtype"
                            value={matData.jobtype || ''}
                            onChange={(e) => setMatData({ ...matData, jobtype: e.target.value })}
                            // value={jobtypevalue}
                            // onChange={(e) => setJobtypevalue(e.target.value)}
                            label="Job Type"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select Job For</em>
                            </MenuItem>
                            {jobtype1 && jobtype1 !== undefined
                                ? jobtype1.map((option, index) => (
                                      <MenuItem key={index} value={option.id}>
                                          {option.name}
                                      </MenuItem>
                                  ))
                                : 'No Data'}
                            {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="designtype-select-label">
                            Design Type
                        </InputLabel>
                        <Select
                            labelId="designtype-select-label"
                            id="designtype"
                            name="designtype"
                            value={matData.designtype || ''}
                            onChange={(e) => setMatData({ ...matData, designtype: e.target.value })}
                            // value={designtypevalue}
                            // onChange={(e) => setDesigntypevalue(e.target.value)}
                            label="Design Type"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select Design Type</em>
                            </MenuItem>
                            {designtype1 && designtype1 !== undefined
                                ? designtype1.map((option, index) => (
                                      <MenuItem key={index} value={option.id}>
                                          {option.name}
                                      </MenuItem>
                                  ))
                                : 'No Data'}
                            {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="location-select-label">
                            Showroom Location
                        </InputLabel>
                        <Select
                            labelId="location-select-label"
                            id="showroom"
                            name="showroom"
                            value={matData.showroom || ''}
                            onChange={(e) => setMatData({ ...matData, showroom: e.target.value })}
                            // value={showroomvalue}
                            // onChange={(e) => setShowroomvalue(e.target.value)}
                            label="Showroom Location"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select a location</em>
                            </MenuItem>
                            {showroomnames && showroomnames !== undefined
                                ? showroomnames.map((option, index) => (
                                      <MenuItem key={index} value={option.id}>
                                          {option.name}
                                      </MenuItem>
                                  ))
                                : 'No Data'}
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="priority-select-label">
                            Priority
                        </InputLabel>
                        <Select
                            labelId="priority-select-label"
                            id="priority"
                            value={matData.priority || ''}
                            onChange={(e) => setMatData({ ...matData, priority: e.target.value })}
                            // value={priority}
                            // onChange={(e) => setPriority(e.target.value)}
                            label="Priority"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select a Priority</em>
                            </MenuItem>
                            <MenuItem value="Medium">Medium</MenuItem>
                            <MenuItem value="TOP">Top</MenuItem>
                            <MenuItem value="Urgent">Urgent</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>

                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="assignto-select-label">
                            Assign To
                        </InputLabel>
                        <Select
                            labelId="assignto-select-label"
                            id="assigned_to"
                            name="assigned_to"
                            value={matData.assigned_to || ''}
                            onChange={(e) => setMatData({ ...matData, assigned_to: e.target.value })}
                            // value={assigntovalue}
                            // onChange={(e) => setAssigntovalue(e.target.value)}
                            label="Assign To"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select a User</em>
                            </MenuItem>
                            {assignto && assignto !== undefined
                                ? assignto.map((option, index) => (
                                      <MenuItem key={index} value={option.id}>
                                          {option.username}
                                      </MenuItem>
                                  ))
                                : 'No Data'}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth className={classes.select}>
                        <InputLabel className={classes.label} id="status-select-label">
                            Status
                        </InputLabel>
                        <Select
                            labelId="status-select-label"
                            id="status-select"
                            value={matData.status || ''}
                            onChange={(e) => setMatData({ ...matData, status: e.target.value })}
                            // value={status}
                            // onChange={(e) => setStatus(e.target.value)}
                            label="Status"
                            //displayEmpty
                            //className={classes.selectEmpty}
                            //className={classes.select}
                        >
                            <MenuItem value="">
                                <em>Select a Status</em>
                            </MenuItem>
                            <MenuItem value="Pending">Pending</MenuItem>
                            <MenuItem value="Follow Up">Follow Up</MenuItem>
                            <MenuItem value="Completed">Completed</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DemoItem label="Expiry On" fullWidth>
                            <MobileDateTimePicker
                                defaultValue={dayjs(matData.dead_Line, matData.dead_Line)}
                                onChange={(e) => setMatData({ ...matData, dead_Line: e.target.value })}
                                fullWidth
                            />
                        </DemoItem>
                    </LocalizationProvider>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <LocalizationProvider dateAdapter={AdapterDayjs} fullWidth className={classes.select}>
                        <DateTimePicker
                            className={classes.label}
                            renderInput={(props) => <TextField {...props} fullWidth />}
                            label="Date and Time"
                            // value={selectedDate}
                            // onChange={handleDateChange}
                            //value={matData.dead_Line || ''}
                            onChange={(e) => setMatData({ ...matData, dead_Line: e.target.value })}
                            fullWidth
                        />
                    </LocalizationProvider>
                </Grid>
                {/* <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DateTimePicker
                        renderInput={(props) => <TextField {...props} fullWidth />}
                        label="Date and Time"
                        //value={matData.dead_Line || null}
                        onChange={handleDateChange}
                        //onChange={(e) => setMatData({ ...matData, dead_Line: e.target.value })}
                        fullWidth
                    />
                </LocalizationProvider> */}
                {/* <LocalizationProvider dateAdapter={AdapterDateFns}>
                                    <DateTimePicker
                                        renderInput={(props) => <TextField {...props} fullWidth />}
                                        label="Date and Time"
                                        //value={matData.dead_Line || null}
                                        onChange={handleDateChange}
                                        inputFormat="yyyy-MM-dd'T'HH:mm:ss"
                                        parseInput={parseISO}
                                        fullWidth
                                    />
                                </LocalizationProvider> */}
                {/* <DateTimePicker
                                    renderInput={(props) => <TextField {...props} />}
                                    label="Select Date and Time"
                                    value={matData.dead_Line || null}
                                    onChange={handleDateChange}
                                /> */}
                <p>{matData.dead_Line || null}</p>
                <Grid item xs={12} md={12} xl={12}>
                    <TextField
                        //size="small"
                        label="Comments"
                        id="comment"
                        // value={comment}
                        // onChange={(e) => setComment(e.target.value)}
                        value={matData.comment || ''}
                        onChange={(e) => setMatData({ ...matData, comment: e.target.value })}
                        fullWidth
                        //type="number"
                        variant="outlined"
                        className={classes.input}
                        InputLabelProps={{
                            classes: {
                                //root: classes.label,
                                focused: classes.label
                            }
                        }}
                    />
                </Grid>

                <Grid item xs={12} md={6} xl={6} sx={{ mt: 3 }}>
                    <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                        {' '}
                        <Button
                            className={classes.Button}
                            variant="contained"
                            onClick={handleSubmit}
                            //startIcon={<FileUploadOutlinedIcon />}
                        >
                            Create
                        </Button>
                    </Stack>
                </Grid>
            </Grid>
        </div>
    );
};

export default withAuth(SamplePage);
