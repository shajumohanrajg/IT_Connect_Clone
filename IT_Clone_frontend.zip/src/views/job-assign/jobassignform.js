// material-ui

import React, { useState } from 'react';
import { makeStyles } from '@mui/styles';
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    TextField,
    Button,
    Input,
    Fab,
    Typography,
    Grid,
    Box,
    InputAdornment,
    Stack,
    Card
    // List,
    // ListItem,
    // ListItemText,
    //Stack
} from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import WorkIcon from '@mui/icons-material/Work';
import BeachAccessIcon from '@mui/icons-material/BeachAccess';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
//import { makeStyles } from '@material-ui/core/styles';
// import { DropzoneArea } from 'material-ui-dropzone';
// import 'react-dropzone-uploader/dist/styles.css';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import Modal from '@mui/material/Modal';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { OutlinedInput } from '@material-ui/core';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import Axios from 'axios';
import withAuth from '../pages/authentication/authentication3/withAuth';

import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { Urgent } from 'tabler-icons-react';
//import { ListItem } from '@mui/material';
// ==============================|| SAMPLE PAGE ||============================== //
// const useStyles = makeStyles((theme) => ({
//     formControl: {
//         margin: theme.spacing(1),
//         minWidth: 120
//     },
//     selectEmpty: {
//         marginTop: theme.spacing(2)
//     }
// }));
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    stepper: {
        backgroundColor: 'transparent', // set your desired background color
        // padding: "16px", // adjust the padding as needed
        // borderRadius: "8px", // adjust the border radius as needed
        [theme.breakpoints.down('sm')]: {
            padding: theme.spacing(1)
        }
    },
    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                // color: 'white',
                // backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                // backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        // backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    borderRadius: 5,
    boxShadow: 30,
    p: 4
};

const SamplePage = () => {
    const classes = useStyles();
    const [location, setLocation] = useState('');
    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    function getPhoto(event) {
        setPhoto(URL.createObjectURL(event.target.files[0]));
        setPhoto1(event.target.files[0]);
    }
    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };

    const [name, setName] = useState('');
    const [status, setStatus] = useState('');
    const [jobfor, setJobfor] = useState([]);
    const [jobforvalue, setJobforvalue] = useState('');
    const [jobtype, setJobtype] = useState([]);
    const [jobtypevalue, setJobtypevalue] = useState('');
    const [designtype, setDesigntype] = useState([]);
    const [designtypevalue, setDesigntypevalue] = useState('');
    const [showroomnames, setShowroomnames] = useState([]);
    const [showroomvalue, setShowroomvalue] = useState('');
    const [comment, setComment] = useState('');
    const [priority, setPriority] = useState('');
    const [priorityvalue, setPriorityvalue] = useState('');
    const [assignto, setAssignto] = useState([]);
    const [assigntovalue, setAssigntovalue] = useState('');

    const [selectedDate, setSelectedDate] = useState(null);

    const handleDateChange = (date) => {
        setSelectedDate(date);
    };

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/jobfor', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobfor(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setShowroomnames(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/jobtype', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobtype(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/designtype', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setDesigntype(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://127.0.0.1:1212/api/v1/users/', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setAssignto(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();
        Axios.post(
            'http://localhost:1212/api/v1/job/job/',
            {
                // id: id,
                //name: name,

                jobfor: jobforvalue,
                jobtype: jobtypevalue,
                designtype: designtypevalue,
                showroom: showroomvalue,
                priority: priority,
                status: status,
                comment: comment,
                assigned_to: assigntovalue,
                dead_Line: selectedDate,
                created_by: 1,
                modified_by: 1
            },
            {
                headers: {
                    Authorization: `Token ${token}` // Include the token in the request headers
                }
            }
        ).then(
            (response) => {
                // enqueueSnackbar('Data Entry Successful', {
                //     variant: 'success',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(response);
                // history.push('/dashboard/bomat_table2');
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            },
            (error) => {
                // enqueueSnackbar('Check Data and Try Again', {
                //     variant: 'Error',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(error);
            }
        );
    };
    return (
        <div>
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Job Management
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                </Stack>
            </Card>
            <br></br>
            <Card sx={{ width: '100%', boxShadow: 0, p: 5 }}>
                <Grid container spacing={2} direction="row" justifyContent="space-between" alignItems="flex-start">
                    <List sx={{ width: '100%', maxWidth: 360 }}>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                    <AddAPhotoOutlinedIcon />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                <Typography variant="h3">Create Job assign</Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="jobfor-select-label">
                                    Job For
                                </InputLabel>
                                <Select
                                    labelId="jobfor-select-label"
                                    id="jobfor"
                                    name="jobfor"
                                    value={jobforvalue}
                                    onChange={(e) => setJobforvalue(e.target.value)}
                                    label="Job For"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select Job For</em>
                                    </MenuItem>
                                    {jobfor && jobfor !== undefined
                                        ? jobfor.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                    {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="jobtype-select-label">
                                    Job Type
                                </InputLabel>
                                <Select
                                    labelId="jobtype-select-label"
                                    id="jobtype"
                                    name="jobtype"
                                    value={jobtypevalue}
                                    onChange={(e) => setJobtypevalue(e.target.value)}
                                    label="Job Type"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select Job For</em>
                                    </MenuItem>
                                    {jobtype && jobtype !== undefined
                                        ? jobtype.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                    {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="designtype-select-label">
                                    Design Type
                                </InputLabel>
                                <Select
                                    labelId="designtype-select-label"
                                    id="jobtype"
                                    name="jobtype"
                                    value={designtypevalue}
                                    onChange={(e) => setDesigntypevalue(e.target.value)}
                                    label="Design Type"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select Design Type</em>
                                    </MenuItem>
                                    {designtype && designtype !== undefined
                                        ? designtype.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                    {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="location-select-label">
                                    Showroom Location
                                </InputLabel>
                                <Select
                                    labelId="location-select-label"
                                    id="showroom"
                                    name="showroom"
                                    value={showroomvalue}
                                    onChange={(e) => setShowroomvalue(e.target.value)}
                                    label="Showroom Location"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    {showroomnames && showroomnames !== undefined
                                        ? showroomnames.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="priority-select-label">
                                    Priority
                                </InputLabel>
                                <Select
                                    labelId="priority-select-label"
                                    id="priority"
                                    value={priority}
                                    onChange={(e) => setPriority(e.target.value)}
                                    label="Priority"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a Priority</em>
                                    </MenuItem>
                                    <MenuItem value="Medium">Medium</MenuItem>
                                    <MenuItem value="TOP">Top</MenuItem>
                                    <MenuItem value="Urgent">Urgent</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        q
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="assignto-select-label">
                                    Assign To
                                </InputLabel>
                                <Select
                                    labelId="assignto-select-label"
                                    id="assigned_to"
                                    name="assigned_to"
                                    value={assigntovalue}
                                    onChange={(e) => setAssigntovalue(e.target.value)}
                                    label="Assign To"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a User</em>
                                    </MenuItem>
                                    {assignto && assignto !== undefined
                                        ? assignto.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.username}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    labelId="status-select-label"
                                    id="status-select"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    label="Status"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a Status</em>
                                    </MenuItem>
                                    <MenuItem value="Pending">Pending</MenuItem>
                                    <MenuItem value="Follow Up">Follow Up</MenuItem>
                                    <MenuItem value="Completed">Completed</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <LocalizationProvider dateAdapter={AdapterDateFns} className={classes.select}>
                                <DateTimePicker
                                    className={classes.label}
                                    renderInput={(props) => <TextField {...props} fullWidth />}
                                    label="Date and Time"
                                    value={selectedDate}
                                    onChange={handleDateChange}
                                    fullWidth
                                />
                            </LocalizationProvider>
                        </Grid>
                        <Grid item xs={12} md={6} xl={6}>
                            <TextField
                                //size="small"
                                label="Comments"
                                id="comment"
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={6} xl={6} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    onClick={handleSubmit}
                                    //startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Create
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Grid>
            </Card>
        </div>
    );
};

export default withAuth(SamplePage);
