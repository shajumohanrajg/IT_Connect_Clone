import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Card, Box, Typography, Stack, Button, Modal, Grid, TextField, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
//import { Typography } from 'tabler-icons-react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';

import { useMediaQuery } from '@mui/material';
import Axios from 'axios';
import { makeStyles } from '@mui/styles';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import EditIcon from '@mui/icons-material/Edit';
import React, { useEffect, useState } from 'react';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import withAuth from '../pages/authentication/authentication3/withAuth';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    boxShadow: 24,
    p: 4
};
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },

    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                color: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    inputprops: {
        //backgroundColor: 'white',
        //color: 'black'
    },
    input1: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",
        backgroundColor: 'transparent',
        //color: 'black',
        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                fontcolor: 'black',
                backgroundColor: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        animationDuration: '10ms',
        //backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        //backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));

function DataTable() {
    const columns1 = [
        {
            field: 'jobfor',
            headerName: 'Job For',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
            // renderCell: (params) => {
            //     const type = params.value;
            //     const isRent = type === 'Rent';
            //     const type1 = params.value;
            //     const isOwn = type1 === 'Own';

            //     return (
            //         <div>
            //             <span>{isRent ? 'R' : type}</span>
            //             <span>{isOwn ? 'O' : type1}</span>
            //         </div>
            //     );
            // }
        },
        {
            field: 'name',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'Name',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header',
            //flex: 0.2
            width: 200
            // cellClassName: "name-column--cell",
        },
        {
            field: 'status',
            headerName: 'Status',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
            // renderCell: (params) => {
            //     const type = params.value;
            //     const isRent = type === 'Rent';
            //     const type1 = params.value;
            //     const isOwn = type1 === 'Own';

            //     return (
            //         <div>
            //             <span>{isRent ? 'R' : type}</span>
            //             <span>{isOwn ? 'O' : type1}</span>
            //         </div>
            //     );
            // }
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            renderCell: (params) => (
                // <Button variant="outlined" onClick={() => handleEditClick(params.id)}>
                //     Edit
                // </Button>
                <IconButton aria-label="delete" size="large" onClick={() => handleEditClick(params.id)}>
                    <EditIcon fontSize="small" />
                </IconButton>
            )
        }
        // {
        //     headerName: 'Actions',
        //     field: 'action',
        //     flex: 1,
        //     headerClassName: 'super-app-theme--header',
        //     renderCell: (params) => (
        //         <div>
        //             <IconButton aria-label="delete" size="large" onClick={() => updateVendor(params.id)}>
        //                 <EditIcon fontSize="small" />
        //             </IconButton>

        //             {/* <IconButton aria-label="delete" color="error" size="large" onClick={() => deleteVendor(params.id)}>
        //                 <DeleteIcon fontSize="small" />
        //             </IconButton> */}
        //         </div>
        //     )
        // }
        // {
        //     field: 'url',
        //     headerName: 'URL',
        //     // valueFormatter: ({ value }) => "PO" + value,
        //     // cellClassName: "name-column--cell",
        //     //flex: 0.2
        //     width: 200
        // }
    ];

    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };
    const [openModel, setOpenModal] = React.useState(false);
    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        Axios.put(`http://localhost:1212/api/v1/job/jobtype/${selectedRowId}/`, matData, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                console.log('Data updated successfully:', response.data);
                // Perform any necessary actions after successful data update
            })
            .catch((error) => {
                console.log('Error updating data:', error);
                // Handle any errors that occur during the update process
            });
    };

    const [selectedRowId, setSelectedRowId] = React.useState(null);

    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`http://localhost:1212/api/v1/job/jobtype/${id}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                setMatData(data);
                setOpenModal(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [jobfor, setJobfor] = useState([]);
    const [jobforvalue, setJobforvalue] = useState('');

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/jobfor', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobfor(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const [name, setName] = useState('');
    const [status, setStatus] = useState('');
    const handleClose = () => {
        setSelectedRowId(null);
        setOpenModal(false);
    };
    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    // const updateVendor = (id) => {
    //     // console.log(id)
    //     history.push(`/dashboard/bomat_update4/${id}`);
    //     window.location.reload();
    // };

    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [jobtype, setJobtype] = React.useState([]);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/jobtype', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobtype(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const [matData, setMatData] = React.useState([
        {
            name: '',
            status: null,
            jobfor: null,
            created_by: 1,
            modified_by: 1
        }
    ]);

    // const [selectedJobfor, setSelectedJobfor] = useState('');

    // useEffect(() => {
    //     if (matData.length > 0) {
    //         const matchedJobfor = jobfor.find((option) => option.id === matData[0].jobfor);
    //         if (matchedJobfor) {
    //             setSelectedJobfor(matchedJobfor.id);
    //         } else {
    //             setSelectedJobfor('');
    //         }
    //     } else {
    //         setSelectedJobfor('');
    //     }
    // }, [jobfor, matData]);

    // console.log(selectedJobfor);

    // const jobCategory = jobfor.find((category) => category.name === jobtype.jobfor);

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', boxShadow: 0 }}>
            {/* <Stack direction={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center">
                <List>
                    <ListItem>
                        <ListItemAvatar>
                            <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                <StoreOutlinedIcon sx={{ color: 'white' }} />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText>
                            {' '}
                            <Typography variant="h3" color="black">
                                Hoarding Table
                            </Typography>
                        </ListItemText>
                    </ListItem>
                </List>
                <Button
                    className={classes.Button}
                    variant="contained"
                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                    //onClick={handleOpen}
                    href="/hoardingform"
                    startIcon={<AddCircleOutlinedIcon />}
                >
                    Hoarding
                </Button>
            </Stack> */}

            <Modal open={modalOpen} onClose={handleCloseModal}>
                <div>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: 'auto' }} />
                </div>
            </Modal>
            <Card sx={{ boxShadow: 2 }}>
                <Box
                    //id="invoice-container"
                    height="60vh"
                    width="100%"
                    fontWeight={10}
                    //className={classes.customButton}
                    sx={{
                        //width: '100%',
                        //border: '2px solid #fff2ea',
                        p: 2,
                        height: isSmallScreen ? '90vh' : '60vh',
                        width: '100%',
                        borderRadius: 5,
                        '& .MuiDataGrid-root': {
                            border: 'none',
                            padding: 1
                            //border: '2px dashed grey'
                        },
                        '& .super-app-theme--header': {
                            //backgroundColor: 'rgba(255, 7, 0, 0.55)',
                            //color: 'orange !important',
                            //fontWeight: 'bold !important'
                            //fontWeight: '700 !important',
                            //color: 'white !important'
                        },
                        '& .super-app-theme--cell': {
                            //backgroundColor: 'primary',
                            //color: '#1a3e72 !important',
                            //fontWeight: '600 !important',
                            //border: 1
                        },
                        '& .MuiDataGrid-cell': {
                            borderBottom: 'none !important',
                            //backgroundColor: '#f2f2f2',
                            color: 'black',
                            fontWeight: '550 !important'
                        },
                        '& .name-column--cell': {
                            variant: 'button',
                            fontWeight: 'medium',
                            color: 'ButtonText'
                        },
                        '& .MuiDataGrid-columnHeaders': {
                            //borderLeft: '2px dashed grey',
                            //borderRight: '2px dashed grey',
                            //borderBottom: '2px solid grey',
                            //fontWeight: 'bold !important',
                            //fontWeight: '700 !important',
                            //fontSize: 15,
                            //fontColor: 'red'
                            //backgroundColor: '#ff874b',
                            //borderRadius: 2
                            //color: 'white !important'
                        },

                        '.MuiDataGrid-columnHeaderTitle': {
                            //fontWeight: 'bold !important',
                            //fontWeight: '1000 !important',
                            //overflow: 'visible !important',
                            color: 'white',
                            width: 'auto',
                            paddingTop: '12px',
                            paddingBottom: '10px',
                            //paddingLeft: "8px",
                            //paddingRight: "24px",
                            textAlign: 'left',
                            fontSize: '0.80rem',
                            fontWeight: 700,
                            opacity: 0.7,
                            background: 'transparent',
                            color: '#8392ab',
                            borderRadius: 'none',
                            borderBottom: '0.0625rem solid #e9ecef'
                            //fontSize: 15
                        },
                        '& .MuiDataGrid-virtualScroller': {
                            //opacity: 1,
                            //transition: 'opacity 0.2s',
                            //overflowY: 'auto',
                            overflowX: 'auto',
                            '&::-webkit-scrollbar': {
                                width: '4px',
                                backgroundColor: '#F5F5F5'
                            },
                            '&::-webkit-scrollbar-thumb': {
                                //backgroundColor: '#11cdef',
                                borderRadius: '4px'
                            }
                        },
                        '& .MuiDataGrid-footerContainer': {
                            color: '#8392ab',
                            border: 'none'
                        },
                        '& .MuiDataGrid-columnSeparator': {
                            visibility: 'hidden'
                        },
                        '&.MuiDataGrid-pagination': {
                            //backgroundColor: "red",
                            //padding: "10px",
                            width: '20px !important'
                        },

                        '&.MuiDataGrid-virtualScroller': {
                            opacity: 0,
                            transition: 'opacity 0.2s'
                        },
                        '&.MuiTablePagination-root': {
                            width: '20px'
                        },

                        '&.MuiDataGrid-virtualScroller:hover': {
                            opacity: 1
                        },
                        '& .MuiTablePagination-select': {
                            //paddingRight: 2,
                            width: '10px !important'
                        },
                        '& .MuiTablePagination-selectIcon': {
                            display: 'none'
                        },

                        '&.MuiDataGrid-toolbar .MuiDataGrid-menuList': {
                            padding: 0
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root': {
                            fontSize: '14px',
                            color: '#333'
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root:hover': {
                            backgroundColor: '#f0f0f0'
                        }
                    }}
                >
                    <DataGrid
                        rows={jobtype}
                        //columns={columns1}
                        columns={columns1}
                        pageSize={5}
                        getRowId={(row) => row.id}
                        components={{ Toolbar: GridToolbar, color: 'primary' }}
                        componentsProps={{
                            toolbar: {
                                showQuickFilter: true,
                                quickFilterProps: { debounceMs: 500 },
                                color: 'primary'
                            }
                        }}
                        loading={loading}
                        //autoHeight
                        //scrollbarSize={100}
                        //pageSize={5}
                        //checkboxSelection
                        //touchRipple
                        //disableColumnMenu
                        // onRowClick={handleRowClick}
                        disableColumnFilter={isSmallScreen ? true : false}
                        disableDensitySelector={isSmallScreen ? true : false}
                        virtualization
                    />
                </Box>
            </Card>

            <Modal open={!!selectedRowId} onClose={handleClose}>
                <Box sx={style}>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <List sx={{ width: '100%', maxWidth: 360 }}>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                        <AddAPhotoOutlinedIcon />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    <Typography variant="h3">Update Class #{selectedRowId}</Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="jobfor-select-label">
                                    Job For
                                </InputLabel>
                                <Select
                                    labelId="jobfor-select-label"
                                    id="jobfor-select"
                                    // value={matData.jobfor}
                                    //onChange={(e) => setMatData({ ...matData, jobfor: e.target.value })}
                                    onChange={(e) => setMatData({ ...matData, jobfor: e.target.value })}
                                    value={matData.jobfor || ''}
                                    // onChange={(e) => setSelectedJobfor(e.target.value)}
                                    // value={jobforvalue}
                                    // onChange={(e) => setJobforvalue(e.target.value)}
                                    label="Job For"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select Job For</em>
                                    </MenuItem>
                                    {jobfor && jobfor !== undefined
                                        ? jobfor.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                    {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Name"
                                id="name"
                                value={matData.name}
                                onChange={(e) => setMatData({ ...matData, name: e.target.value })}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            {/* <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    labelId="status-select-label"
                                    id="status-select"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    //label="Status"
                                    //displayEmpty
                                    //inputProps={{ 'aria-label': 'Without label' }}
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="" disabled>
                                        <em>{matData.status}</em>
                                    </MenuItem>
                                    <MenuItem value="Active">Active</MenuItem>
                                    <MenuItem value="Inactive">Inactive</MenuItem>
                                </Select>
                            </FormControl> */}
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    value={matData.status || ''}
                                    onChange={(e) => setMatData({ ...matData, status: e.target.value })}
                                    label="Status"
                                >
                                    <MenuItem value="Active">Active</MenuItem>
                                    <MenuItem value="Inactive">Inactive</MenuItem>
                                    {/* Add more MenuItem components for other age options */}
                                </Select>
                            </FormControl>
                        </Grid>

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    onClick={handleSubmit}
                                    //startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Update
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Modal>

            {/* <Modal open={modalOpen} onClose={handleCloseModal} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ maxWidth: '90vw', maxHeight: '90vh' }}>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                    <IconButton
                        onClick={handleCloseModal}
                        style={{ position: 'absolute', top: 10, right: 10, color: 'white', backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </div>
            </Modal> */}
        </Card>
    );
}

export default withAuth(DataTable);
