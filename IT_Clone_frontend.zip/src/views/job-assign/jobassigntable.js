import { Button, Card, FormControl, Grid, InputLabel, MenuItem, Modal, Select, Stack, TextField } from '@mui/material';
import { GridToolbar } from '@mui/x-data-grid';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';

import EditIcon from '@mui/icons-material/Edit';
import { IconButton, useMediaQuery } from '@mui/material';
import Axios from 'axios';
import React, { useState } from 'react';
import CustomDataGrid from './CustomDataGrid';
import FormBox from './FormBox';
import HeaderForm from './headerform';
import useStyles from './styles';
import withAuth from '../pages/authentication/authentication3/withAuth';
import { useParams, useNavigate } from 'react-router-dom';
function DataTable() {
    const navigate = useNavigate();
    const columns1 = [
        {
            field: 'jobfor',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'Job For',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header',
            //flex: 0.2
            width: 200
            // cellClassName: "name-column--cell",
        },
        {
            field: 'jobtype',
            headerName: 'Job Type',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'designtype',
            headerName: 'Design Type',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'showroom',
            headerName: 'Showroom',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'assigned_to',
            headerName: 'Assign To',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'priority',
            headerName: 'Priority',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'status',
            headerName: 'Status',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        {
            field: 'dead_Line',
            headerName: 'Dead Line',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
        },
        ,
        {
            headerName: 'Actions',
            field: 'action',
            flex: 1,
            headerClassName: 'super-app-theme--header',
            renderCell: (params) => (
                <div>
                    <IconButton aria-label="view" color="warning" size="large" onClick={() => viewShowrooms(params.id)}>
                        {/* <VisibilityIcon fontSize="small" /> */}
                    </IconButton>
                </div>
            )
        }

        // {
        //     field: 'actions',
        //     headerName: 'Actions',
        //     width: 150,
        //     renderCell: (params) => (
        //         // <Button variant="outlined" onClick={() => handleEditClick(params.id)}>
        //         //     Edit
        //         // </Button>
        //         <IconButton aria-label="delete" size="large" onClick={() => handleEditClick(params.id)}>
        //             <EditIcon fontSize="small" />
        //         </IconButton>
        //     )
        // }
        // {
        //     headerName: 'Actions',
        //     field: 'action',
        //     flex: 1,
        //     headerClassName: 'super-app-theme--header',
        //     renderCell: (params) => (
        //         <div>
        //             <IconButton aria-label="delete" size="large" onClick={() => updateVendor(params.id)}>
        //                 <EditIcon fontSize="small" />
        //             </IconButton>

        //             {/* <IconButton aria-label="delete" color="error" size="large" onClick={() => deleteVendor(params.id)}>
        //                 <DeleteIcon fontSize="small" />
        //             </IconButton> */}
        //         </div>
        //     )
        // }
    ];

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/jobassignupdate/${id}`);
        window.location.reload();
    };

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        Axios.put(`http://localhost:1212/api/v1/OMM2/class_mgmt/${selectedRowId}/`, matData, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                console.log('Data updated successfully:', response.data);
                // Perform any necessary actions after successful data update
            })
            .catch((error) => {
                console.log('Error updating data:', error);
                // Handle any errors that occur during the update process
            });
    };

    const [matData, setMatData] = React.useState([
        {
            name: '',
            status: null,
            created_by: 1,
            modified_by: 1
        }
    ]);

    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`http://localhost:1212/api/v1/job/job/${id}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                setMatData(data);
                setOpenModal(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [name, setName] = useState('');
    const [status, setStatus] = useState(matData.status);

    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [floordiadata, setFloordiadata] = React.useState([]);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/job/job', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setFloordiadata(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', boxShadow: 0 }}>
            <CustomDataGrid
                isSmallScreen={true}
                rows={floordiadata}
                columns={columns1}
                // Add any additional props you want to pass
                //autoHeight={true}
                //checkboxSelection={true}
                //pageSize={10}
                // ...and other available props
                getRowId={(row) => row.id}
                components={{ Toolbar: GridToolbar, color: 'primary' }}
                componentsProps={{
                    toolbar: {
                        showQuickFilter: true,
                        quickFilterProps: { debounceMs: 500 },
                        color: 'primary'
                    }
                }}
                loading={loading}
                //autoHeight
                //scrollbarSize={100}
                //pageSize={5}
                //checkboxSelection
                //touchRipple
                //disableColumnMenu
                // onRowClick={handleRowClick}
                disableColumnFilter={isSmallScreen ? true : false}
                disableDensitySelector={isSmallScreen ? true : false}
                virtualization
            />
        </Card>
    );
}

export default withAuth(DataTable);
