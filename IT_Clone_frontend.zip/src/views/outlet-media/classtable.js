import { Button, Card, FormControl, Grid, InputLabel, MenuItem, Modal, Select, Stack, TextField } from '@mui/material';
import { GridToolbar } from '@mui/x-data-grid';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';

import EditIcon from '@mui/icons-material/Edit';
import { IconButton, useMediaQuery } from '@mui/material';
import Axios from 'axios';
import React, { useState } from 'react';
import CustomDataGrid from './CustomDataGrid';
import FormBox from './FormBox';
import HeaderForm from './headerform';
import useStyles from './styles';
import withAuth from '../pages/authentication/authentication3/withAuth';

function DataTable() {
    const columns1 = [
        {
            field: 'name',
            // valueFormatter: ({ value }) => "PO" + value,
            headerName: 'Name',
            cellClassName: 'super-app-theme--cell',
            headerClassName: 'super-app-theme--header',
            //flex: 0.2
            width: 200
            // cellClassName: "name-column--cell",
        },
        {
            field: 'status',
            headerName: 'Status',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: 120
            // renderCell: (params) => {
            //     const type = params.value;
            //     const isRent = type === 'Rent';
            //     const type1 = params.value;
            //     const isOwn = type1 === 'Own';

            //     return (
            //         <div>
            //             <span>{isRent ? 'R' : type}</span>
            //             <span>{isOwn ? 'O' : type1}</span>
            //         </div>
            //     );
            // }
        },
        {
            field: 'actions',
            headerName: 'Actions',
            width: 150,
            renderCell: (params) => (
                // <Button variant="outlined" onClick={() => handleEditClick(params.id)}>
                //     Edit
                // </Button>
                <IconButton aria-label="delete" size="large" onClick={() => handleEditClick(params.id)}>
                    <EditIcon fontSize="small" />
                </IconButton>
            )
        }
        // {
        //     headerName: 'Actions',
        //     field: 'action',
        //     flex: 1,
        //     headerClassName: 'super-app-theme--header',
        //     renderCell: (params) => (
        //         <div>
        //             <IconButton aria-label="delete" size="large" onClick={() => updateVendor(params.id)}>
        //                 <EditIcon fontSize="small" />
        //             </IconButton>

        //             {/* <IconButton aria-label="delete" color="error" size="large" onClick={() => deleteVendor(params.id)}>
        //                 <DeleteIcon fontSize="small" />
        //             </IconButton> */}
        //         </div>
        //     )
        // }
    ];

    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };
    const [openModel, setOpenModal] = React.useState(false);
    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        Axios.put(`http://localhost:1212/api/v1/OMM2/class_mgmt/${selectedRowId}/`, matData, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                console.log('Data updated successfully:', response.data);
                // Perform any necessary actions after successful data update
            })
            .catch((error) => {
                console.log('Error updating data:', error);
                // Handle any errors that occur during the update process
            });
    };

    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const [matData, setMatData] = React.useState([
        {
            name: '',
            status: null,
            created_by: 1,
            modified_by: 1
        }
    ]);

    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`http://localhost:1212/api/v1/OMM2/class_mgmt/${id}/`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                setMatData(data);
                setOpenModal(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [name, setName] = useState('');
    const [status, setStatus] = useState(matData.status);
    const handleClose = () => {
        setSelectedRowId(null);
        setOpenModal(false);
    };
    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [floordiadata, setFloordiadata] = React.useState([]);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get('http://localhost:1212/api/v1/OMM2/class_mgmt', {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setFloordiadata(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', boxShadow: 0 }}>
            <Modal open={modalOpen} onClose={handleCloseModal}>
                <div>
                    <img src={selectedImage} alt="Selected" style={{ width: '100%', height: 'auto' }} />
                </div>
            </Modal>

            <Modal open={!!selectedRowId} onClose={handleClose}>
                <FormBox>
                    <HeaderForm icon={<StoreOutlinedIcon />} text="Create Class" iconColor="#ffffff" variant="h3" />

                    <Grid item xs={12} md={12} xl={12}>
                        <TextField
                            //size="small"
                            label="Name"
                            id="name"
                            value={matData.name}
                            onChange={(e) => setMatData({ ...matData, name: e.target.value })}
                            fullWidth
                            //type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={12} xl={12}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="status-select-label">
                                Status
                            </InputLabel>
                            <Select
                                value={matData.status || ''}
                                onChange={(e) => setMatData({ ...matData, status: e.target.value })}
                                label="Status"
                            >
                                <MenuItem value="Active">Active</MenuItem>
                                <MenuItem value="Inactive">Inactive</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>

                    <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                        <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                            {' '}
                            <Button
                                className={classes.Button}
                                variant="contained"
                                onClick={handleSubmit}
                                //startIcon={<FileUploadOutlinedIcon />}
                            >
                                Update
                            </Button>
                        </Stack>
                    </Grid>
                </FormBox>
            </Modal>

            <CustomDataGrid
                isSmallScreen={true}
                rows={floordiadata}
                columns={columns1}
                // Add any additional props you want to pass
                //autoHeight={true}
                //checkboxSelection={true}
                //pageSize={10}
                // ...and other available props
                getRowId={(row) => row.id}
                components={{ Toolbar: GridToolbar, color: 'primary' }}
                componentsProps={{
                    toolbar: {
                        showQuickFilter: true,
                        quickFilterProps: { debounceMs: 500 },
                        color: 'primary'
                    }
                }}
                loading={loading}
                //autoHeight
                //scrollbarSize={100}
                //pageSize={5}
                //checkboxSelection
                //touchRipple
                //disableColumnMenu
                // onRowClick={handleRowClick}
                disableColumnFilter={isSmallScreen ? true : false}
                disableDensitySelector={isSmallScreen ? true : false}
                virtualization
            />
        </Card>
    );
}

export default withAuth(DataTable);
