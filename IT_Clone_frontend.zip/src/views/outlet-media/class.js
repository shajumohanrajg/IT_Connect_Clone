// material-ui

import { Button, FormControl, Grid, InputLabel, MenuItem, Select, Stack, TextField } from '@mui/material';
import React, { useState } from 'react';

// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import Modal from '@mui/material/Modal';
import Axios from 'axios';
import Table from './classtable';
import useStyles from './styles';

import CustomList from './headercard';

import CustomForm from './headerform';

import CustomCard from './HeaderCustomCard';

import FormBox from './FormBox';
import withAuth from '../pages/authentication/authentication3/withAuth';
// ==============================|| SAMPLE PAGE ||============================== //

const SamplePage = () => {
    const classes = useStyles();
    const [location, setLocation] = useState('');

    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };
    const [name, setName] = useState('');
    const [status, setStatus] = useState('');

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();
        Axios.post(
            'http://localhost:1212/api/v1/OMM2/class_mgmt/',
            {
                // id: id,
                name: name,
                status: status,
                created_by: 1,
                modified_by: 1
            },
            {
                headers: {
                    Authorization: `Token ${token}` // Include the token in the request headers
                }
            }
        ).then(
            (response) => {
                // enqueueSnackbar('Data Entry Successful', {
                //     variant: 'success',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(response);

                //navigate('/success');
                // history.push('/dashboard/bomat_table2');
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            },
            (error) => {
                // enqueueSnackbar('Check Data and Try Again', {
                //     variant: 'Error',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(error);
            }
        );
    };
    return (
        <div>
            <CustomCard>
                <CustomList icon={<StoreOutlinedIcon />} text="Class Management" iconColor="#ffffff" variant="h3" />
                <Button className={classes.Button} variant="contained" onClick={handleOpen} startIcon={<AddCircleOutlinedIcon />}>
                    Class
                </Button>
            </CustomCard>
            <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                <FormBox>
                    <CustomForm icon={<StoreOutlinedIcon />} text="Create Class" iconColor="#ffffff" variant="h3" />
                    <Grid item xs={12} md={12} xl={12}>
                        <TextField
                            //size="small"
                            label="Name"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            fullWidth
                            //type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={12} xl={12}>
                        <FormControl fullWidth className={classes.select}>
                            <InputLabel className={classes.label} id="status-select-label">
                                Status
                            </InputLabel>
                            <Select
                                labelId="status-select-label"
                                id="status-select"
                                value={status}
                                onChange={(e) => setStatus(e.target.value)}
                                label="Status"
                                //displayEmpty
                                //className={classes.selectEmpty}
                                //className={classes.select}
                            >
                                <MenuItem value="">
                                    <em>Select a Status</em>
                                </MenuItem>
                                <MenuItem value="Active">Active</MenuItem>
                                <MenuItem value="Inactive">Inactive</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>

                    <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                        <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                            {' '}
                            <Button
                                className={classes.Button}
                                variant="contained"
                                onClick={handleSubmit}
                                //startIcon={<FileUploadOutlinedIcon />}
                            >
                                Create
                            </Button>
                        </Stack>
                    </Grid>
                </FormBox>
            </Modal>
            <br></br>
            <Table />
        </div>
    );
};

export default withAuth(SamplePage);
