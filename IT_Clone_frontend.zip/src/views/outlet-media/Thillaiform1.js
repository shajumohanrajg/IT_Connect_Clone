import { useState } from 'react';
import {
    TextField,
    Checkbox,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Button,
    Input,
    FormGroup,
    FormControlLabel
} from '@material-ui/core';

const MyForm = () => {
    const [name, setName] = useState('');
    const [gender, setGender] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState(null);
    const [birthTime, setBirthTime] = useState(null);
    const [motherTongue, setMotherTongue] = useState('');
    const [photo, setPhoto] = useState(null);
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [physicalStatus, setPhysicalStatus] = useState('');
    const [bodyType, setBodyType] = useState('');
    const [complexion, setComplexion] = useState('');
    const [foodHabit, setFoodHabit] = useState('');
    const [fatherName, setFatherName] = useState('');
    const [fatherJob, setFatherJob] = useState('');
    const [motherName, setMotherName] = useState('');
    const [noOfBrother, setNoOfBrother] = useState('');
    const [brotherMarried, setBrotherMarried] = useState(false);
    const [noOfSister, setNoOfSister] = useState('');
    const [sisterMarried, setSisterMarried] = useState(false);
    const [educationalQualification, setEducationalQualification] = useState('');
    const [job, setJob] = useState('');
    const [incomePerMonth, setIncomePerMonth] = useState('');
    const [religious, setReligious] = useState('');
    const [contactPerson, setContactPerson] = useState('');
    const [contactNo, setContactNo] = useState('');
    const [whatsApp, setWhatsApp] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [district, setDistrict] = useState('');
    const [state, setState] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    return (
        <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={6}>
                    {/* <TextField
            fullWidth
            id="supplier_channel"
            label="Vendor Channel"
            select
            unique
            onChange={(e) => handleState(e.target.value)}
            variant="outlined"
          >
            <MenuItem disabled>Select Channel</MenuItem>
            {arrayUniqueByStateName &&
            arrayUniqueByStateName !== undefined
              ? arrayUniqueByStateName.map((option, index) => (
                  <MenuItem key={index} value={option.id}>
                    {option.supplier_channel}
                  </MenuItem>
                ))
              : "No State"}
          </TextField> */}
                    <TextField label="Name" value={name} onChange={(e) => setName(e.target.value)} />
                </Grid>
            </Grid>
            <FormControl>
                <InputLabel id="gender-label">Gender</InputLabel>
                <Select labelId="gender-label" value={gender} onChange={(e) => setGender(e.target.value)}>
                    <MenuItem value="male">Male</MenuItem>
                    <MenuItem value="female">Female</MenuItem>
                    <MenuItem value="other">Other</MenuItem>
                </Select>
            </FormControl>
            <TextField label="Date of Birth" type="date" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} />
            {/* <DatePicker label="Date of Birth" value={dateOfBirth} onChange={(date) => setDateOfBirth(date)} /> */}
            <TextField label="Birth Time" value={birthTime} onChange={(e) => setBirthTime(e.target.value)} />
            {/* <TimePicker label="Birth Time" value={birthTime} onChange={(time) => setBirthTime(time)} /> */}
            <FormControl>
                <InputLabel id="mother-tongue-label">Mother Tongue</InputLabel>
                <Select labelId="mother-tongue-label" value={motherTongue} onChange={(e) => setMotherTongue(e.target.value)}>
                    <MenuItem value="tamil">Tamil</MenuItem>
                    <MenuItem value="english">English</MenuItem>
                    <MenuItem value="spanish">Spanish</MenuItem>
                    <MenuItem value="chinese">Chinese</MenuItem>
                    {/* add more options here */}
                </Select>
            </FormControl>
            <Input type="file" onChange={(e) => setPhoto(e.target.files[0])} />
            <Button variant="contained" component="label">
                Upload Photo
                <input type="file" hidden onChange={(e) => setPhoto(e.target.files[0])} />
            </Button>
            <FormControl>
                <InputLabel id="height-label">Height</InputLabel>
                <Select labelId="height-label" value={height} onChange={(e) => setHeight(e.target.value)}>
                    <MenuItem value="4ft">4ft or less</MenuItem>
                    <MenuItem value="4ft 1in">4ft 1in</MenuItem>
                    <MenuItem value="4ft 2in">4ft 2in</MenuItem>
                    <MenuItem value="4ft 3in">4ft 3in</MenuItem>
                    <MenuItem value="4ft 4in">4ft 4in</MenuItem>
                    <MenuItem value="4ft 5in">4ft 5in</MenuItem>
                    <MenuItem value="4ft 6in">4ft 6in</MenuItem>
                    <MenuItem value="4ft 7in">4ft 7in</MenuItem>
                    <MenuItem value="4ft 8in">4ft 8in</MenuItem>
                    <MenuItem value="4ft 9in">4ft 9in</MenuItem>
                    <MenuItem value="4ft 10in">4ft 10in</MenuItem>
                    <MenuItem value="4ft 11in">4ft 11in</MenuItem>
                    <MenuItem value="5ft">5ft</MenuItem>
                    <MenuItem value="5ft 1in">5ft 1in</MenuItem>
                    <MenuItem value="5ft 2in">5ft 2in</MenuItem>
                    <MenuItem value="5ft 3in">5ft 3in</MenuItem>
                    <MenuItem value="5ft 4in">5ft 4in</MenuItem>
                    <MenuItem value="5ft 5in">5ft 5in</MenuItem>
                    <MenuItem value="5ft 6in">5ft 6in</MenuItem>
                    <MenuItem value="5ft 7in">5ft 7in</MenuItem>
                    <MenuItem value="5ft 8in">5ft 8in</MenuItem>
                    <MenuItem value="5ft 9in">5ft 9in</MenuItem>
                    <MenuItem value="5ft 10in">5ft 10in</MenuItem>
                </Select>
            </FormControl>
            <TextField label="Weight" value={weight} onChange={(e) => setWeight(e.target.value)} />
            <FormControl>
                <InputLabel id="physical-status-label">Physical Status</InputLabel>
                <Select labelId="physical-status-label" value={physicalStatus} onChange={(e) => setPhysicalStatus(e.target.value)}>
                    <MenuItem value="normal">Normal</MenuItem>
                    <MenuItem value="physically-challenged">Physically Challenged</MenuItem>
                </Select>
            </FormControl>
            <FormControl>
                <InputLabel id="body-type-label">Body Type</InputLabel>
                <Select labelId="body-type-label" value={bodyType} onChange={(e) => setBodyType(e.target.value)}>
                    <MenuItem value="slim">Slim</MenuItem>
                    <MenuItem value="athletic">Athletic</MenuItem>
                    <MenuItem value="average">Average</MenuItem>
                    <MenuItem value="heavy">Heavy</MenuItem>
                </Select>
            </FormControl>
            <FormControl>
                <InputLabel id="complexion-label">Complexion</InputLabel>
                <Select labelId="complexion-label" value={complexion} onChange={(e) => setComplexion(e.target.value)}>
                    <MenuItem value="fair">Fair</MenuItem>
                    <MenuItem value="wheatish">Wheatish</MenuItem>
                    <MenuItem value="dark">Dark</MenuItem>
                </Select>
            </FormControl>
            <FormControl>
                <InputLabel id="food-habit-label">Food Habit</InputLabel>
                <Select labelId="food-habit-label" value={foodHabit} onChange={(e) => setFoodHabit(e.target.value)}>
                    <MenuItem value="vegetarian">Vegetarian</MenuItem>
                    <MenuItem value="non-vegetarian">Non-Vegetarian</MenuItem>
                    <MenuItem value="eggetarian">Eggetarian</MenuItem>
                </Select>
            </FormControl>
            <TextField label="Father's Name" value={fatherName} onChange={(e) => setFatherName(e.target.value)} />
            <TextField label="Father's Job" value={fatherJob} onChange={(e) => setFatherJob(e.target.value)} />
            <TextField label="Mother's Name" value={motherName} onChange={(e) => setMotherName(e.target.value)} />
            <TextField label="Number of Brothers" value={noOfBrother} onChange={(e) => setNoOfBrother(e.target.value)} />
            <FormGroup>
                <FormControlLabel
                    control={<Checkbox checked={brotherMarried} onChange={(e) => setBrotherMarried(e.target.checked)} />}
                    label="Brother Married"
                />
            </FormGroup>
            <TextField label="Number of Sisters" value={noOfSister} onChange={(e) => setNoOfSister(e.target.value)} />
            <FormGroup>
                <FormControlLabel
                    control={<Checkbox checked={sisterMarried} onChange={(e) => setSisterMarried(e.target.checked)} />}
                    label="Sister Married"
                />
            </FormGroup>
            <TextField
                label="Educational Qualification"
                value={educationalQualification}
                onChange={(e) => setEducationalQualification(e.target.value)}
            />
            <TextField label="Job" value={job} onChange={(e) => setJob(e.target.value)} />
            <TextField label="Income per Month" value={incomePerMonth} onChange={(e) => setIncomePerMonth(e.target.value)} />
            <FormControl></FormControl>
            <FormControl>
                <InputLabel id="religious-label">Religious</InputLabel>
                <Select labelId="religious-label" value={religious} onChange={(e) => setReligious(e.target.value)}>
                    <MenuItem value="hindu">Hindu</MenuItem>
                    <MenuItem value="muslim">Muslim</MenuItem>
                </Select>
            </FormControl>
            <TextField label="Contact Person" value={contactPerson} onChange={(e) => setContactPerson(e.target.value)} />
            <TextField label="Contact Number" value={contactNo} onChange={(e) => setContactNo(e.target.value)} />
            <TextField label="WhatsApp Number" value={whatsApp} onChange={(e) => setWhatsApp(e.target.value)} />
            <TextField label="Address" value={address} onChange={(e) => setAddress(e.target.value)} />
            <TextField label="City" value={city} onChange={(e) => setCity(e.target.value)} />
            <TextField label="District" value={district} onChange={(e) => setDistrict(e.target.value)} />
            <FormControl>
                <InputLabel id="state-label">State</InputLabel>
                <Select labelId="state-label" value={state} onChange={(e) => setState(e.target.value)}>
                    <MenuItem value="Andhra Pradesh">Andhra Pradesh</MenuItem>
                    <MenuItem value="Arunachal Pradesh">Arunachal Pradesh</MenuItem>
                    <MenuItem value="Assam">Assam</MenuItem>
                    <MenuItem value="Bihar">Bihar</MenuItem>
                    <MenuItem value="Chhattisgarh">Chhattisgarh</MenuItem>
                    <MenuItem value="Goa">Goa</MenuItem>
                    <MenuItem value="Gujarat">Gujarat</MenuItem>
                    <MenuItem value="Haryana">Haryana</MenuItem>
                    <MenuItem value="Himachal Pradesh">Himachal Pradesh</MenuItem>
                    <MenuItem value="Jharkhand">Jharkhand</MenuItem>
                    <MenuItem value="Karnataka">Karnataka</MenuItem>
                    <MenuItem value="Kerala">Kerala</MenuItem>
                    <MenuItem value="Madhya Pradesh">Madhya Pradesh</MenuItem>
                    <MenuItem value="Maharashtra">Maharashtra</MenuItem>
                    <MenuItem value="Manipur">Manipur</MenuItem>
                    <MenuItem value="Meghalaya">Meghalaya</MenuItem>
                    <MenuItem value="Mizoram">Mizoram</MenuItem>
                    <MenuItem value="Nagaland">Nagaland</MenuItem>
                    <MenuItem value="Odisha">Odisha</MenuItem>
                    <MenuItem value="Punjab">Punjab</MenuItem>
                    <MenuItem value="Rajasthan">Rajasthan</MenuItem>
                    <MenuItem value="Sikkim">Sikkim</MenuItem>
                    <MenuItem value="Tamil Nadu">Tamil Nadu</MenuItem>
                    <MenuItem value="Telangana">Telangana</MenuItem>
                    <MenuItem value="Tripura">Tripura</MenuItem>
                    <MenuItem value="Uttar Pradesh">Uttar Pradesh</MenuItem>
                    <MenuItem value="Uttarakhand">Uttarakhand</MenuItem>
                    <MenuItem value="West Bengal">West Bengal</MenuItem>
                </Select>
            </FormControl>

            {/* add other form fields */}
            <Button type="submit">Submit</Button>
        </form>
    );
};

export default MyForm;
