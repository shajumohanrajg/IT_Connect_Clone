// material-ui

import React, { useState } from 'react';
import { makeStyles } from '@mui/styles';
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    TextField,
    Button,
    Input,
    Fab,
    Typography,
    Grid,
    Box,
    InputAdornment,
    Stack
} from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import WorkIcon from '@mui/icons-material/Work';
import BeachAccessIcon from '@mui/icons-material/BeachAccess';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import Modal from '@mui/material/Modal';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { OutlinedInput } from '@material-ui/core';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import withAuth from '../pages/authentication/authentication3/withAuth';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    stepper: {
        backgroundColor: 'transparent', // set your desired background color
        // padding: "16px", // adjust the padding as needed
        // borderRadius: "8px", // adjust the border radius as needed
        [theme.breakpoints.down('sm')]: {
            padding: theme.spacing(1)
        }
    },
    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                color: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px solid grey",
                backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    borderRadius: 5,
    boxShadow: 30,
    p: 4
};

const SamplePage = () => {
    const classes = useStyles();

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    return (
        <MainCard title="Floor Diagram">
            <div>
                <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/outletadform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Asset
                    </Button>
                </Stack>
                <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                    <Box sx={style}>
                        <Grid container spacing={2} justifyContent="center" alignItems="center">
                            <List sx={{ width: '100%', maxWidth: 360 }}>
                                <ListItem>
                                    <ListItemAvatar>
                                        <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                            <AddAPhotoOutlinedIcon />
                                        </Avatar>
                                    </ListItemAvatar>
                                    <ListItemText>
                                        <Typography variant="h3">Add Media Outlet Form</Typography>
                                    </ListItemText>
                                </ListItem>
                            </List>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="class-select-label">
                                        class
                                    </InputLabel>
                                    <Select
                                        labelId="class-select-label"
                                        id="class"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Class"
                                        name="class"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="status-select-label">
                                        Status
                                    </InputLabel>
                                    <Select
                                        labelId="status-select-label"
                                        id="status"
                                        name="status"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Status"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="location-select-label">
                                        Showroom Location
                                    </InputLabel>
                                    <Select
                                        labelId="location-select-label"
                                        id="location"
                                        name="location"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Showroom Location"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>

                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="brandtype-select-label">
                                        Branding Type
                                    </InputLabel>
                                    <Select
                                        labelId="brandtype-select-label"
                                        id="brandtype"
                                        name="brandtype"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Branding Type"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="brandloc-select-label">
                                        Branding Location
                                    </InputLabel>
                                    <Select
                                        labelId="brandloc-select-label"
                                        id="brandlocation"
                                        name="brandlocation"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Branding Location"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="brand-select-label">
                                        Brand
                                    </InputLabel>
                                    <Select
                                        labelId="brand-select-label"
                                        id="brand"
                                        name="brand"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Brand"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <TextField
                                    //size="small"
                                    label="Width"
                                    id="width"
                                    name="width"
                                    //value={weight}
                                    //onChange={(e) => setWeight(e.target.value)}
                                    fullWidth
                                    //type="number"
                                    variant="outlined"
                                    className={classes.input}
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            focused: classes.label
                                        }
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <TextField
                                    //size="small"
                                    label="Height"
                                    id="height"
                                    name="height"
                                    //value={weight}
                                    //onChange={(e) => setWeight(e.target.value)}
                                    fullWidth
                                    //type="number"
                                    variant="outlined"
                                    className={classes.input}
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            focused: classes.label
                                        }
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <TextField
                                    //size="small"
                                    label="Model Name"
                                    id="modelname"
                                    name="modelname"
                                    //value={weight}
                                    //onChange={(e) => setWeight(e.target.value)}
                                    fullWidth
                                    //type="number"
                                    variant="outlined"
                                    className={classes.input}
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            focused: classes.label
                                        }
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="vendor-select-label">
                                        Vendor
                                    </InputLabel>
                                    <Select
                                        labelId="vendor-select-label"
                                        id="vendor"
                                        name="vendor"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Vendor"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="material-select-label">
                                        Material
                                    </InputLabel>
                                    <Select
                                        labelId="material-select-label"
                                        id="material"
                                        name="material"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Material"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="lighttype-select-label">
                                        Light Type
                                    </InputLabel>
                                    <Select
                                        labelId="lighttype-select-label"
                                        id="lighttype"
                                        name="lighttype"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label="Light Type"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={12} xl={12} sx={{ mt: 2 }}>
                                <FormControl fullWidth variant="outlined" size="small" className={classes.select1}>
                                    <InputLabel className={classes.label} id="adimage">
                                        Ad Image
                                    </InputLabel>
                                    <OutlinedInput
                                        labelId="adimage"
                                        id="adimage"
                                        type="file"
                                        name="adimage"
                                        //className={classes.select}
                                        inputProps={{ accept: 'image/*' }}
                                        startAdornment={
                                            <InputAdornment position="start">
                                                <PhotoCameraIcon />
                                            </InputAdornment>
                                        }
                                        //onChange={handleImageChange2}
                                        fullWidth
                                        //margin="normal"
                                        variant="outlined"
                                        label="Ad Image"
                                        InputLabelProps={{
                                            classes: {
                                                //root: classes.label,
                                                //focused: classes.label
                                            }
                                        }}
                                    />
                                </FormControl>
                            </Grid>
                            {/* <Grid item xs={12} md={6} xl={4}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="adstatus-select-label">
                                        Ad Status
                                    </InputLabel>
                                    <Select
                                        labelId="adstatus-select-label"
                                        id="adstatus"
                                        name="adstatus"
                                        value={location}
                                        onChange={handleLocationChange}
                                        label=" Ad Status"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a location</em>
                                        </MenuItem>
                                        <MenuItem value="New York">New York</MenuItem>
                                        <MenuItem value="Los Angeles">Los Angeles</MenuItem>
                                        <MenuItem value="Chicago">Chicago</MenuItem>
                                        <MenuItem value="Houston">Houston</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid> */}
                            <Grid item xs={12} md={12} xl={12} sx={{ mt: 2 }}>
                                <FormControl fullWidth variant="outlined" size="small" className={classes.select1}>
                                    <InputLabel className={classes.label} id="assetimage">
                                        Asset Image
                                    </InputLabel>
                                    <OutlinedInput
                                        labelId="assetimage"
                                        id="assetimage"
                                        type="file"
                                        name="assetimage"
                                        //className={classes.select}
                                        inputProps={{ accept: 'image/*' }}
                                        startAdornment={
                                            <InputAdornment position="start">
                                                <PhotoCameraIcon />
                                            </InputAdornment>
                                        }
                                        //onChange={handleImageChange2}
                                        fullWidth
                                        //margin="normal"
                                        variant="outlined"
                                        label="Asset Image"
                                        InputLabelProps={{
                                            classes: {
                                                //root: classes.label,
                                                //focused: classes.label
                                            }
                                        }}
                                    />
                                </FormControl>
                            </Grid>
                            {/* <Grid item xs={12} md={6} xl={4}>
                                <TextField
                                    //size="small"
                                    label="Other Comments"
                                    id="comments"
                                    name="comments"
                                    //value={weight}
                                    //onChange={(e) => setWeight(e.target.value)}
                                    fullWidth
                                    //type="number"
                                    variant="outlined"
                                    className={classes.input}
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            focused: classes.label
                                        }
                                    }}
                                />
                            </Grid> */}

                            <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                                <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                    {' '}
                                    <Button
                                        className={classes.Button}
                                        variant="contained"
                                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                        onClick={handleOpen}
                                        startIcon={<FileUploadOutlinedIcon />}
                                    >
                                        Add
                                    </Button>
                                </Stack>
                            </Grid>
                        </Grid>
                    </Box>
                </Modal>
            </div>
        </MainCard>
    );
};

export default withAuth(SamplePage);
