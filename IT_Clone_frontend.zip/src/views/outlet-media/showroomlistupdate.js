// material-ui

import React, { useState, useEffect } from 'react';
import { makeStyles } from '@mui/styles';
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    TextField,
    Button,
    Input,
    Fab,
    Typography,
    Grid,
    Box,
    InputAdornment,
    Stack,
    Card
} from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import WorkIcon from '@mui/icons-material/Work';
import BeachAccessIcon from '@mui/icons-material/BeachAccess';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import Modal from '@mui/material/Modal';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { OutlinedInput } from '@material-ui/core';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import Axios from 'axios';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import Table from './360floordiatable';
import withAuth from '../pages/authentication/authentication3/withAuth';
import { useParams } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },

    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                color: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    inputprops: {
        //backgroundColor: 'white',
        //color: 'black'
    },
    input1: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",
        backgroundColor: 'transparent',
        //color: 'black',
        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                fontcolor: 'black',
                backgroundColor: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        animationDuration: '10ms',
        //backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        //backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    borderRadius: 5,
    boxShadow: 30,
    p: 4
};
const selectStyles = {
    backgroundColor: 'white',
    color: 'black'
};
const customStyles = {
    borderRadius: 50,
    animationDuration: '10ms',
    '& .MuiOutlinedInput-root': {
        '& fieldset': {
            borderRadius: 8,
            color: 'white'
        },
        '&:hover fieldset': {
            borderColor: '#999'
        },
        '&.Mui-focused fieldset': {
            borderColor: '#1a5f7a'
        }
    }
};

const SamplePage = () => {
    let { id } = useParams();
    const classes = useStyles();

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const [name, setName] = useState('');
    const [rsm, setRsm] = useState('');
    const [asm, setAsm] = useState('');
    const [manager, setManager] = useState('');
    const [cugNo, setCugNo] = useState('');
    const [landline, setLandline] = useState('');
    const [email, setEmail] = useState('');
    const [region, setRegion] = useState('');
    const [state, setState] = useState('');
    const [address, setAddress] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const [matData, setMatData] = React.useState([
        {
            name: '',

            created_by: 1,
            modified_by: 1,

            rsm: '',
            asm: '',
            manager: '',
            cug_no: '',
            landline: '',
            e_mail: '',
            region: '',
            state: '',
            address: ''
        }
    ]);

    const url = 'http://localhost:1212/api/v1/OMM2/showroom_mgmt/';
    useEffect(() => {
        const token = localStorage.getItem('token');
        // const id=props.match.params.id
        Axios.get(url + id, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((res) => {
                // console.log(res.data)
                setMatData(res.data);
            })
            .catch((err) => console.error(err));
    }, [id]);

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        e.preventDefault();

        Axios.put(`http://localhost:1212/api/v1/OMM2/showroom_mgmt/${id}/`, matData, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then((response) => {
                console.log('Data updated successfully:', response.data);
                // Perform any necessary actions after successful data update
            })
            .catch((error) => {
                console.log('Error updating data:', error);
                // Handle any errors that occur during the update process
            });
    };

    // const handleSubmit = (e) => {
    //     const token = localStorage.getItem('token');
    //     e.preventDefault();
    //     Axios.put(
    //         'http://localhost:1212/api/v1/OMM2/showroom_mgmt/',
    //         {
    //             // id: id,
    //             name: name,
    //             rsm: rsm,
    //             asm: asm,
    //             manager: manager,
    //             cug_no: cugNo,
    //             landline: landline,
    //             e_mail: email,
    //             region: region,
    //             state: state,
    //             address: address,
    //             created_by: 1,
    //             modified_by: 1
    //         },
    //         {
    //             headers: {
    //                 Authorization: `Token ${token}` // Include the token in the request headers
    //             }
    //         }
    //     ).then(
    //         (response) => {
    //             // enqueueSnackbar('Data Entry Successful', {
    //             //     variant: 'success',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(response);
    //             // history.push('/dashboard/bomat_table2');
    //             // setTimeout(() => {
    //             //     window.location.reload();
    //             // }, 1000);
    //         },
    //         (error) => {
    //             // enqueueSnackbar('Check Data and Try Again', {
    //             //     variant: 'Error',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(error);
    //         }
    //     );
    // };
    return (
        <MainCard title="Showroom Creation">
            <div>
                {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/outletadform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Asset
                    </Button>
                </Stack> */}

                <List sx={{ width: '100%', maxWidth: 360 }}>
                    <ListItem>
                        <ListItemAvatar>
                            <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                <AddAPhotoOutlinedIcon />
                            </Avatar>
                        </ListItemAvatar>
                        <ListItemText>
                            <Typography variant="h3">Update Showroom</Typography>
                        </ListItemText>
                    </ListItem>
                </List>
                <br></br>
                <Grid container spacing={2} justifyContent="center" alignItems="center">
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Showroom Name"
                            id="name"
                            name="name"
                            value={matData.name || ''}
                            onChange={(e) => setMatData({ ...matData, name: e.target.value })}
                            // value={name}
                            // onChange={(e) => setName(e.target.value)}
                            fullWidth
                            //type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Rsm"
                            id="rsm"
                            name="rsm"
                            value={matData.rsm || ''}
                            onChange={(e) => setMatData({ ...matData, rsm: e.target.value })}
                            // value={rsm}
                            // onChange={(e) => setRsm(e.target.value)}
                            fullWidth
                            //type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Asm"
                            id="asm"
                            name="asm"
                            value={matData.asm || ''}
                            onChange={(e) => setMatData({ ...matData, asm: e.target.value })}
                            // value={asm}
                            // onChange={(e) => setAsm(e.target.value)}
                            fullWidth
                            //type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="CUG No"
                            id="cug_no"
                            name="cug_no"
                            value={matData.cug_no || ''}
                            onChange={(e) => setMatData({ ...matData, cug_no: e.target.value })}
                            // value={cug_no}
                            // onChange={(e) => setCugNo(e.target.value)}
                            fullWidth
                            type="number"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Landline"
                            id="landline"
                            name="landline"
                            value={matData.landline || ''}
                            onChange={(e) => setMatData({ ...matData, landline: e.target.value })}
                            // value={landline}
                            // onChange={(e) => setLandline(e.target.value)}
                            fullWidth
                            type="tel"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Email"
                            id="e_mail"
                            name="e_mail"
                            value={matData.e_mail || ''}
                            onChange={(e) => setMatData({ ...matData, e_mail: e.target.value })}
                            // value={email}
                            // onChange={(e) => setEmail(e.target.value)}
                            fullWidth
                            type="email"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="Region"
                            id="region"
                            name="region"
                            value={matData.region || ''}
                            onChange={(e) => setMatData({ ...matData, region: e.target.value })}
                            // value={region}
                            // onChange={(e) => setRegion(e.target.value)}
                            fullWidth
                            //type="email"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>

                    <Grid item xs={12} md={6} xl={6}>
                        <TextField
                            //size="small"
                            label="State"
                            id="state"
                            name="state"
                            value={matData.state || ''}
                            onChange={(e) => setMatData({ ...matData, state: e.target.value })}
                            // value={state}
                            // onChange={(e) => setState(e.target.value)}
                            fullWidth
                            //type="email"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>
                    <Grid item xs={12} md={12} xl={12}>
                        <TextField
                            //size="small"
                            label="Address"
                            id="address"
                            name="address"
                            value={matData.address || ''}
                            onChange={(e) => setMatData({ ...matData, address: e.target.value })}
                            // value={address}
                            // onChange={(e) => setAddress(e.target.value)}
                            fullWidth
                            multiline={4}
                            //type="email"
                            variant="outlined"
                            className={classes.input}
                            InputLabelProps={{
                                classes: {
                                    //root: classes.label,
                                    focused: classes.label
                                }
                            }}
                        />
                    </Grid>

                    {/* <Grid item xs={12} md={6} xl={6} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                    onClick={handleSubmit}
                                    startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Add
                                </Button>
                            </Stack>
                        </Grid> */}

                    <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                        <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                            {' '}
                            <Button
                                className={classes.Button}
                                variant="contained"
                                onClick={handleSubmit}
                                //startIcon={<FileUploadOutlinedIcon />}
                            >
                                Update
                            </Button>
                        </Stack>
                    </Grid>
                </Grid>
            </div>
        </MainCard>
    );
};

export default withAuth(SamplePage);
