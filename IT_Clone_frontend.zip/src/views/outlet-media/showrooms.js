// material-ui

import { Button, Card, Stack, Typography } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import { makeStyles } from '@mui/styles';

// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import MainCard from 'ui-component/cards/MainCard';
import useStyles from './styles';

import CustomList from './headercard';

import CustomForm from './headerform';

import CustomCard from './HeaderCustomCard';

import FormBox from './FormBox';
import Showroomstable from './showroomstable';
import withAuth from '../pages/authentication/authentication3/withAuth';

const SamplePage = () => {
    const classes = useStyles();

    return (
        <div>
            <CustomCard>
                <CustomList icon={<StoreOutlinedIcon />} text="Showrooms" iconColor="#ffffff" variant="h3" />
                <Button className={classes.Button} variant="contained" startIcon={<AddCircleOutlinedIcon />} href="/showroomadd">
                    Showrooms
                </Button>
            </CustomCard>
            <br></br>
            <Showroomstable />
        </div>
    );
};

export default withAuth(SamplePage);
