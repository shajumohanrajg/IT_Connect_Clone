import React from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import ArgonBox from "components/ArgonBox";
import ArgonTypography from "components/ArgonTypography";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import { Select, MenuItem, Button } from "@mui/material";
//import ArgonTypography from "components/ArgonTypography";
import ArgonAvatar from "components/ArgonAvatar";
import ArgonBadge from "components/ArgonBadge";
//import "./data.css";
import { AccessAlarms } from "@mui/icons-material";
import { makeStyles } from "@material-ui/core/styles";
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import axios from "axios";
import MyDataGrid from "examples/Tables/Table/MyDataGrid";
import {
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarFilterButton,
  GridToolbarExport,
  GridToolbarDensitySelector,
  GridToolbarQuickFilter,
} from "@mui/x-data-grid";
const pageSizeOptions = [5, 10, 20];
function CustomToolbar() {
  const [pageSize, setPageSize] = React.useState(pageSizeOptions[0]);

  const handlePageSizeChange = (event) => {
    setPageSize(event.target.value);
  };
  return (
    <GridToolbarContainer>
      {/* <GridToolbarColumnsButton /> */}
      <GridToolbarFilterButton />
      {/* <GridToolbarDensitySelector /> */}
      <GridToolbarExport />
      {/* <GridToolbarQuickFilter
        quickFilterParser={(searchInput) =>
          searchInput
            .split(',')
            .map((value) => value.trim())
            .filter((value) => value !== '')
        }
      />
      <div style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", gap: 10 }}>
        <Select name="gender">
          <MenuItem value="">All</MenuItem>
          <MenuItem value="Male">Male</MenuItem>
          <MenuItem value="Female">Female</MenuItem>
        </Select>
        <Button variant="contained" color="primary">
          Apply
        </Button>
        <Button variant="contained">Clear</Button>
      </div> */}
    </GridToolbarContainer>
  );
}
// Data

const useStyles = makeStyles({
  customButton: {
    background: "linear-gradient(45deg, #FE6B8B 30%, #FF8E53 90%)",
    borderRadius: 3,
    border: 0,
    color: "white",
    height: 48,
    padding: "0 30px",
    boxShadow: "0 3px 5px 2px rgba(255, 105, 135, .3)",
  },
  datagridbox:
  {
     //border: '2px solid #fff2ea',
     p: 2,
     borderRadius: 5,
     "& .MuiDataGrid-root": {
       border: "none",
       padding: 1,
       //border: '2px dashed grey'
     },
     "& .super-app-theme--header": {
       //backgroundColor: 'rgba(255, 7, 0, 0.55)',
       //color: 'orange !important',
       //fontWeight: 'bold !important'
       //fontWeight: '700 !important',
       //color: 'white !important'
     },
     "& .super-app-theme--cell": {
       //backgroundColor: 'primary',
       //color: '#1a3e72 !important',
       //fontWeight: '600 !important',
       //border: 1
     },
     "& .MuiDataGrid-cell": {
       borderBottom: "none !important",
       //backgroundColor: '#f2f2f2',
       color: "black",
       fontWeight: "550 !important",
     },
     "& .name-column--cell": {
       variant: "button",
       fontWeight: "medium",
       color: "ButtonText",
     },
     "& .MuiDataGrid-columnHeaders": {
       //borderLeft: '2px dashed grey',
       //borderRight: '2px dashed grey',
       //borderBottom: '2px solid grey',
       //fontWeight: 'bold !important',
       //fontWeight: '700 !important',
       fontSize: '14px',
       fontColor: '#8392ab',
       variant:'Button',
       //backgroundColor: '#ff874b',
       //borderRadius: 2
       color: '#8392ab !important'
     },

     ".MuiDataGrid-columnHeaderTitle": {
       //fontWeight: 'bold !important',
       //fontWeight: '1000 !important',
       //overflow: 'visible !important',
       color: "white",
       width: "auto",
       paddingTop: "12px",
       paddingBottom: "10px",
       //paddingLeft: "8px",
       //paddingRight: "24px",
       textAlign: "left",
       fontSize: "14px",
       fontWeight: 700,
       opacity: 0.7,
       background: "transparent",
       color: "#8392ab",
       borderRadius: "none",
       borderBottom: "0.0625rem solid #e9ecef",
       //fontSize: 15
     },
     "& .MuiDataGrid-virtualScroller": {
       //opacity: 1,
       //transition: 'opacity 0.2s',
       overflowY: "auto",
       "&::-webkit-scrollbar": {
         width: "6px",
         backgroundColor: "#F5F5F5",
       },
       "&::-webkit-scrollbar-thumb": {
         backgroundColor: "#11cdef",
         borderRadius: "4px",
       },
     },
     "& .MuiDataGrid-footerContainer": {
       color: "#8392ab",
       border: "none",
     },
     "& .MuiDataGrid-columnSeparator": {
       visibility: "hidden",
     },
     "&.MuiDataGrid-pagination": {
       //backgroundColor: "red",
       //padding: "10px",
       width: "20px !important",
     },

     "&.MuiDataGrid-virtualScroller": {
       opacity: 0,
       transition: "opacity 0.2s",
     },
     "&.MuiTablePagination-root": {
       width: "20px",
     },

     "&.MuiDataGrid-virtualScroller:hover": {
       opacity: 1,
     },
     "& .MuiTablePagination-select": {
       //paddingRight: 2,
       width: "10px !important",
     },
     "& .MuiTablePagination-selectIcon": {
       display: "none",
     },

     "&.MuiDataGrid-toolbar .MuiDataGrid-menuList": {
       padding: 0,
     },

     "& .MuiDataGrid-toolbar .MuiButtonBase-root": {
       fontSize: "14px",
       color: "#333",
     },

     "& .MuiDataGrid-toolbar .MuiButtonBase-root:hover": {
       backgroundColor: "#f0f0f0",
     },
 
     "&  .MuiTablePagination-root" : {
  color: "#333",
},



/* Add hover effects */

"&.MuiDataGrid-hover:hover": {
  backgroundColor: "red",
  //cursor: pointer
}
  }
});
const columns = [
  { field: "id", headerName: "ID", width: 70 },
  {
    field: "firstName",
    headerName: "First name",
    width: 130,
    renderCell: (params) => <ArgonTypography variant="button">{params.value}</ArgonTypography>,
    filterable: false,
    sortable: false,
    disableExport: false,
    editable: false,
    //valueGetter:(data1)=>data1.row.address.street
  },
  {
    field: "lastName",
    headerName: "Last name",
    width: 130,
    cellClassName: "name-column--cell",
    renderCell: (params) => (
      <ArgonTypography variant="button" fontWeight="medium" color="text">
        {params.value}
      </ArgonTypography>
    ),
  },
  { field: "age", headerName: "Age", type: "number", width: 90 },
];

const rows = [
  { id: 1, lastName: "ahi", firstName: "Jon", age: 35 },
  { id: 2, lastName: "Lannister", firstName: "Cersei", age: 42 },
  { id: 3, lastName: "Lannister", firstName: "Jaime", age: 45 },
  { id: 4, lastName: "Stark", firstName: "Arya", age: 16 },
  { id: 5, lastName: "Targaryen", firstName: "Daenerys", age: 55 },
  { id: 6, lastName: "ahi", firstName: "Jon", age: 35 },
  { id: 7, lastName: "Lannister", firstName: "Cersei", age: 42 },
  { id: 8, lastName: "Lannister", firstName: "Jaime", age: 45 },
  { id: 9, lastName: "Stark", firstName: "Arya", age: 16 },
  { id: 10, lastName: "Targaryen", firstName: "Daenerys", age: 55 },
  { id: 11, lastName: "ahi", firstName: "Jon", age: 35 },
  { id: 12, lastName: "Lannister", firstName: "Cersei", age: 42 },
  { id: 13, lastName: "Lannister", firstName: "Jaime", age: 45 },
  { id: 14, lastName: "Stark", firstName: "Arya", age: 16 },
  { id: 15, lastName: "Targaryen", firstName: "Daenerys", age: 55 },
  { id: 16, lastName: "ahi", firstName: "Jon", age: 35 },
  { id: 17, lastName: "Lannister", firstName: "Cersei", age: 42 },
];

export default function MyDataGrid1() {
  const classes = useStyles();
  const [statusData, setStatusData] = React.useState([]);
  React.useEffect(() => {
    // console.log("fetched");
    axios.get("http://10.8.1.170:1122/api/v1/status").then((res) => {
      console.log(res.data);
      setStatusData(res.data);
    });
  }, []);
  const [data, setData] = React.useState([]);
  React.useEffect(() => {
    fetch("http://10.8.1.170:1122/api/v1/status")
      .then((response) => response.json())
      .then((data) => setData(data))
      .catch((error) => console.error(error));
  }, []);
console.log(data);
  return (
    <DashboardLayout>
      <DashboardNavbar />
      <Box>
        <Card>
          <ArgonBox display="flex" justifyContent="space-between" alignItems="center" p={3}>
            <ArgonTypography variant="h6">Authors table</ArgonTypography>
          </ArgonBox>
          <ArgonBox
            sx={{
              "& .MuiTableRow-root:not(:last-child)": {
                "& td": {
                  borderBottom: ({ borders: { borderWidth, borderColor } }) =>
                    `${borderWidth[1]} solid ${borderColor}`,
                },
              },
            }}
          >
            <Card>
              <Box
                //id="invoice-container"
                height="70vh"
                //fontWeight={10}
                className={classes.datagridbox}     
              >
                <DataGrid
                  showQuickFilter
                  
                  rows={rows}
                  components={{
                    Toolbar: GridToolbar,
                    //Toolbar: MyToolbar
                    Pagination: () => (
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <span>Rows per page:</span>
                        <select value={pageSize} onChange={handlePageSizeChange}>
                          {pageSizeOptions.map((option) => (
                            <option key={option} value={option}>
                              {option}
                            </option>
                          ))}
                        </select>
                      </div>
                    ),
                  }}
                  // slots={{
                  //     //loadingOverlay: LinearProgress,
                  //     exportIcon
                  // }}
                  //loading={loading}
                  overlay
                  columns={columns}
                  //exportIcon={true}
                  slots={{
                    toolbar: CustomToolbar,
                  }}
                  componentsProps={{
                    toolbar: {
                      //MyToolbar,
                      className: "custom-toolbar",
                      showQuickFilter: true,
                      quickFilterProps: { debounceMs: 500 },
                      color: "orange",
                    },
                  }}
                  initialState={{
                    pagination: {
                      paginationModel: {
                        pageSize: 11,
                      },
                    },
                  }}
                  pageSizeOptions={[25, 50, 150]}
                  // pagination
                  getRowId={(row) => row.id}
                  //filterModel={filterModel}
                  //pagination
                  //renderFooter={renderFooter}
                />
              </Box>
            </Card>
          </ArgonBox>
        </Card>
        <MyDataGrid rows={rows} columns={columns} />
      </Box>
    </DashboardLayout>
  );
}
