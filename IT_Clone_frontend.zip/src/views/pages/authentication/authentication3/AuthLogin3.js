import React from 'react';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import {
    FormControl,
    InputLabel,
    OutlinedInput,
    FormHelperText,
    Button,
    Box,
    IconButton,
    InputAdornment,
    CircularProgress
} from '@mui/material';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
//import { useNavigate } from 'react-router';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import AnimateButton from 'ui-component/extended/AnimateButton';
import { Grow } from '@mui/material';
import { TextField } from '@material-ui/core';

const LoginForm = () => {
    //const navigate = useNavigate();
    const navigate = useNavigate();
    const initialValues = {
        username: '',
        password: ''
    };
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const validationSchema = Yup.object().shape({
        username: Yup.string().max(255).required('Username is required'),
        password: Yup.string().max(255).required('Password is required')
    });

    const handleSubmit = async (values, { setErrors, setStatus, setSubmitting }) => {
        setLoading(true);
        try {
            const response = await axios.post('http://localhost:1212/api/v1/token/login', {
                username: values.username,
                password: values.password
            });
            //const authToken = response.data.auth_token;
            // Store the token in local storage
            //localStorage.setItem('authToken', authToken);

            // Handle successful login
            //onsole.log(response.data);

            const token = response.data.auth_token;
            localStorage.setItem('token', token);
            console.log(token);

            // Redirect or perform other actions upon successful login
            console.log('Login successful!');
            setStatus({ success: true });
            setSubmitting(false);

            navigate('/dashboard/default');
        } catch (err) {
            console.error(err);
            setError('Login failed. Please check your credentials.');
            //setPassword('');
            if (err.response) {
                // Handle API error response
                setErrors({ submit: err.response.data.message });
            } else {
                // Handle general error
                setErrors({ submit: 'An error occurred. Please try again.' });
            }

            setStatus({ success: false });
            setSubmitting(false);
        }
        setLoading(false);
    };
    const handleFocus = () => {
        setError('');
    };
    // const [username, setUsername] = useState('');
    // const [password, setPassword] = useState('');

    // const handleLogin = async (e) => {
    //     e.preventDefault();

    //     try {
    //         const response = await axios.post('http://localhost:1212/api/v1/token/login', {
    //             username,
    //             password
    //         });

    //         // Save the token to local storage or state for future API requests
    //         const token = response.data.auth_token;
    //         localStorage.setItem('token', token);
    //         console.log(token);

    //         // Redirect or perform other actions upon successful login
    //         console.log('Login successful!');
    //         navigate('/status');
    //     } catch (error) {
    //         console.error('Login failed:', error);
    //     }
    // };
    return (
        <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
            {({ errors, touched, handleChange, handleBlur, isSubmitting, values }) => (
                <Form noValidate>
                    <FormControl fullWidth error={touched.username && Boolean(errors.username)}>
                        {/* <InputLabel htmlFor="outlined-adornment-email-login">Username</InputLabel> */}
                        <TextField
                            id="outlined-adornment-email-login"
                            value={values.username}
                            name="username"
                            //variant="outlined"
                            onBlur={handleBlur}
                            onChange={handleChange}
                            label="Username"
                            onFocus={handleFocus}
                            InputProps={{
                                shrink: true
                            }}
                            InputLabelProps={{
                                shrink: true
                                // classes: {
                                //   //root: classes.label,
                                //   focused: classes.label,
                                // },
                            }}
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton
                                        //aria-label="toggle password visibility"

                                        edge="end"
                                        size="large"
                                    >
                                        <AccountCircleIcon />
                                    </IconButton>
                                </InputAdornment>
                            }
                        />
                        {touched.username && errors.username && <FormHelperText error>{errors.username}</FormHelperText>}
                    </FormControl>
                    <br></br>
                    <br></br>
                    <FormControl fullWidth error={touched.password && Boolean(errors.password)}>
                        {/* <InputLabel htmlFor="outlined-adornment-password-login">Password</InputLabel> */}
                        <TextField
                            id="outlined-adornment-password-login"
                            //type="password"
                            value={values.password}
                            name="password"
                            onBlur={handleBlur}
                            onChange={handleChange}
                            onFocus={handleFocus}
                            type={showPassword ? 'text' : 'password'}
                            label="Password"
                            shrink
                            InputLabelProps={{
                                shrink: true
                                // classes: {
                                //   //root: classes.label,
                                //   focused: classes.label,
                                // },
                            }}
                            endAdornment={
                                <InputAdornment position="end">
                                    <IconButton
                                        aria-label="toggle password visibility"
                                        onClick={handleClickShowPassword}
                                        onMouseDown={handleMouseDownPassword}
                                        edge="end"
                                        size="large"
                                    >
                                        {showPassword ? <Visibility /> : <VisibilityOff />}
                                    </IconButton>
                                </InputAdornment>
                            }
                        />
                        {touched.password && errors.password && <FormHelperText error>{errors.password}</FormHelperText>}
                    </FormControl>

                    {errors.submit && (
                        <Box sx={{ mt: 3 }}>
                            <FormHelperText error>{errors.submit}</FormHelperText>
                        </Box>
                    )}
                    {error && (
                        <Box sx={{ mt: 3 }}>
                            <Grow in={Boolean(error)}>
                                <FormHelperText error>{error}</FormHelperText>
                            </Grow>
                        </Box>
                    )}
                    <Box sx={{ mt: 2 }}>
                        <AnimateButton>
                            <Button
                                disableElevation
                                disabled={(isSubmitting, loading)}
                                fullWidth
                                size="large"
                                type="submit"
                                variant="contained"
                                color="secondary"
                                sx={{ color: 'white' }}
                            >
                                {loading ? <CircularProgress size={24} /> : 'Login'}
                            </Button>
                        </AnimateButton>
                    </Box>
                </Form>
            )}
        </Formik>
    );
};

export default LoginForm;
