import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { Card, Box, Typography } from '@mui/material';
//import { Typography } from 'tabler-icons-react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import React from 'react';
import { useMediaQuery } from '@mui/material';
const columns = [
    { field: 'id', headerName: 'ID', width: 90 },
    { field: 'firstName', headerName: 'First Name', width: 150 },
    { field: 'lastName', headerName: 'Last Name', width: 150 },
    { field: 'age', headerName: 'Age', type: 'number', width: 90 }
];
const columns1 = [
    {
        field: 'sno',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'S.NO',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header'
        //flex: 0.2
        // cellClassName: "name-column--cell",
    },
    {
        field: 'branch',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Branches',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'shortcode',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Short Code',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'location',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Location',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'city',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'City',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'state',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'State',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    }
];
const columns2 = [
    // {
    //     field: 'sno',
    //     // valueFormatter: ({ value }) => "PO" + value,
    //     headerName: 'S.NO',
    //     cellClassName: 'super-app-theme--cell',
    //     headerClassName: 'super-app-theme--header',
    //     flex: 0.2
    //     // cellClassName: "name-column--cell",
    // },
    {
        field: 'branch',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Showroom',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'region',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Region',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'state',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'State',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'opendate',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'Dob',
        cellClassName: 'super-app-theme--cell',

        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    },
    {
        field: 'asm',
        // valueFormatter: ({ value }) => "PO" + value,
        headerName: 'ASM',
        cellClassName: 'super-app-theme--cell',
        headerClassName: 'super-app-theme--header',
        flex: 0.4
        // cellClassName: "name-column--cell",
    }
];
const rows = [
    { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
    { id: 2, lastName: 'Lannister', firstName: 'Cersei', age: 42 },
    { id: 3, lastName: 'Lannister', firstName: 'Jaime', age: 45 },
    { id: 4, lastName: 'Stark', firstName: 'Arya', age: 16 },
    { id: 5, lastName: 'Targaryen', firstName: 'Daenerys', age: null },
    { id: 6, lastName: 'Melisandre', firstName: null, age: 150 },
    { id: 7, lastName: 'Clifford', firstName: 'Ferrara', age: 44 },
    { id: 8, lastName: 'Frances', firstName: 'Rossini', age: 36 },
    { id: 9, lastName: 'Roxie', firstName: 'Harvey', age: 65 }
];

function DataTable() {
    const [loading, setLoading] = React.useState(false);
    const [product, setProduct] = React.useState('');

    React.useEffect(() => {
        setLoading(true);
        const token = 'St3e6u2zYK?L!Aq-*DdBfWGEs5j6e5j$';
        fetch('https://poorvika.org/api/showroom/showroomdetails.php', {
            method: 'GET',
            headers: {
                authorization: `${token}`,
                'Content-Type': 'application/json'
            }
        })
            .then((response) => response.json())
            // .then(response => response.data)
            .then((res) => {
                console.log(res.data);
                setProduct(res.data);
                setLoading(false);
            })
            //.then(data => console.log(data))
            // .then(data => setProduct(data))
            .catch((error) => console.error(error));
    }, []);
    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <Card sx={{ width: '100%', my: 3, marginLeft: 2.5 }}>
            <List>
                <ListItem>
                    <ListItemAvatar>
                        <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                            <StoreOutlinedIcon sx={{ color: 'white' }} />
                        </Avatar>
                    </ListItemAvatar>
                    <ListItemText>
                        {' '}
                        <Typography variant="h3" color="black">
                            Showrooms List
                        </Typography>
                    </ListItemText>
                </ListItem>
            </List>

            <Card sx={{ my: 1, boxShadow: 2 }}>
                <Box
                    //id="invoice-container"
                    height="60vh"
                    fontWeight={10}
                    //className={classes.customButton}
                    sx={{
                        //width: '100%',
                        //border: '2px solid #fff2ea',
                        p: 2,
                        height: isSmallScreen ? '90vh' : '60vh',
                        width: '100%',
                        borderRadius: 5,
                        '& .MuiDataGrid-root': {
                            border: 'none',
                            padding: 1
                            //border: '2px dashed grey'
                        },
                        '& .super-app-theme--header': {
                            //backgroundColor: 'rgba(255, 7, 0, 0.55)',
                            //color: 'orange !important',
                            //fontWeight: 'bold !important'
                            //fontWeight: '700 !important',
                            //color: 'white !important'
                        },
                        '& .super-app-theme--cell': {
                            //backgroundColor: 'primary',
                            //color: '#1a3e72 !important',
                            //fontWeight: '600 !important',
                            //border: 1
                        },
                        '& .MuiDataGrid-cell': {
                            borderBottom: 'none !important',
                            //backgroundColor: '#f2f2f2',
                            color: 'black',
                            fontWeight: '550 !important'
                        },
                        '& .name-column--cell': {
                            variant: 'button',
                            fontWeight: 'medium',
                            color: 'ButtonText'
                        },
                        '& .MuiDataGrid-columnHeaders': {
                            //borderLeft: '2px dashed grey',
                            //borderRight: '2px dashed grey',
                            //borderBottom: '2px solid grey',
                            //fontWeight: 'bold !important',
                            //fontWeight: '700 !important',
                            //fontSize: 15,
                            //fontColor: 'red'
                            //backgroundColor: '#ff874b',
                            //borderRadius: 2
                            //color: 'white !important'
                        },

                        '.MuiDataGrid-columnHeaderTitle': {
                            //fontWeight: 'bold !important',
                            //fontWeight: '1000 !important',
                            //overflow: 'visible !important',
                            color: 'white',
                            width: 'auto',
                            paddingTop: '12px',
                            paddingBottom: '10px',
                            //paddingLeft: "8px",
                            //paddingRight: "24px",
                            textAlign: 'left',
                            fontSize: '0.80rem',
                            fontWeight: 700,
                            opacity: 0.7,
                            background: 'transparent',
                            color: '#8392ab',
                            borderRadius: 'none',
                            borderBottom: '0.0625rem solid #e9ecef'
                            //fontSize: 15
                        },
                        '& .MuiDataGrid-virtualScroller': {
                            //opacity: 1,
                            //transition: 'opacity 0.2s',
                            //overflowY: 'auto',
                            overflowX: 'auto',
                            '&::-webkit-scrollbar': {
                                width: '4px',
                                backgroundColor: '#F5F5F5'
                            },
                            '&::-webkit-scrollbar-thumb': {
                                //backgroundColor: '#11cdef',
                                borderRadius: '4px'
                            }
                        },
                        '& .MuiDataGrid-footerContainer': {
                            color: '#8392ab',
                            border: 'none'
                        },
                        '& .MuiDataGrid-columnSeparator': {
                            visibility: 'hidden'
                        },
                        '&.MuiDataGrid-pagination': {
                            //backgroundColor: "red",
                            //padding: "10px",
                            width: '20px !important'
                        },

                        '&.MuiDataGrid-virtualScroller': {
                            opacity: 0,
                            transition: 'opacity 0.2s'
                        },
                        '&.MuiTablePagination-root': {
                            width: '20px'
                        },

                        '&.MuiDataGrid-virtualScroller:hover': {
                            opacity: 1
                        },
                        '& .MuiTablePagination-select': {
                            //paddingRight: 2,
                            width: '10px !important'
                        },
                        '& .MuiTablePagination-selectIcon': {
                            display: 'none'
                        },

                        '&.MuiDataGrid-toolbar .MuiDataGrid-menuList': {
                            padding: 0
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root': {
                            fontSize: '14px',
                            color: '#333'
                        },

                        '& .MuiDataGrid-toolbar .MuiButtonBase-root:hover': {
                            backgroundColor: '#f0f0f0'
                        }
                    }}
                >
                    <DataGrid
                        rows={product}
                        //columns={columns1}
                        columns={columns1}
                        pageSize={5}
                        getRowId={(row) => row.sno}
                        components={{ Toolbar: GridToolbar, color: 'primary' }}
                        componentsProps={{
                            toolbar: {
                                showQuickFilter: true,
                                quickFilterProps: { debounceMs: 500 },
                                color: 'primary'
                            }
                        }}
                        loading={loading}
                        //autoHeight
                        //scrollbarSize={100}
                        //pageSize={5}
                        //checkboxSelection
                        //touchRipple
                        //disableColumnMenu
                        disableColumnFilter={isSmallScreen ? true : false}
                        disableDensitySelector={isSmallScreen ? true : false}
                        virtualization
                    />
                </Box>
            </Card>
        </Card>
    );
}

export default DataTable;
