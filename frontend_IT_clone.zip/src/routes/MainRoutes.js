import { lazy } from 'react';

// project imports
import MainLayout from 'layout/MainLayout';
import Loadable from 'ui-component/Loadable';

// dashboard routing
const DashboardDefault = Loadable(lazy(() => import('views/dashboard/Default')));

// utilities routing
const UtilsTypography = Loadable(lazy(() => import('views/utilities/Typography')));
const UtilsColor = Loadable(lazy(() => import('views/utilities/Color')));
const UtilsShadow = Loadable(lazy(() => import('views/utilities/Shadow')));
const UtilsMaterialIcons = Loadable(lazy(() => import('views/utilities/MaterialIcons')));
const UtilsTablerIcons = Loadable(lazy(() => import('views/utilities/TablerIcons')));
const Asset = Loadable(lazy(() => import('views/outlet-media/outletadvertise')));
const Assetform = Loadable(lazy(() => import('views/outlet-media/outletadform')));
const MyForm = Loadable(lazy(() => import('views/outlet-media/floordiagram')));
const MyForm1 = Loadable(lazy(() => import('views/outlet-media/360floordiagram')));
const Class = Loadable(lazy(() => import('views/outlet-media/class')));
const Brand = Loadable(lazy(() => import('views/outlet-media/brand')));
const Brandtype = Loadable(lazy(() => import('views/outlet-media/brandtype')));
const Lighttype = Loadable(lazy(() => import('views/outlet-media/lighttype')));
const Materialtype = Loadable(lazy(() => import('views/outlet-media/materialtype')));
const Adlocation = Loadable(lazy(() => import('views/outlet-media/adlocation')));
const Vendorlist = Loadable(lazy(() => import('views/outlet-media/vendorlist')));
const Showrooms = Loadable(lazy(() => import('views/outlet-media/showrooms')));
const Showroomadd = Loadable(lazy(() => import('views/outlet-media/showroomlist')));
const Status = Loadable(lazy(() => import('views/outlet-media/status')));
const Jobfor = Loadable(lazy(() => import('views/job-assign/jobfor')));
const Jobtype = Loadable(lazy(() => import('views/job-assign/jobtype')));
const DesignType = Loadable(lazy(() => import('views/job-assign/designtype')));

const Hoardinglist = Loadable(lazy(() => import('views/hoarding/hoardinglist')));
const Hoardingform = Loadable(lazy(() => import('views/hoarding/hoardingform')));

// sample page routing
const SamplePage = Loadable(lazy(() => import('views/sample-page')));

// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
    path: '/',
    element: <MainLayout />,
    children: [
        {
            path: '/',
            element: <DashboardDefault />
        },
        {
            path: 'dashboard',
            children: [
                {
                    path: 'default',
                    element: <DashboardDefault />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'util-typography',
                    element: <UtilsTypography />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'util-color',
                    element: <UtilsColor />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'util-shadow',
                    element: <UtilsShadow />
                }
            ]
        },
        {
            path: 'utils',
            children: [
                {
                    path: 'util-shadow',
                    element: <UtilsShadow />
                }
            ]
        },
        {
            path: 'icons',
            children: [
                {
                    path: 'tabler-icons',
                    element: <UtilsTablerIcons />
                },
                {
                    path: 'default',
                    element: <DashboardDefault />
                }
            ]
        },
        {
            path: 'icons',
            children: [
                {
                    path: 'material-icons',
                    element: <UtilsMaterialIcons />
                },
                {
                    path: 'material-icons',
                    element: <UtilsMaterialIcons />
                }
            ]
        },

        {
            path: 'sample-page',
            element: <SamplePage />
        },
        {
            path: 'floordiagram',
            element: <MyForm />
        },
        {
            path: '360floordiagram',
            element: <MyForm1 />
        },
        {
            path: 'class',
            element: <Class />
        },
        {
            path: 'brand',
            element: <Brand />
        },
        {
            path: 'brandtype',
            element: <Brandtype />
        },
        {
            path: 'lighttype',
            element: <Lighttype />
        },
        {
            path: 'materialtype',
            element: <Materialtype />
        },
        {
            path: 'adlocation',
            element: <Adlocation />
        },
        {
            path: 'vendorlist',
            element: <Vendorlist />
        },
        {
            path: 'status',
            element: <Status />
        },
        {
            path: 'jobfor',
            element: <Jobfor />
        },
        {
            path: 'jobtype',
            element: <Jobtype />
        },
        {
            path: 'designtype',
            element: <DesignType />
        },
        {
            path: 'outletadvertise',
            element: <Asset />
        },
        {
            path: 'outletadform',
            element: <Assetform />
        },
        {
            path: 'showroomadd',
            element: <Showroomadd />
        },
        {
            path: 'showrooms',
            element: <Showrooms />
        },
        {
            path: 'hoardinglist',
            element: <Hoardinglist />
        },
        {
            path: 'hoardingform',
            element: <Hoardingform />
        }
    ]
};

export default MainRoutes;
