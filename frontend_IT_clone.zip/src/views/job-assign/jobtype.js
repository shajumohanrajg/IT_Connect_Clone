// material-ui

import React, { useState } from 'react';
import { makeStyles } from '@mui/styles';
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    TextField,
    Button,
    Input,
    Fab,
    Typography,
    Grid,
    Box,
    InputAdornment,
    Stack
} from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import ImageIcon from '@mui/icons-material/Image';
import WorkIcon from '@mui/icons-material/Work';
import BeachAccessIcon from '@mui/icons-material/BeachAccess';
//import { makeStyles } from '@material-ui/core/styles';
// import { DropzoneArea } from 'material-ui-dropzone';
// import 'react-dropzone-uploader/dist/styles.css';

// project imports
import MainCard from 'ui-component/cards/MainCard';
import Modal from '@mui/material/Modal';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import { OutlinedInput } from '@material-ui/core';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import Axios from 'axios';

import Table from './jobtypetable';
// ==============================|| SAMPLE PAGE ||============================== //
// const useStyles = makeStyles((theme) => ({
//     formControl: {
//         margin: theme.spacing(1),
//         minWidth: 120
//     },
//     selectEmpty: {
//         marginTop: theme.spacing(2)
//     }
// }));
const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    stepper: {
        backgroundColor: 'transparent', // set your desired background color
        // padding: "16px", // adjust the padding as needed
        // borderRadius: "8px", // adjust the border radius as needed
        [theme.breakpoints.down('sm')]: {
            padding: theme.spacing(1)
        }
    },
    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                // color: 'white',
                // backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                // backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        // backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    borderRadius: 5,
    boxShadow: 30,
    p: 4
};

const SamplePage = () => {
    const classes = useStyles();
    const [location, setLocation] = useState('');
    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    function getPhoto(event) {
        setPhoto(URL.createObjectURL(event.target.files[0]));
        setPhoto1(event.target.files[0]);
    }
    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };

    const [name, setName] = useState('');
    const [status, setStatus] = useState('');
    const [jobfor, setJobfor] = useState([]);
    const [jobforvalue, setJobforvalue] = useState('');
    // const [jobtype, setJobtype] = useState([]);
    // const [jobtypevalue, setJobtypevalue] = useState('');

    React.useEffect(() => {
        Axios.get('http://localhost:1212/api/v1/job/jobfor_list ', {}).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setJobfor(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        Axios.put('http://localhost:1212/api/v1/job/jobtype_list', {
            // id: id,
            name: name,
            status: status,
            jobfor: jobforvalue
        }).then(
            (response) => {
                // enqueueSnackbar('Data Entry Successful', {
                //     variant: 'success',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(response);
                // history.push('/dashboard/bomat_table2');
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            },
            (error) => {
                // enqueueSnackbar('Check Data and Try Again', {
                //     variant: 'Error',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(error);
            }
        );
    };
    return (
        <MainCard title="Job Type Management">
            <div>
                <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        onClick={handleOpen}
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Job Type
                    </Button>
                </Stack>
                <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                    <Box sx={style}>
                        <Grid container spacing={2} justifyContent="center" alignItems="center">
                            <List sx={{ width: '100%', maxWidth: 360 }}>
                                <ListItem>
                                    <ListItemAvatar>
                                        <Avatar sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                            <AddAPhotoOutlinedIcon />
                                        </Avatar>
                                    </ListItemAvatar>
                                    <ListItemText>
                                        <Typography variant="h3">Create Job Type</Typography>
                                    </ListItemText>
                                </ListItem>
                            </List>
                            <Grid item xs={12} md={12} xl={12}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="jobfor-select-label">
                                        Job For
                                    </InputLabel>
                                    <Select
                                        labelId="jobfor-select-label"
                                        id="jobfor-select"
                                        value={jobforvalue}
                                        onChange={(e) => setJobforvalue(e.target.value)}
                                        label="Job For"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select Job For</em>
                                        </MenuItem>
                                        {jobfor && jobfor !== undefined
                                            ? jobfor.map((option, index) => (
                                                  <MenuItem key={index} value={option.id}>
                                                      {option.name}
                                                  </MenuItem>
                                              ))
                                            : 'No Data'}
                                        {/* <MenuItem value="poorvika">Poorvika</MenuItem>
                                        <MenuItem value="shine">Shine</MenuItem>
                                        <MenuItem value="poorvika diary">Poorvika Dairy</MenuItem> */}
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} md={12} xl={12}>
                                <TextField
                                    //size="small"
                                    label="Name"
                                    id="name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    fullWidth
                                    //type="number"
                                    variant="outlined"
                                    className={classes.input}
                                    InputLabelProps={{
                                        classes: {
                                            //root: classes.label,
                                            focused: classes.label
                                        }
                                    }}
                                />
                            </Grid>
                            <Grid item xs={12} md={12} xl={12}>
                                <FormControl fullWidth className={classes.select}>
                                    <InputLabel className={classes.label} id="status-select-label">
                                        Status
                                    </InputLabel>
                                    <Select
                                        labelId="status-select-label"
                                        id="status-select"
                                        value={status}
                                        onChange={(e) => setStatus(e.target.value)}
                                        label="Status"
                                        //displayEmpty
                                        //className={classes.selectEmpty}
                                        //className={classes.select}
                                    >
                                        <MenuItem value="">
                                            <em>Select a Status</em>
                                        </MenuItem>
                                        <MenuItem value="A">Active</MenuItem>
                                        <MenuItem value="I">Inactive</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>

                            <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                                <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                    {' '}
                                    <Button
                                        className={classes.Button}
                                        variant="contained"
                                        onClick={handleSubmit}
                                        //startIcon={<FileUploadOutlinedIcon />}
                                    >
                                        Create
                                    </Button>
                                </Stack>
                            </Grid>
                        </Grid>
                    </Box>
                </Modal>
                <br></br>
                <Table />
            </div>

            {/* <ImageUpload /> */}
        </MainCard>
    );
};

export default SamplePage;
