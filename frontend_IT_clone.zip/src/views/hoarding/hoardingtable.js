// material-ui
import React, { useState } from 'react';
//import './App.css';
import MaterialTable from 'material-table';
import { makeStyles } from '@mui/styles';
//import GetAppIcon from '@material-ui/icons/GetApp';
//import AddIcon from '@material-ui/icons/Add';
//import { createTheme, ThemeProvider } from '@material-ui/core/styles';
// import {
//   ChevronLeft,
//   ChevronRight,
//   Search,
//   FilterList,
//   Close,
//   ClearIcon,
//   Clear,
// } from "@material-ui/icons";
import {
    AddBox,
    ArrowDownward,
    Check,
    ChevronLeft,
    ChevronRight,
    Clear,
    DeleteOutline,
    Edit,
    FilterList,
    FirstPage,
    LastPage,
    Remove,
    SaveAlt,
    Search,
    ViewColumn
} from '@material-ui/icons';

//import ClearIcon from '@mui/icons-material/Clear';

import NavigateNextIcon from '@mui/icons-material/NavigateNext';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    stepper: {
        backgroundColor: 'transparent', // set your desired background color
        // padding: "16px", // adjust the padding as needed
        // borderRadius: "8px", // adjust the border radius as needed
        [theme.breakpoints.down('sm')]: {
            padding: theme.spacing(1)
        }
    },
    Button: {
        borderRadius: 8,
        backgroundColor: '#1a5f7a',
        color: 'white',
        '&:hover': {
            backgroundColor: '#1a5f7a',
            color: 'white'
            //boxShadow: 24
        }
    },
    input: {
        borderRadius: 50,
        //padding: "0.75rem",
        //height: "1.4375em",

        animationDuration: '10ms',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px dashed grey",
                //height: "1.4375em",
                //padding: "1rem",
                color: 'white'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            }
        }
    },
    fw: {
        fontWeight: 'bold'
    },
    label: {
        //color: "red",
        '&.Mui-focused': {
            color: '#1a5f7a'
        }
    },
    focusedLabel: {
        color: '#1a5f7a'
    },
    select: {
        size: 'small',
        borderRadius: 10,
        backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8,
                //borderColor: "black",
                //border: "2px solid grey",
                backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    select1: {
        size: 'small',
        borderRadius: 10,
        backgroundColor: '#fff',
        '& .MuiOutlinedInput-root': {
            '& fieldset': {
                //borderColor: "#ccc",
                borderRadius: 8
                //borderColor: "black",
                //border: "2px solid grey",
                //backgroundColor: '#fff'
            },
            '&:hover fieldset': {
                borderColor: '#999'
            },
            '&.Mui-focused fieldset': {
                borderColor: '#1a5f7a'
            },
            '&.Mui-focused': {
                color: '#1a5f7a'
            }
        },
        '& .MuiSelect-icon': {
            color: '#333'
        }
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    //border: '2px solid #000',
    borderRadius: 5,
    boxShadow: 30,
    p: 4
};

const SamplePage = () => {
    const classes = useStyles();

    const options1 = {
        searchFieldStyle: {
            borderRadius: '4px',
            border: '1px solid #ccc',
            padding: '5px',
            width: '100%'
        },
        selectionArea: 'outlined'
    };
    const rowStyle = {
        borderBottom: 'none',
        border: 'none'
    };
    const [tableData, setTableData] = useState([
        {
            name: 'Raj',
            email: 'Raj@gmail.com',
            phone: 7894561230,
            age: null,
            gender: 'M',
            city: 'Chennai',
            fee: 78456
        },
        {
            name: 'Mohan',
            email: 'mohan@gmail.com',
            phone: 7845621590,
            age: 35,
            gender: 'M',
            city: 'Delhi',
            fee: 456125
        },
        {
            name: 'Sweety',
            email: 'sweety@gmail.com',
            phone: 741852912,
            age: 17,
            gender: 'F',
            city: 'Noida',
            fee: 458796
        },
        {
            name: 'Vikas',
            email: 'vikas@gmail.com',
            phone: 9876543210,
            age: 20,
            gender: 'M',
            city: 'Mumbai',
            fee: 874569
        },
        {
            name: 'Neha',
            email: 'neha@gmail.com',
            phone: 7845621301,
            age: 25,
            gender: 'F',
            city: 'Patna',
            fee: 748521
        },
        {
            name: 'Mohan',
            email: 'mohan@gmail.com',
            phone: 7845621590,
            age: 35,
            gender: 'M',
            city: 'Delhi',
            fee: 456125
        },
        {
            name: 'Sweety',
            email: 'sweety@gmail.com',
            phone: 741852912,
            age: 17,
            gender: 'F',
            city: 'Noida',
            fee: 458796
        },
        {
            name: 'Vikas',
            email: 'vikas@gmail.com',
            phone: 9876543210,
            age: 20,
            gender: 'M',
            city: 'Mumbai',
            fee: 874569
        },
        {
            name: 'Raj',
            email: 'Raj@gmail.com',
            phone: 7894561230,
            age: null,
            gender: 'M',
            city: 'Chennai',
            fee: 78456
        },
        {
            name: 'Mohan',
            email: 'mohan@gmail.com',
            phone: 7845621590,
            age: 35,
            gender: 'M',
            city: 'Delhi',
            fee: 456125
        },
        {
            name: 'Sweety',
            email: 'sweety@gmail.com',
            phone: 741852912,
            age: 17,
            gender: 'F',
            city: 'Noida',
            fee: 458796
        },
        {
            name: 'Vikas',
            email: 'vikas@gmail.com',
            phone: 9876543210,
            age: 20,
            gender: 'M',
            city: 'Mumbai',
            fee: 874569
        }
    ]);
    const columns = [
        {
            title: 'Name',
            field: 'name',
            sorting: false,
            filtering: true,
            //cellStyle: { background:"#009688" },
            headerStyle: { color: '#fff' }
        },
        { title: 'Email', field: 'email', filterPlaceholder: 'filter' },
        { title: 'Phone Number', field: 'phone', align: 'center', grouping: false },
        {
            title: 'Age',
            field: 'age',
            emptyValue: () => <em>null</em>,
            render: (rowData) => (
                <div
                    style={{
                        background: rowData.age >= 18 ? '#008000aa' : '#f90000aa',
                        borderRadius: '4px',
                        paddingLeft: 5
                    }}
                >
                    {rowData.age >= 18 ? '18+' : '18-'}
                </div>
            ),
            searchable: false,
            export: false
        },
        {
            title: 'Gender',
            field: 'gender',
            render: (rowData) => (
                <div
                    style={{
                        background: rowData.gender === 'M' ? '#008000aa' : '#f90000aa',
                        borderRadius: '4px',
                        paddingLeft: 5
                    }}
                >
                    {rowData.gender}
                </div>
            ),
            lookup: { M: 'Male', F: 'Female' }
        },
        { title: 'City', field: 'city', filterPlaceholder: 'filter' },
        {
            title: 'School Fee',
            field: 'fee',
            type: 'currency',
            currencySetting: { currencyCode: 'INR', minimumFractionDigits: 1 },
            //cellStyle: { background:"#009688" },
            headerStyle: { color: '#fff' }
        }
    ];

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    return (
        <div>
            <MaterialTable
                columns={columns}
                data={tableData}
                // editable={{
                //   onRowAdd: (newRow) => new Promise((resolve, reject) => {
                //     setTableData([...tableData, newRow])

                //     setTimeout(() => resolve(), 500)
                //   }),
                //   onRowUpdate: (newRow, oldRow) => new Promise((resolve, reject) => {
                //     const updatedData = [...tableData]
                //     updatedData[oldRow.tableData.id] = newRow
                //     setTableData(updatedData)
                //     setTimeout(() => resolve(), 500)
                //   }),
                //   onRowDelete: (selectedRow) => new Promise((resolve, reject) => {
                //     const updatedData = [...tableData]
                //     updatedData.splice(selectedRow.tableData.id, 1)
                //     setTableData(updatedData)
                //     setTimeout(() => resolve(), 1000)

                //   })
                // }}
                // actions={[
                //   {
                //     icon: () => <GetAppIcon />,
                //     tooltip: "Click me",
                //     onClick: (e, data) => console.log(data),
                //     // isFreeAction:true
                //   },
                //    {
                //     icon: () => <GetAppIcon />,
                //     tooltip: "Click me",
                //     onClick: (e, data) => console.log(data),
                //     // isFreeAction:true
                //   }
                // ]}
                // actions={[
                //   {
                //     icon: 'search',
                //     tooltip: 'Search',
                //     onClick: (event, rowData) => alert('You clicked the search icon'),
                //     isFreeAction: true,
                //   },
                //   {
                //     icon: 'refresh',
                //     tooltip: 'Refresh Data',
                //     onClick: (event, rowData) => alert('You clicked the refresh icon'),
                //     isFreeAction: true,
                //   },
                //   {
                //     icon: 'arrow_downward',
                //     tooltip: 'Export Data',
                //     onClick: (event, rowData) => alert('You clicked the export icon'),
                //     isFreeAction: true,
                //   },
                //   {
                //     icon: 'chevron_left',
                //     tooltip: 'Previous Page',
                //     onClick: (event, rowData) => alert('You clicked the previous page icon'),
                //     disabled: true, // Example of how to disable the icon
                //     isFreeAction: true,
                //   },
                //   {
                //     icon: 'chevron_right',
                //     tooltip: 'Next Page',
                //     onClick: (event, rowData) => alert('You clicked the next page icon'),
                //     isFreeAction: true,
                //   },
                // ]}
                // localization={{
                //   toolbar: {
                //     searchTooltip: 'Search',
                //     searchPlaceholder: 'Search',
                //   },
                //   pagination: {
                //     labelRowsSelect: 'rows per page',
                //     labelDisplayedRows: '{from}-{to} of {count}',
                //     firstTooltip: 'First Page',
                //     previousTooltip: 'Previous Page',
                //     nextTooltip: 'Next Page',
                //     lastTooltip: 'Last Page',
                //   },
                // }}
                // actions={[
                //   {
                //     icon: AddBox,
                //     tooltip: 'Add User',
                //     // action
                //   },
                //   {
                //     icon: Edit,
                //     tooltip: 'Edit User',
                //     // action
                //   },
                //   {
                //     icon: DeleteOutline,
                //     tooltip: 'Delete User',
                //     // action
                //   },
                // ]}
                onSelectionChange={(selectedRows) => console.log(selectedRows)}
                icons={{
                    // Search: Search,
                    // //ResetSearch: Clear,
                    // PreviosPage: ChevronLeft,
                    // LastPage: ChevronRight,
                    // Filter: FilterList,
                    // //SortArrow: ArrowDownward,
                    // DetailPanel: ChevronRight,
                    // //Delete: DeleteOutline,
                    // //Add: AddBox,
                    // //Edit: Edit,
                    // Close: Close,
                    // Clear: Clear
                    Add: AddBox,
                    Check: Check,
                    Clear: Clear,
                    Delete: DeleteOutline,
                    DetailPanel: ChevronRight,
                    Edit: Edit,
                    Export: SaveAlt,
                    Filter: FilterList,
                    FirstPage: FirstPage,
                    LastPage: LastPage,
                    NextPage: ChevronRight,
                    PreviousPage: ChevronLeft,
                    ResetSearch: Clear,
                    Search: Search,
                    SortArrow: ArrowDownward,
                    ThirdStateCheck: Remove,
                    ViewColumn: ViewColumn
                }}
                options1={options1}
                options={{
                    sorting: true,
                    search: true,
                    searchFieldAlignment: 'right',
                    searchAutoFocus: false,
                    loadingType: 'linear',
                    searchFieldVariant: 'standard',
                    filtering: true,
                    paging: true,
                    pageSizeOptions: [2, 5, 10, 20, 25, 50, 100],
                    pageSize: 5,
                    paginationType: 'normal',
                    //paginationType: "normal",
                    showFirstLastPageButtons: false,
                    //paginationPosition: "footer",
                    exportButton: true,
                    exportAllData: true,
                    exportFileName: 'TableData',
                    addRowPosition: 'first',
                    actionsColumnIndex: -1,
                    toolbarButtonAlignment: 'right',
                    // selection: true,
                    ///showSelectAllCheckbox: false,
                    showTitle: 'false',
                    showTextRowsSelected: false,
                    selectionProps: (rowData) => ({
                        disabled: rowData.age == null
                        // color:"primary"
                    }),

                    //grouping: true,
                    columnsButton: false,
                    //rowStyle:{{rowStyle}},
                    rowStyle
                    //rowStyle: (data, index) => index % 1 === 0 ? { background: "#fff",borderBottom: 'none',
                    //border: 'none' } : null,
                    //rowStyle: (data, index) => index % 2 === 0 ? { background: "#f5f5f5" } : null,
                    //headerStyle: { background: "#f44336",color:"#fff"}
                }}
                //style={{ border: '1px solid black',borderRadius:2 }}
                title="Hoarding"
                //icons={{ Add: () => <AddIcon /> }}
            />
        </div>
    );
};

export default SamplePage;
