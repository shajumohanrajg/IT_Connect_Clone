import { useState } from 'react';
import {
    TextField,
    Checkbox,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Button,
    Input,
    FormGroup,
    FormControlLabel,
    Grid,
    Box,
    Typography
} from '@material-ui/core';
//import { Typography } from 'tabler-icons-react';

const MyForm = () => {
    const [name, setName] = useState('');
    const [gender, setGender] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState(null);
    const [birthTime, setBirthTime] = useState(null);
    const [motherTongue, setMotherTongue] = useState('');
    const [maritalStatus, setMaritalStatus] = useState('');
    const [photo, setPhoto] = useState(null);
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [physicalStatus, setPhysicalStatus] = useState('');
    const [bodyType, setBodyType] = useState('');
    const [complexion, setComplexion] = useState('');
    const [foodHabit, setFoodHabit] = useState('');
    const [fatherName, setFatherName] = useState('');
    const [fatherJob, setFatherJob] = useState('');
    const [motherName, setMotherName] = useState('');
    const [motherJob, setMotherJob] = useState('');
    const [noOfBrother, setNoOfBrother] = useState('');
    const [brotherMarried, setBrotherMarried] = useState(false);
    const [noOfSister, setNoOfSister] = useState('');
    const [sisterMarried, setSisterMarried] = useState(false);
    const [educationalQualification, setEducationalQualification] = useState('');
    const [job, setJob] = useState('');
    const [incomePerMonth, setIncomePerMonth] = useState('');
    const [religious, setReligious] = useState('');
    const [contactPerson, setContactPerson] = useState('');
    const [contactNo, setContactNo] = useState('');
    const [whatsApp, setWhatsApp] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [district, setDistrict] = useState('');
    const [state, setState] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    return (
        <form onSubmit={handleSubmit}>
            <br></br>
            <Box>
                <Typography>Personal Info</Typography>
            </Box>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={4}>
                    <TextField label="Name" value={name} onChange={(e) => setName(e.target.value)} fullWidth variant="outlined" required />
                </Grid>
                <Grid item xs={12} md={6} xl={4}>
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="gender-label">Gender</InputLabel>
                        <Select labelId="gender-label" value={gender} onChange={(e) => setGender(e.target.value)} label="Gender">
                            <MenuItem value="male">Male</MenuItem>
                            <MenuItem value="female">Female</MenuItem>
                            <MenuItem value="other">Other</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={4}>
                    <TextField
                        label="Date of Birth"
                        type="date"
                        value={dateOfBirth}
                        onChange={(e) => setDateOfBirth(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                    {/* <DatePicker label="Date of Birth" value={dateOfBirth} onChange={(date) => setDateOfBirth(date)} /> */}
                </Grid>
                <Grid item xs={12} md={6} xl={4}>
                    <TextField
                        label="Birth Time"
                        value={birthTime}
                        onChange={(e) => setBirthTime(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                    {/* <TimePicker label="Birth Time" value={birthTime} onChange={(time) => setBirthTime(time)} /> */}
                </Grid>
                <Grid item xs={12} md={6} xl={4}>
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="mother-tongue-label">Mother Tongue</InputLabel>
                        <Select
                            labelId="mother-tongue-label"
                            value={motherTongue}
                            onChange={(e) => setMotherTongue(e.target.value)}
                            label="Mother Tongue"
                        >
                            <MenuItem value="tamil">Tamil</MenuItem>
                            <MenuItem value="english">English</MenuItem>
                            <MenuItem value="spanish">Spanish</MenuItem>
                            <MenuItem value="chinese">Chinese</MenuItem>
                            {/* add more options here */}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={4}>
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="Maritual-Status">Maritual Status</InputLabel>
                        <Select
                            labelId="Maritual-Status"
                            value={maritalStatus}
                            onChange={(e) => setMaritalStatus(e.target.value)}
                            label="Mother Tongue"
                        >
                            <MenuItem value="Unmarried">Unmarried</MenuItem>
                            <MenuItem value="Divorced">Divorced</MenuItem>

                            {/* add more options here */}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {/* <Input type="file" onChange={(e) => setPhoto(e.target.files[0])} fullWidth variant="outlined" /> */}
                    <Button variant="contained" component="label">
                        Upload Photo
                        <input type="file" hidden onChange={(e) => setPhoto(e.target.files[0])} />
                    </Button>{' '}
                    {photo}
                </Grid>
            </Grid>
            <br></br>
            <Box>
                <Typography>Physical Info</Typography>
            </Box>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="height-label">Height</InputLabel>
                        <Select labelId="height-label" value={height} onChange={(e) => setHeight(e.target.value)} label="Height">
                            <MenuItem value="4ft">4ft or less</MenuItem>
                            <MenuItem value="4ft 1in">4ft 1in</MenuItem>
                            <MenuItem value="4ft 2in">4ft 2in</MenuItem>
                            <MenuItem value="4ft 3in">4ft 3in</MenuItem>
                            <MenuItem value="4ft 4in">4ft 4in</MenuItem>
                            <MenuItem value="4ft 5in">4ft 5in</MenuItem>
                            <MenuItem value="4ft 6in">4ft 6in</MenuItem>
                            <MenuItem value="4ft 7in">4ft 7in</MenuItem>
                            <MenuItem value="4ft 8in">4ft 8in</MenuItem>
                            <MenuItem value="4ft 9in">4ft 9in</MenuItem>
                            <MenuItem value="4ft 10in">4ft 10in</MenuItem>
                            <MenuItem value="4ft 11in">4ft 11in</MenuItem>
                            <MenuItem value="5ft">5ft</MenuItem>
                            <MenuItem value="5ft 1in">5ft 1in</MenuItem>
                            <MenuItem value="5ft 2in">5ft 2in</MenuItem>
                            <MenuItem value="5ft 3in">5ft 3in</MenuItem>
                            <MenuItem value="5ft 4in">5ft 4in</MenuItem>
                            <MenuItem value="5ft 5in">5ft 5in</MenuItem>
                            <MenuItem value="5ft 6in">5ft 6in</MenuItem>
                            <MenuItem value="5ft 7in">5ft 7in</MenuItem>
                            <MenuItem value="5ft 8in">5ft 8in</MenuItem>
                            <MenuItem value="5ft 9in">5ft 9in</MenuItem>
                            <MenuItem value="5ft 10in">5ft 10in</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField label="Weight" value={weight} onChange={(e) => setWeight(e.target.value)} fullWidth variant="outlined" />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="physical-status-label">Physical Status</InputLabel>
                        <Select
                            labelId="physical-status-label"
                            value={physicalStatus}
                            onChange={(e) => setPhysicalStatus(e.target.value)}
                            label="Physical Status"
                        >
                            <MenuItem value="normal">Normal</MenuItem>
                            <MenuItem value="physically-challenged">Physically Challenged</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="body-type-label">Body Type</InputLabel>
                        <Select labelId="body-type-label" value={bodyType} onChange={(e) => setBodyType(e.target.value)} label="Body Type">
                            <MenuItem value="slim">Slim</MenuItem>
                            <MenuItem value="athletic">Athletic</MenuItem>
                            <MenuItem value="average">Average</MenuItem>
                            <MenuItem value="heavy">Heavy</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="complexion-label">Complexion</InputLabel>
                        <Select
                            labelId="complexion-label"
                            value={complexion}
                            onChange={(e) => setComplexion(e.target.value)}
                            label="Complexion"
                        >
                            <MenuItem value="fair">Fair</MenuItem>
                            <MenuItem value="wheatish">Wheatish</MenuItem>
                            <MenuItem value="dark">Dark</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="food-habit-label">Food Habit</InputLabel>
                        <Select
                            labelId="food-habit-label"
                            value={foodHabit}
                            onChange={(e) => setFoodHabit(e.target.value)}
                            label="Food Habit"
                        >
                            <MenuItem value="vegetarian">Vegetarian</MenuItem>
                            <MenuItem value="non-vegetarian">Non-Vegetarian</MenuItem>
                            <MenuItem value="eggetarian">Eggetarian</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>
            <br></br>
            <Box>
                <Typography>Family Info</Typography>
            </Box>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="Father's Name"
                        value={fatherName}
                        onChange={(e) => setFatherName(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="Father's Job"
                        value={fatherJob}
                        onChange={(e) => setFatherJob(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="Mother's Name"
                        value={motherName}
                        onChange={(e) => setMotherName(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="Mother's Job"
                        value={motherJob}
                        onChange={(e) => setMotherJob(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="Number of Brothers"
                        value={noOfBrother}
                        onChange={(e) => setNoOfBrother(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormGroup fullWidth variant="outlined">
                        <FormControlLabel
                            control={<Checkbox checked={brotherMarried} onChange={(e) => setBrotherMarried(e.target.checked)} />}
                            label="Brother Married"
                        />
                    </FormGroup>
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField
                        label="Number of Sisters"
                        value={noOfSister}
                        onChange={(e) => setNoOfSister(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormGroup fullWidth variant="outlined">
                        <FormControlLabel
                            control={<Checkbox checked={sisterMarried} onChange={(e) => setSisterMarried(e.target.checked)} />}
                            label="Sister Married"
                        />
                    </FormGroup>
                </Grid>
            </Grid>
            <br></br>
            <Box>
                <Typography>Education & Job</Typography>
            </Box>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField
                        label="Educational Qualification"
                        value={educationalQualification}
                        onChange={(e) => setEducationalQualification(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField label="Job" value={job} onChange={(e) => setJob(e.target.value)} fullWidth variant="outlined" />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField
                        label="Income per Month"
                        value={incomePerMonth}
                        onChange={(e) => setIncomePerMonth(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
            </Grid>
            <br></br>
            <Box>
                <Typography>Background</Typography>
            </Box>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="religious-label">Religious</InputLabel>
                        <Select
                            labelId="religious-label"
                            value={religious}
                            onChange={(e) => setReligious(e.target.value)}
                            label="Religious"
                        >
                            <MenuItem value="hindu">Hindu</MenuItem>
                            <MenuItem value="muslim">Muslim</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>
            </Grid>
            <br></br>
            <Box>
                <Typography>Communication</Typography>
            </Box>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField
                        label="Contact Person"
                        value={contactPerson}
                        onChange={(e) => setContactPerson(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="Contact Number"
                        value={contactNo}
                        onChange={(e) => setContactNo(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField
                        label="WhatsApp Number"
                        value={whatsApp}
                        onChange={(e) => setWhatsApp(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField label="Address" value={address} onChange={(e) => setAddress(e.target.value)} fullWidth variant="outlined" />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    <TextField label="City" value={city} onChange={(e) => setCity(e.target.value)} fullWidth variant="outlined" />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <TextField
                        label="District"
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        fullWidth
                        variant="outlined"
                    />
                </Grid>
                <Grid item xs={12} md={6} xl={6}>
                    {' '}
                    <FormControl fullWidth variant="outlined">
                        <InputLabel id="state-label">State</InputLabel>
                        <Select labelId="state-label" value={state} onChange={(e) => setState(e.target.value)} label="State">
                            <MenuItem value="Andhra Pradesh">Andhra Pradesh</MenuItem>
                            <MenuItem value="Arunachal Pradesh">Arunachal Pradesh</MenuItem>
                            <MenuItem value="Assam">Assam</MenuItem>
                            <MenuItem value="Bihar">Bihar</MenuItem>
                            <MenuItem value="Chhattisgarh">Chhattisgarh</MenuItem>
                            <MenuItem value="Goa">Goa</MenuItem>
                            <MenuItem value="Gujarat">Gujarat</MenuItem>
                            <MenuItem value="Haryana">Haryana</MenuItem>
                            <MenuItem value="Himachal Pradesh">Himachal Pradesh</MenuItem>
                            <MenuItem value="Jharkhand">Jharkhand</MenuItem>
                            <MenuItem value="Karnataka">Karnataka</MenuItem>
                            <MenuItem value="Kerala">Kerala</MenuItem>
                            <MenuItem value="Madhya Pradesh">Madhya Pradesh</MenuItem>
                            <MenuItem value="Maharashtra">Maharashtra</MenuItem>
                            <MenuItem value="Manipur">Manipur</MenuItem>
                            <MenuItem value="Meghalaya">Meghalaya</MenuItem>
                            <MenuItem value="Mizoram">Mizoram</MenuItem>
                            <MenuItem value="Nagaland">Nagaland</MenuItem>
                            <MenuItem value="Odisha">Odisha</MenuItem>
                            <MenuItem value="Punjab">Punjab</MenuItem>
                            <MenuItem value="Rajasthan">Rajasthan</MenuItem>
                            <MenuItem value="Sikkim">Sikkim</MenuItem>
                            <MenuItem value="Tamil Nadu">Tamil Nadu</MenuItem>
                            <MenuItem value="Telangana">Telangana</MenuItem>
                            <MenuItem value="Tripura">Tripura</MenuItem>
                            <MenuItem value="Uttar Pradesh">Uttar Pradesh</MenuItem>
                            <MenuItem value="Uttarakhand">Uttarakhand</MenuItem>
                            <MenuItem value="West Bengal">West Bengal</MenuItem>
                        </Select>
                    </FormControl>
                </Grid>

                {/* <Grid item xs={12} md={6} xl={6}></Grid>
                <Grid item xs={12} md={6} xl={6}></Grid> */}
            </Grid>
            {/* add other form fields */}
            <Button type="submit">Submit</Button>
        </form>
    );
};

export default MyForm;
