import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
//import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%'
    },
    accordion: {
        marginTop: theme.spacing(2)
    },
    formControl: {
        minWidth: 200,
        marginTop: theme.spacing(2)
    }
}));

function getSteps() {
    return ['Step 1', 'Step 2', 'Step 3'];
}

function getStepContent(step) {
    switch (step) {
        case 0:
            return (
                <Accordion className={classes.accordion}>
                    <AccordionSummary>
                        <Typography variant="h6">Personal Information</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <form>{/* Add Personal Information Fields Here */}</form>
                    </AccordionDetails>
                </Accordion>
            );
        case 1:
            return (
                <Accordion className={classes.accordion}>
                    <AccordionSummary>
                        <Typography variant="h6">Educational Information</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <form>{/* Add Educational Information Fields Here */}</form>
                    </AccordionDetails>
                </Accordion>
            );
        case 2:
            return (
                <Accordion className={classes.accordion}>
                    <AccordionSummary>
                        <Typography variant="h6">Job Information</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <form>{/* Add Job Information Fields Here */}</form>
                    </AccordionDetails>
                </Accordion>
            );
        default:
            return 'Unknown step';
    }
}

export default function App() {
    const classes = useStyles();
    const [activeStep, setActiveStep] = useState(0);
    const steps = getSteps();

    const handleNext = () => {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleReset = () => {
        setActiveStep(0);
    };

    return (
        <div className={classes.root}>
            <Stepper activeStep={activeStep}>
                {steps.map((label) => {
                    const stepProps = {};
                    const labelProps = {};
                    return (
                        <Step key={label} {...stepProps}>
                            <StepLabel {...labelProps}>{label}</StepLabel>
                        </Step>
                    );
                })}
            </Stepper>
            <div>
                {activeStep === steps.length ? (
                    <div>
                        <Typography>All steps completed</Typography>
                        <Button onClick={handleReset}>Reset</Button>
                    </div>
                ) : (
                    <div>
                        {getStepContent(activeStep)}
                        <div>
                            <Button disabled={activeStep === 0} onClick={handleBack}>
                                Back
                            </Button>
                            <Button variant="contained" color="primary" onClick={handleNext}>
                                {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
                            </Button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
