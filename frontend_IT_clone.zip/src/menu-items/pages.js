// assets
import { IconKey } from '@tabler/icons';
import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
//import AcUnitIcon from '@mui/icons-material/cUnitIcon';
// constant
const icons = {
    IconKey,
    AssignmentOutlinedIcon
};
//const icon1 = <AcUnitIcon color="warning" />;
// ==============================|| EXTRA PAGES MENU ITEMS ||============================== //

const pages = {
    id: 'pages',
    //title: 'Pages',
    //caption: 'Pages Caption',
    type: 'group',
    children: [
        {
            id: 'authentication',
            title: 'Task Sharing System',
            type: 'collapse',
            icon: icons.AssignmentOutlinedIcon,

            children: [
                {
                    id: 'expire-ad',
                    title: 'Expire Advertisement',
                    type: 'item',
                    url: '/pages/login/login3',
                    target: true
                    //icon: icons.IconKey
                },
                {
                    id: 'admin-review',
                    title: 'Admin Review Job',
                    type: 'item',
                    url: '/pages/register/register3',
                    target: true
                },
                {
                    id: 'vendor-approval',
                    title: 'Vendor Approval',
                    type: 'item',
                    url: '/pages/register/register3',
                    target: true
                }
            ]
        }
    ]
};

export default pages;
