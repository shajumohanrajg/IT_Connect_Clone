// assets
import { IconBrandChrome, IconHelp } from '@tabler/icons';
import BrushOutlinedIcon from '@mui/icons-material/BrushOutlined';

import PermMediaOutlinedIcon from '@mui/icons-material/PermMediaOutlined';

import SecurityUpdateGoodOutlinedIcon from '@mui/icons-material/SecurityUpdateGoodOutlined';

// constant
const icons = { IconBrandChrome, IconHelp, BrushOutlinedIcon, PermMediaOutlinedIcon, SecurityUpdateGoodOutlinedIcon };

// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //

const other = {
    id: 'sample-docs-roadmap',
    type: 'group',
    children: [
        {
            id: 'hoarding',
            title: 'Hoarding',
            type: 'item',
            url: '/hoardinglist',
            icon: icons.BrushOutlinedIcon,
            breadcrumbs: false
        },
        {
            id: 'media-research',
            title: 'Media Research',
            type: 'item',
            url: 'https://codedthemes.gitbook.io/berry/',
            icon: icons.PermMediaOutlinedIcon,
            external: true,
            target: true
        }
        // {
        //     id: 'mobile-app',
        //     title: 'Mobile App',
        //     type: 'item',
        //     url: '/sample-page',
        //     icon: icons.SecurityUpdateGoodOutlinedIcon,
        //     breadcrumbs: false
        // }
    ]
};

export default other;
