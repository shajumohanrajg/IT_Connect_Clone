import { styled } from '@mui/material/styles';

const WaveContainer = styled('div')({
    position: 'relative',
    height: '200px',
    overflow: 'hidden'
});

const Wave = styled('div')({
    position: 'absolute',
    width: '100%',
    height: '100%',
    background: 'linear-gradient(90deg, #64b5f6, #2196f3)',
    animation: '$waveAnimation 2s infinite linear',
    transformOrigin: 'bottom'
});

const waveAnimation = `@keyframes waveAnimation {
  0% {
    transform: translateY(0%);
  }
  100% {
    transform: translateY(-50%);
  }
}`;

const WavePattern = () => {
    return (
        <WaveContainer>
            <Wave />
        </WaveContainer>
    );
};

export default WavePattern;
