 <Grid container spacing={2}>
                    <Grid container spacing={2} md={4}>
                        <Grid item md={4}>
                            {/* First Grid */}
                            <Grid container direction="column" spacing={2}>
                                <Grid item>
                                    {/* Image */}
                                    <img src={Branding} alt="wsfeefef" />
                                </Grid>
                                <Grid item>
                                    {/* Title */}
                                    <Typography variant="h6">Your Title</Typography>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid item md={8}>
                            {/* Second Grid */}
                            <Grid container direction="row" spacing={2}>
                                <Grid item md={12}>
                                    <Typography variant="h6">Second Grid Title</Typography>
                                </Grid>
                                <br></br>
                                <Grid container md={12}>
                                    <Grid item>
                                        {/* Subgrid 1 */}
                                        <Grid container spacing={2}>
                                            <Typography variant="subtitle2">material</Typography>
                                        </Grid>
                                    </Grid>
                                    <Grid item>
                                        {/* Subgrid 2 */}
                                        <Grid container spacing={2}>
                                            <Typography variant="subtitle2">:</Typography>
                                        </Grid>
                                    </Grid>
                                    <Grid item>
                                        {/* Subgrid 3 */}
                                        <Grid container spacing={2}>
                                            <Typography variant="subtitle2">Vinyl board main</Typography>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid container>
                    <Box>
                        <Grid item xs={12} sm={6} md={2} lg={2}>
                            {/* <CardMedia
                                component="img"
                                sx={{
                                    width: '100%',
                                    height: 'auto'
                                }}
                                image={Branding}
                                alt="Image"
                            /> */}
                            <img
                                src={Branding}
                                //width="50px"
                                alt="hhsehf"
                                sx={{
                                    width: '100%',
                                    height: 'auto'
                                }}
                            />
                            <CardContent>
                                <Typography variant="h5" component="div">
                                    Card Title
                                </Typography>
                            </CardContent>
                        </Grid>
                        <Grid item xs={12} sm={6} md={3} lg={3}>
                            <CardContent>
                                <Typography variant="h6" component="div">
                                    Card Title
                                </Typography>
                                <Grid container>
                                    <Grid item xs={4}>
                                        <Typography variant="body1" component="div">
                                            Subgrid 1
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={1}>
                                        <Typography variant="body1" component="div">
                                            :
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={4}>
                                        <Typography variant="body1" component="div">
                                            Subgrid 3
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </CardContent>
                        </Grid>
                    </Box>
                </Grid>
                <Grid container spacing={2}>
                    <Grid item md={4}>
                        <Card>
                            {/* First Grid */}
                            <Grid container spacing={2}>
                                <Grid item md={4}>
                                    <Grid container direction="column" spacing={2}>
                                        <Grid item>
                                            {/* Image */}
                                            <img src={Branding} alt="ascasc" />
                                        </Grid>
                                        <Grid item>
                                            {/* Title */}
                                            <Typography variant="h6">Your Title</Typography>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item md={6}>
                                    {/* Second Grid */}
                                    <Grid container direction="row" spacing={2}>
                                        <Grid item md={12}>
                                            <Typography variant="h6">Second Grid Title</Typography>
                                        </Grid>
                                        <Grid container item md={12}>
                                            <Grid item>
                                                {/* Subgrid 1 */}
                                                <Grid container spacing={2}>
                                                    <Typography variant="subtitle2">material</Typography>
                                                </Grid>
                                            </Grid>
                                            <Grid item>
                                                {/* Subgrid 2 */}
                                                <Grid container spacing={2}>
                                                    <Typography variant="subtitle2">:</Typography>
                                                </Grid>
                                            </Grid>
                                            <Grid item>
                                                {/* Subgrid 3 */}
                                                <Grid container spacing={2}>
                                                    <Typography variant="subtitle2">Vinyl board main</Typography>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Card>
                    </Grid>
                </Grid>
                <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                    <Card sx={{ boxShadow: 0, p: 2, borderTop: '1px solid #ebebeb' }}>
                        <Grid item xs={12} sm={12} md={6} lg={6}>
                            <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                <Grid item xs={4} sm={4} md={4} lg={4}>
                                    <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                        <Grid container direction="column" spacing={2}>
                                            <Grid item>
                                                {/* Image */}
                                                <img src={Branding} alt="ascasc" />
                                            </Grid>
                                            <Grid item>
                                                {/* Title */}
                                                <Typography variant="h6">Your Title</Typography>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item xs={4} sm={4} md={6} lg={6}>
                                    {' '}
                                    <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                        <Grid container direction="column" spacing={2}>
                                            <Grid item>
                                                {/* Image */}
                                                <img src={Branding} alt="ascasc" />
                                            </Grid>
                                            <Grid item>
                                                {/* Title */}
                                                <Typography variant="h6">Your Title</Typography>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Card>
                </Grid>
                {/* <Card sx={{ display: 'flex' }}>
                    <CardMedia component="img" sx={{ width: 151 }} image={Branding} alt="Live from space album cover" />
                    <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                        <CardContent sx={{ flex: '1 0 auto' }}>
                            <Typography component="div" variant="h5">
                                Live From Space
                            </Typography>
                            <Typography variant="subtitle1" color="text.secondary" component="div">
                                Mac Miller
                            </Typography>
                        </CardContent>
                        <Box sx={{ display: 'flex', alignItems: 'center', pl: 1, pb: 1 }}></Box>
                    </Box>
                </Card> */}
                {/* <Box sx={{ display: 'flex' }}>
                    <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                        <Grid item xs={12} sm={12} md={4} lg={4}>
                            <Card>
                                <Grid container spacing={0} direction="row" sx={{ mt: 0 }}>
                                    <Grid item xs={4} sm={4} md={3} lg={3}>
                                        <Box>
                                            <img src={Branding} alt="ascasc" width="120" />
                                            <Typography variant="subtitle1" color="text.secondary" component="div">
                                                Mac Miller
                                            </Typography>
                                        </Box>
                                    </Grid>

                                    <Grid item xs={7} sm={7} md={6} lg={6} sx={{ p: 1 }}>
                                        <Box>
                                            <Typography component="div" variant="h5">
                                                Live From Space
                                            </Typography>
                                            <Typography variant="subtitle1" color="text.secondary" component="div">
                                                Mac Miller
                                            </Typography>
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Card>
                        </Grid>
                    </Grid>
                </Box> */}
                <br></br>
                <Grid container spacing={2}>
                    {/* First grid item */}
                    <Grid item md={4}>
                        <Grid container spacing={2} direction="row">
                            {/* Subgrid 1 */}
                            <Grid item xs={4} sm={4} md={4}>
                                {/* <img src={Branding} alt="ascasc" width="120" /> */}
                                <Avatar alt="Remy Sharp" src={Branding} sx={{ width: 100, height: 100 }} variant="square" />
                                <Typography component="div" variant="h5">
                                    Live From Space
                                </Typography>
                            </Grid>
                            {/* Subgrid 2 */}
                            <Grid item xs={6} sm={6} md={6}>
                                <Typography component="div" variant="h5">
                                    Live From Space
                                </Typography>
                                <Typography variant="subtitle1" color="text.secondary" component="div">
                                    Mac Miller
                                </Typography>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                        <Grid container spacing={2}>
                            <Card>
                                <Grid item xs={12} sm={6}>
                                    <CardContent>
                                        <img src={Branding} alt="sdff" style={{ maxWidth: '100%' }} />
                                        <Typography variant="h5" gutterBottom>
                                            Title
                                        </Typography>
                                    </CardContent>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    {' '}
                                    <CardContent>
                                        <Typography variant="h5" gutterBottom>
                                            Title
                                        </Typography>
                                        <Typography variant="body1">Data</Typography>
                                    </CardContent>
                                </Grid>
                            </Card>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <Card>
                            <CardContent>
                                <Typography variant="h5" gutterBottom>
                                    Title
                                </Typography>
                                <Typography variant="body1">Data</Typography>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
                <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                        <Card>
                            <CardContent>
                                <img src={Branding} alt="sdfsdfc" style={{ maxWidth: '100%' }} />
                                <Typography variant="h5" gutterBottom>
                                    Title
                                </Typography>
                                <Typography variant="body1">Data</Typography>
                            </CardContent>
                        </Card>
                    </Grid>
                </Grid>
                <Grid container spacing={2}>
                    <Card>
                        <CardContent>
                            <Grid item sm={12} xs={12} md={4} lg={4}>
                                <Grid container spacing={2}>
                                    <Grid item xs={12} sm={6} md={4}>
                                        <img src={Branding} alt="Casefe" style={{ maxWidth: '100%' }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={7}>
                                        <Typography variant="h5" gutterBottom>
                                            Title
                                        </Typography>
                                        <Grid container spacing={2}>
                                            <Grid item xs={4}>
                                                <Typography variant="body1">Item 1</Typography>
                                            </Grid>
                                            <Grid item xs={1}>
                                                <Typography variant="body1">:</Typography>
                                            </Grid>
                                            <Grid item xs={4}>
                                                <Typography variant="body1">Item 3</Typography>
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid container spacing={1} direction="row">
                    <Grid item sm={12} xs={12} md={4} lg={4}>
                        <Card
                            sx={{
                                height: 'auto',
                                //boxShadow: 2,
                                //borderBottom: "2px solid grey",
                                //borderBottomStyle: 'inset',
                                //borderTopRight: '2px solid black',
                                borderRightColor: 'black',
                                position: 'absolute',
                                overflow: 'hidden'
                            }}
                        >
                            <Grid
                                container
                                //spacing={2}
                                //justifyContent="center"
                                //alignItems="center"
                                sx={{
                                    position: 'absolute',
                                    overflow: 'hidden'
                                }}
                            >
                                <Grid item xs={6} sm={6} md={4} lg={4}>
                                    <Stack direction="column" justifyContent="center" alignItems="center" spacing={1}>
                                        {' '}
                                        <Box textAlign="center">
                                            {' '}
                                            {/* <img
                                                src={Branding}
                                                alt="Row"
                                                style={{ width: '100%', height: 'auto', cursor: 'pointer', width: 100 }}
                                                // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex
                                                tabIndex="0"
                                            /> */}
                                            <Avatar alt="Remy Sharp" src={Branding} sx={{ width: 100, height: 100 }} variant="square" />
                                        </Box>
                                    </Stack>
                                </Grid>
                                <Grid item xs={6} sm={6} md={5} lg={5}>
                                    <Typography component="div" variant="h5">
                                        Live From Space
                                    </Typography>
                                    <Typography variant="subtitle1" color="text.secondary" component="div">
                                        Mac Miller
                                    </Typography>
                                </Grid>
                            </Grid>
                        </Card>
                    </Grid>
                </Grid>