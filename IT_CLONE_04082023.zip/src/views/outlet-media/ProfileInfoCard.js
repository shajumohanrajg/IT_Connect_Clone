import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import Divider from '@mui/material/Divider';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';

function ProfileInfoCard({ title, description, info, social, action, shadow }) {
    // ... (rest of the component code remains unchanged)

    return (
        <Card sx={{ height: '100%', boxShadow: !shadow && 'none' }}>
            <CardHeader
                title={
                    <Typography variant="h6" fontWeight="medium" textTransform="capitalize">
                        {title}
                    </Typography>
                }
                action={
                    <Typography component="a" href={action.route} variant="body2" color="secondary">
                        <Tooltip title={action.tooltip} placement="top">
                            {/* <Icon>edit</Icon> */}
                        </Tooltip>
                    </Typography>
                }
            />
            <CardContent>
                <Typography variant="button" color="text" fontWeight="light" gutterBottom>
                    {description}
                </Typography>
                <Divider />
                <Box display="flex" py={1} pr={2}>
                    <Typography variant="button" fontWeight="bold" textTransform="capitalize">
                        Fullname:
                    </Typography>
                    <Typography variant="button" fontWeight="regular" color="text">
                        rgrg
                    </Typography>
                </Box>
                <Box display="flex" py={1} pr={2}>
                    <Typography variant="button" fontWeight="bold" textTransform="capitalize">
                        Email:
                    </Typography>
                    <Typography variant="button" fontWeight="regular" color="text">
                        rgrg
                    </Typography>
                </Box>
                <Box display="flex" py={1} pr={2}>
                    <Typography variant="button" fontWeight="bold" textTransform="capitalize">
                        Mobile:
                    </Typography>
                    <Typography variant="button" fontWeight="regular" color="text">
                        rgrg
                    </Typography>
                </Box>
                <Box display="flex" py={1} pr={2}>
                    <Typography variant="button" fontWeight="bold" textTransform="capitalize">
                        Poorvika ID:
                    </Typography>
                    <Typography variant="button" fontWeight="regular" color="text">
                        rgrg
                    </Typography>
                </Box>
                {/* ... (renderItems and renderSocial code remains unchanged) */}
            </CardContent>
        </Card>
    );
}

// ... (rest of the component code remains unchanged)

export default ProfileInfoCard;
