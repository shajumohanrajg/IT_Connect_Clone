// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
//import { makeStyles } from '@material-ui/core/styles';
// import { DropzoneArea } from 'material-ui-dropzone';
// import 'react-dropzone-uploader/dist/styles.css';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

// eslint-disable-next-line prettier/prettier
import {
    Alert,
    Box,
    Button,
    Card,
    CircularProgress,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Select,
    Snackbar,
    Stack,
    TextField,
    Typography
} from '@mui/material';
import MuiAlert from '@mui/material/Alert';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Modal from '@mui/material/Modal';
import Axios from 'axios';
import React, { useState } from 'react';
// import { useNavigate } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

//import Swal from 'sweetalert2';

import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';
import Table from './brandtable';

import AddIcon from '@mui/icons-material/Add';
import { Fab, useMediaQuery, useTheme } from '@mui/material';

//import SwalAlert from './SwalAlert';

//import { Brandapi } from '../apicomp/Apiurls';

//import './swal.css';

// ==============================|| SAMPLE PAGE ||============================== //

const Alert1 = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

const SamplePage = () => {
    //const navigate = useNavigate();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const classes = useStyles();
    //const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    const navigate = useNavigate();
    //const [responseMessage, setResponseMessage] = useState('');
    const [location, setLocation] = useState('');
    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const [open1, setOpen1] = React.useState(false);
    const handleOpen = () => setOpen(true);
    // const handleClose = () => setOpen(false);
    const handleClose = () => {
        setOpen(false);
        setErrorMessage('');
    };

    const handleCloseerror = () => {
        setOpen1(false);
        setErrorMessage('');
    };

    function getPhoto(event) {
        setPhoto(URL.createObjectURL(event.target.files[0]));
        setPhoto1(event.target.files[0]);
    }
    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };

    const [loading, setLoading] = useState(false);
    const [swalopen, setSwalOpen] = useState(false);

    const [name, setName] = useState('');
    const [status, setStatus] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [requiredalert, setRequiredalert] = useState('');
    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        const userID = localStorage.getItem('id');

        if (!name || !status) {
            // Display an error message or perform any other validation logic
            setRequiredalert('Please fill all mandatory fields.');

            return;
        }
        setLoading(true);
        e.preventDefault();
        Axios.post(
            'http://127.0.0.1:1212/backend/auth/userr/',
            {
                // id: id,
                name: name,
                status: status,
                created_by: userID,
                modified_by: userID
            },
            {
                headers: {
                    Authorization: `Token ${token}` // Include the token in the request headers
                }
            }
        ).then(
            (response) => {
                setLoading(false);

                setResponseMessage('SuccesssFully Brand Created');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);

                //handleClose();
                // enqueueSnackbar('Data Entry Successful', {
                //     variant: 'success',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(response);

                // setSwalOpen(true);
                // history.push('/dashboard/bomat_table2');
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            },
            (error) => {
                setLoading(false);
                if (error.response) {
                    const statusCode = error.response.status;
                    const errorMessage = error.response.data.message;

                    setErrorMessage(`Error (${statusCode}): ${errorMessage}`);

                    // Check for specific error status codes and show alerts accordingly
                    if (statusCode === 403) {
                        // You don't have access for this module
                        alert("You Don't Have Access For This Module");
                        // Reload the page after displaying the alert
                        window.location.reload();
                    } else if (statusCode === 400) {
                        // Bad request error
                        alert('Bad request. Please check your data and try again.');
                    } else if (statusCode === 404) {
                        // Resource not found error
                        alert('Resource not found. Please check the URL or try again later.');
                    } else {
                        // Handle other error codes with appropriate alerts
                        alert('An unexpected error occurred. Please try again later.');
                    }
                } else {
                    // Handle other unexpected errors with a generic alert
                    alert('An unexpected error occurred. Please try again later.');
                }
                // enqueueSnackbar('Check Data and Try Again', {
                //     variant: 'Error',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                // if (error.response) {
                //     const statusCode = error.response.status;
                //     const errorMessage = error.response.data.message;

                //     setErrorMessage(`Error (${statusCode}): ${errorMessage}`);
                // } else {
                //     setErrorMessage('An unexpected error occurred');
                // }

                console.log(error);
            }
        );
    };

    const handleswalClose = () => {
        setSwalOpen(false);
    };
    return (
        <div>
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Brand
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    {isMobile ? (
                        <Fab color="primary" aria-label="add" size="medium" className={classes.fabbutton} onClick={handleOpen}>
                            <AddIcon sx={{ color: 'white' }} />
                        </Fab>
                    ) : (
                        <Button
                            className={classes.Button}
                            variant="contained"
                            //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                            // //onClick={handleOpen}
                            // href="/hoardingform"
                            onClick={handleOpen}
                            startIcon={<AddCircleOutlinedIcon />}
                        >
                            Brand
                        </Button>
                    )}
                </Stack>
            </Card>
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}
            <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                <Box sx={style}>
                    {/* {responseMessage && <SwalAlert title="Success" text={responseMessage} icon="success" />} */}

                    <Snackbar open1={!!errorMessage} autoHideDuration={1000}>
                        <Alert1 severity="info" onClose={handleCloseerror}>
                            {errorMessage}
                        </Alert1>
                    </Snackbar>

                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <List sx={{ width: '100%', maxWidth: 360 }}>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar className={classes.Button} sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                        B
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    <Typography variant="h3">Create Brand</Typography>
                                </ListItemText>
                            </ListItem>
                        </List>

                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                label="Name"
                                id="name"
                                name="name"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                fullWidth
                                required // Added required attribute
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    labelid="status-select-label"
                                    id="status-select"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    label="Status"
                                    name="status"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a Status</em>
                                    </MenuItem>
                                    <MenuItem value="Active">Active</MenuItem>
                                    <MenuItem value="Inactive">Inactive</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            {requiredalert && <Alert severity="error">{requiredalert}</Alert>}
                        </Grid>

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    onClick={handleSubmit}
                                    //startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Create
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                    {loading && (
                        <Box
                            sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                position: 'fixed',
                                top: 0,
                                left: 0,
                                width: '100%',
                                height: '100%'
                                //backgroundColor: 'rgba(0, 0, 0, 0.5)'
                            }}
                        >
                            <CircularProgress color="primary" />
                        </Box>
                    )}
                </Box>
            </Modal>
            <br></br>

            <Table />
        </div>
    );
};

export default withAuth(SamplePage);
