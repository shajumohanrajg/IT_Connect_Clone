import Avatar from '@mui/material/Avatar'; // Import MUI Avatar
import Box from '@mui/material/Box'; // Import MUI Box
import Card from '@mui/material/Card';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography'; // Import MUI Typography
import backgroundImage from 'assets/images/bg-profile.jpeg';
import burceMars from 'assets/images/bruce-mars.jpg';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';

function Header({ children }) {
    const [tabsOrientation, setTabsOrientation] = useState('horizontal');
    const [tabValue, setTabValue] = useState(0);

    useEffect(() => {
        function handleTabsOrientation() {
            return window.innerWidth < 600 ? setTabsOrientation('vertical') : setTabsOrientation('horizontal');
        }

        window.addEventListener('resize', handleTabsOrientation);
        handleTabsOrientation();

        return () => window.removeEventListener('resize', handleTabsOrientation);
    }, [tabsOrientation]);

    const handleSetTabValue = (event, newValue) => setTabValue(newValue);

    return (
        <Box position="relative" mb={5}>
            <Box
                display="flex"
                alignItems="center"
                position="relative"
                minHeight="18.75rem"
                borderRadius="xl"
                sx={{
                    backgroundImage: `linear-gradient(rgba(132, 141, 145, 0.6), rgba(3, 53, 77, 0.6)), url(${backgroundImage})`,

                    // backgroundImage: ({ functions: { rgba, linearGradient }, palette: { gradients } }) =>
                    //     `${linearGradient(rgba(gradients.info.main, 0.6), rgba(gradients.info.state, 0.6))}, url(${backgroundImage})`,
                    backgroundSize: 'cover',
                    backgroundPosition: '50%',
                    overflow: 'hidden'
                }}
            />
            <Card
                sx={{
                    position: 'relative',
                    mt: -8,
                    mx: 3,
                    py: 2,
                    px: 2
                }}
            >
                <Grid container spacing={3} alignItems="center">
                    <Grid item>
                        <Avatar src={burceMars} alt="profile-image" sizes="xl" />
                    </Grid>
                    <Grid item>
                        <Box height="100%" mt={0.5} lineHeight={1}>
                            <Typography variant="h5" fontWeight="medium">
                                Richard Davis
                            </Typography>
                            <Typography variant="button" color="text" fontWeight="regular">
                                CEO / Co-Founder
                            </Typography>
                        </Box>
                    </Grid>
                    {/* <Grid item xs={12} md={6} lg={4} sx={{ ml: 'auto' }}>
                        <AppBar position="static">
                            <Tabs orientation={tabsOrientation} value={tabValue} onChange={handleSetTabValue}>
                                <Tab
                                    label="App"
                                    icon={
                                        <Icon fontSize="small" sx={{ mt: -0.25 }}>
                                            home
                                        </Icon>
                                    }
                                />
                                <Tab
                                    label="Message"
                                    icon={
                                        <Icon fontSize="small" sx={{ mt: -0.25 }}>
                                            email
                                        </Icon>
                                    }
                                />
                                <Tab
                                    label="Settings"
                                    icon={
                                        <Icon fontSize="small" sx={{ mt: -0.25 }}>
                                            settings
                                        </Icon>
                                    }
                                />
                            </Tabs>
                        </AppBar>
                    </Grid> */}
                </Grid>
                {children}
            </Card>
        </Box>
    );
}

Header.propTypes = {
    children: PropTypes.node
};

export default Header;
