// import { DataGrid } from '@mui/x-data-grid';
// import React from 'react';

// const columns = [
//     { field: 'id', headerName: 'ID', width: 70 },
//     { field: 'name', headerName: 'Name', width: 150 },
//     { field: 'age', headerName: 'Age', width: 90 }
//     // {
//     //     field: 'details',
//     //     headerName: 'Details',
//     //     width: 250,
//     //     renderCell: (params) => (
//     //         <div style={{ whiteSpace: 'pre-wrap' }}>
//     //             {params.row.details.map((detail, index) => (
//     //                 <div key={index}>
//     //                     <strong>Address:</strong> {detail.address}
//     //                     <br />
//     //                     <strong>Phone:</strong> {detail.phone}
//     //                 </div>
//     //             ))}
//     //         </div>
//     //     )
//     // }
// ];

// const CustomRow = ({ data }) => {
//     return (
//         <div style={{ display: 'flex', flexDirection: 'column', height: '100%', padding: '5px' }}>
//             {/* <div style={{ fontWeight: 'bold' }}>{data.name}</div> */}
//             {data.details.map((detail, index) => (
//                 <div key={index}>
//                     <strong>Address:</strong> {detail.address}
//                     <br />
//                     <strong>Phone:</strong> {detail.phone}
//                 </div>
//             ))}
//         </div>
//     );
// };

// const rows = [
//     { id: 1, name: 'John Doe', age: 25, details: [{ id: 1, address: '123 Main St', phone: '555-1234' }] },
//     { id: 2, name: 'Jane Smith', age: 30, details: [{ id: 2, address: '456 Elm St', phone: '555-5678' }] }
// ];

// const getRowId = (row) => row.id; // Specify the unique identifier property for the row

// const App = () => {
//     return (
//         <div style={{ height: 400, width: '100%' }}>
//             <DataGrid
//                 rows={rows}
//                 columns={columns}
//                 getRowId={getRowId}
//                 components={{
//                     row: CustomRow
//                 }}
//             />
//         </div>
//     );
// };

// export default App;
