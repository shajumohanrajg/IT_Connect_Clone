import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import Switch from '@mui/material/Switch';
import Typography from '@mui/material/Typography';
import { useState } from 'react';

function PlatformSettings() {
    const [followsMe, setFollowsMe] = useState(true);
    const [answersPost, setAnswersPost] = useState(false);
    const [mentionsMe, setMentionsMe] = useState(true);
    const [newLaunches, setNewLaunches] = useState(false);
    const [productUpdate, setProductUpdate] = useState(true);
    const [newsletter, setNewsletter] = useState(false);

    return (
        <Card sx={{ boxShadow: 'none' }}>
            <CardHeader
                title={
                    <Typography variant="h6" fontWeight="medium" textTransform="capitalize">
                        platform settings
                    </Typography>
                }
            />
            <CardContent>
                <Typography variant="caption" fontWeight="bold" color="text" textTransform="uppercase" gutterBottom>
                    account
                </Typography>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <Switch checked={followsMe} onChange={() => setFollowsMe(!followsMe)} />
                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                        Email me when someone follows me
                    </Typography>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <Switch checked={answersPost} onChange={() => setAnswersPost(!answersPost)} />
                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                        Email me when someone answers on my post
                    </Typography>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <Switch checked={mentionsMe} onChange={() => setMentionsMe(!mentionsMe)} />
                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                        Email me when someone mentions me
                    </Typography>
                </div>
                <Typography variant="caption" fontWeight="bold" color="text" textTransform="uppercase" gutterBottom>
                    application
                </Typography>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <Switch checked={newLaunches} onChange={() => setNewLaunches(!newLaunches)} />
                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                        New launches and projects
                    </Typography>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <Switch checked={productUpdate} onChange={() => setProductUpdate(!productUpdate)} />
                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                        Monthly product updates
                    </Typography>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                    <Switch checked={newsletter} onChange={() => setNewsletter(!newsletter)} />
                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                        Subscribe to newsletter
                    </Typography>
                </div>
            </CardContent>
        </Card>
    );
}

export default PlatformSettings;
