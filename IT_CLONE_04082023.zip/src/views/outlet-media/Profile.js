import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Divider from '@mui/material/Divider';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import React, { useState } from 'react';

import backgroundImage from 'assets/images/bg-profile.jpeg';
import burceMars from 'assets/images/bruce-mars.jpg';
import { useEffect } from 'react';
import ApiComponent from '../apicomp/ApiComponent';
import { Profileapi, Userlistapi } from '../apicomp/Apiurls';
// import Card from "@mui/material/Card";
function App() {
    const [followsMe, setFollowsMe] = useState(true);
    const [answersPost, setAnswersPost] = useState(false);
    const [mentionsMe, setMentionsMe] = useState(true);
    const [newLaunches, setNewLaunches] = useState(false);
    const [productUpdate, setProductUpdate] = useState(true);
    const [newsletter, setNewsletter] = useState(false);
    const [tabsOrientation, setTabsOrientation] = useState('horizontal');
    const [tabValue, setTabValue] = useState(0);

    const [floordiadata, setFloordiadata] = React.useState([]);
    const [userlistdata, setUserlistdata] = React.useState([]);
    useEffect(() => {
        const handleDataFetched = (data) => {
            setFloordiadata(data);
            setUserlistdata(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setFloordiadata([]);
            setUserlistdata([]);
        };
    }, []);

    const title = 'Conversations';

    const info = {
        fullName: floordiadata.username,
        mobile: '+91 9876543210',
        email: floordiadata.email,
        location: 'Chennai'
    };

    const social = [
        {
            link: 'https://www.facebook.com/CreativeTim/',
            //icon: <FacebookIcon />,
            color: 'facebook'
        },
        {
            link: 'https://twitter.com/creativetim',
            // icon: <TwitterIcon />,
            color: 'twitter'
        },
        {
            link: 'https://www.instagram.com/creativetimofficial/',
            //icon: <InstagramIcon />,
            color: 'instagram'
        }
    ];

    const profilesListData = [
        {
            image: 'profile-image-1.jpg',
            name: 'Maarimuthu',
            description: 'ASM',
            action: { type: 'internal', route: '/profile/1', label: 'View Profile' }
        },
        {
            image: 'profile-image-2.jpg',
            name: 'ManiKandan',
            description: 'RSM',
            action: { type: 'internal', route: '/profile/2', label: 'View Profile' }
        },
        {
            image: 'profile-image-2.jpg',
            name: 'Mohankumar',
            description: 'RSM',
            action: { type: 'internal', route: '/profile/2', label: 'View Profile' }
        }
        // Add more profiles as needed
    ];

    const handleSetTabValue = (event, newValue) => setTabValue(newValue);

    const labels = [];
    const values = [];
    // const { socialMediaColors } = colors;
    // const { size } = typography;

    Object.keys(info).forEach((el) => {
        if (el.match(/[A-Z\s]+/)) {
            const uppercaseLetter = Array.from(el).find((i) => i.match(/[A-Z]+/));
            const newElement = el.replace(uppercaseLetter, ` ${uppercaseLetter.toLowerCase()}`);

            labels.push(newElement);
        } else {
            labels.push(el);
        }
    });
    Object.values(info).forEach((el) => values.push(el));

    const renderItems = labels.map((label, key) => (
        <Box key={label} display="flex" py={1} pr={2}>
            <Typography variant="button" fontWeight="bold" textTransform="capitalize">
                {label}: &nbsp;
            </Typography>
            <Typography variant="button" fontWeight="regular" color="text">
                &nbsp;{values[key]}
            </Typography>
        </Box>
    ));

    const renderSocial = social.map(({ link, icon, color }) => (
        <Box
            key={color}
            component="a"
            href={link}
            target="_blank"
            rel="noreferrer"
            //fontSize={size.lg}
            //color={socialMediaColors[color].main}
            pr={1}
            pl={0.5}
            lineHeight={1}
        >
            {icon}
        </Box>
    ));

    const renderProfiles = userlistdata.map(({ image, name, description, action }) => (
        <Box key={name} component="li" display="flex" alignItems="center" py={1} mb={1}>
            <Box mr={2}>
                <Avatar src={image} alt="M" sx={{ backgroundColor: 'white' }} />
            </Box>
            <Box display="flex" flexDirection="column" alignItems="flex-start" justifyContent="center">
                <Typography variant="button" fontWeight="medium">
                    {name}
                </Typography>
                <Typography variant="caption" color="text">
                    {description}
                </Typography>
            </Box>
            {/* <Box ml="auto">
                {action.type === 'internal' ? (
                    <Typography component="a" href="" variant="text" color="info">
                        {action.label}
                    </Typography>
                ) : (
                    <Typography component="a" href="" target="_blank" rel="noreferrer" variant="text" color={action.color}>
                        {action.label}
                    </Typography>
                )}
            </Box> */}
        </Box>
    ));

    return (
        <>
            <ApiComponent apiUrl={Profileapi} onDataFetched={setFloordiadata} />
            <ApiComponent apiUrl={Userlistapi} onDataFetched={setUserlistdata} />
            <Box mt={5} mb={3}>
                <Grid container spacing={1} justifyContent="center" alignItems="stretch">
                    {/* <Grid item xs={12} md={6} xl={4}>
                        <Card sx={{ boxShadow: 'none' }}>
                            <CardHeader
                                title={
                                    <Typography variant="h6" fontWeight="medium" textTransform="capitalize">
                                        platform settings
                                    </Typography>
                                }
                            />
                            <CardContent>
                                <Typography variant="caption" fontWeight="bold" color="text" textTransform="uppercase" gutterBottom>
                                    account
                                </Typography>
                                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                                    <Switch checked={followsMe} onChange={() => setFollowsMe(!followsMe)} />
                                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                                        Email me when someone follows me
                                    </Typography>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                                    <Switch checked={answersPost} onChange={() => setAnswersPost(!answersPost)} />
                                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                                        Email me when someone answers on my post
                                    </Typography>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                                    <Switch checked={mentionsMe} onChange={() => setMentionsMe(!mentionsMe)} />
                                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                                        Email me when someone mentions me
                                    </Typography>
                                </div>
                                <Typography variant="caption" fontWeight="bold" color="text" textTransform="uppercase" gutterBottom>
                                    application
                                </Typography>
                                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                                    <Switch checked={newLaunches} onChange={() => setNewLaunches(!newLaunches)} />
                                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                                        New launches and projects
                                    </Typography>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                                    <Switch checked={productUpdate} onChange={() => setProductUpdate(!productUpdate)} />
                                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                                        Monthly product updates
                                    </Typography>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', marginBottom: 8 }}>
                                    <Switch checked={newsletter} onChange={() => setNewsletter(!newsletter)} />
                                    <Typography variant="button" fontWeight="regular" color="text" style={{ marginLeft: 8 }}>
                                        Subscribe to newsletter
                                    </Typography>
                                </div>
                            </CardContent>
                        </Card>
                    </Grid> */}
                    <Grid item xs={12} md={6} xl={6}>
                        {/* <Divider orientation="vertical" sx={{ ml: -2, mr: 1 }} /> */}
                        <Card sx={{ height: '100%', boxShadow: 'none' }}>
                            <Box
                                display="flex"
                                alignItems="center"
                                position="relative"
                                minHeight="18.75rem"
                                borderRadius="xl"
                                sx={{
                                    backgroundImage: `linear-gradient(rgba(132, 141, 145, 0.6), rgba(3, 53, 77, 0.6)), url(${backgroundImage})`,

                                    // backgroundImage: ({ functions: { rgba, linearGradient }, palette: { gradients } }) =>
                                    //     `${linearGradient(
                                    //         rgba(gradients.info.main, 0.6),
                                    //         rgba(gradients.info.state, 0.6)
                                    //     )}, url(${backgroundImage})`,
                                    backgroundSize: 'cover',
                                    backgroundPosition: '50%',
                                    overflow: 'hidden'
                                }}
                            />
                            <Box sx={{ position: 'relative', mt: -8, mx: 3, py: 2, px: 2, backgroundColor: 'white' }}>
                                <Grid container spacing={3} alignItems="center">
                                    <Grid item>
                                        <Avatar src={burceMars} alt="profile-image" />
                                    </Grid>
                                    <Grid item>
                                        <Box height="100%" mt={0.5} lineHeight={1} sx={{}}>
                                            <Typography variant="h5" fontWeight="medium">
                                                {floordiadata.username}
                                            </Typography>
                                            <Typography variant="button" color="text" fontWeight="regular">
                                                Manager
                                            </Typography>
                                        </Box>
                                    </Grid>
                                    {/* <Grid item xs={12} md={6} lg={4} sx={{ ml: 'auto' }}>
                                    <AppBar position="static">
                                        <Tabs orientation={tabsOrientation} value={tabValue} onChange={handleSetTabValue}>
                                            <Tab
                                                label="App"
                                                icon={
                                                    <Icon fontSize="small" sx={{ mt: -0.25 }}>
                                                        home
                                                    </Icon>
                                                }
                                            />
                                            <Tab
                                                label="Message"
                                                icon={
                                                    <Icon fontSize="small" sx={{ mt: -0.25 }}>
                                                        email
                                                    </Icon>
                                                }
                                            />
                                            <Tab
                                                label="Settings"
                                                icon={
                                                    <Icon fontSize="small" sx={{ mt: -0.25 }}>
                                                        settings
                                                    </Icon>
                                                }
                                            />
                                        </Tabs>
                                    </AppBar>
                                </Grid> */}
                                </Grid>
                                <Box p={2}>
                                    {/* <Box mb={2} lineHeight={1}>
                                        <Typography variant="button" color="text" fontWeight="light">
                                            Poorvika Asset Manager.managing poorvika assets and add advertiments.
                                        </Typography>
                                    </Box> */}
                                    <Box opacity={0.3}>
                                        <Divider />
                                    </Box>
                                    <Box>
                                        {renderItems}
                                        {/* <Box display="flex" py={1} pr={2}>
                                            <Typography variant="button" fontWeight="bold" textTransform="capitalize">
                                                Social: &nbsp;
                                            </Typography>
                                            {renderSocial}
                                        </Box> */}
                                    </Box>
                                </Box>
                            </Box>
                        </Card>
                        {/* <Divider orientation="vertical" sx={{ mx: 0 }} /> */}
                    </Grid>
                    <Grid item xs={12} md={6} xl={4}>
                        <Card sx={{ height: '100%', boxShadow: 'none', backgroundColor: 'white' }}>
                            <Box pt={2} px={2}>
                                <Typography variant="h6" fontWeight="medium" textTransform="capitalize">
                                    IT Connect
                                </Typography>
                            </Box>
                            <Divider />
                            <Box p={2}>
                                <Box component="ul" display="flex" flexDirection="column" p={0} m={0}>
                                    {userlistdata.map((item) => (
                                        <Box key={item.id} component="li" display="flex" alignItems="center" py={1} mb={1}>
                                            <Box mr={2}>
                                                <Avatar src="" alt="M" sx={{ backgroundColor: 'white' }} />
                                            </Box>
                                            <Box display="flex" flexDirection="column" alignItems="flex-start" justifyContent="center">
                                                <Typography variant="button" fontWeight="medium">
                                                    {item.username}
                                                </Typography>
                                                <Typography variant="caption" color="text">
                                                    {item.email}
                                                </Typography>
                                            </Box>
                                            {/* <Box ml="auto">
                                            {action.type === 'internal' ? (
                                                <Typography component="a" href="" variant="text" color="info">
                                                    {action.label}
                                                </Typography>
                                            ) : (
                                                <Typography
                                                    component="a"
                                                    href=""
                                                    target="_blank"
                                                    rel="noreferrer"
                                                    variant="text"
                                                    color={action.color}
                                                >
                                                    {action.label}
                                                </Typography>
                                            )}
                                        </Box> */}
                                        </Box>
                                    ))}
                                </Box>
                            </Box>
                        </Card>
                    </Grid>
                </Grid>
            </Box>
        </>
    );
}

export default App;
