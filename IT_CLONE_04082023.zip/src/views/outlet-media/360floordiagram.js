// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import {
    Box,
    Button,
    Card,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    TextField,
    Typography,
    useMediaQuery,
    useTheme
} from '@mui/material';
import Avatar from '@mui/material/Avatar';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Modal from '@mui/material/Modal';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { isWebUri } from 'valid-url';

import ApiComponent from '../apicomp/ApiComponent';
import { DegreeImageapi, Showroomapi } from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';
import style from '../styles/Boxstyle';
import useStyles from '../styles/styles';
import Table from './360floordiatable';

import AddIcon from '@mui/icons-material/Add';
import { Fab } from '@mui/material';

// ==============================|| SAMPLE PAGE ||============================== //

const SamplePage = () => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    const [location, setLocation] = useState('');
    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    function getPhoto(event) {
        setPhoto(URL.createObjectURL(event.target.files[0]));
        setPhoto1(event.target.files[0]);
    }
    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };
    const [showroomnames, setShowroomnames] = React.useState([]);
    // React.useEffect(() => {
    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {}).then(
    //         (response) => {
    //             // console.log("edition",response.data);
    //             //const districts = response.data;
    //             setShowroomnames(response.data);
    //             console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    // React.useEffect(() => {
    //     const token = localStorage.getItem('token'); // Retrieve the token from localStorage

    //     Axios.get('http://localhost:1212/api/v1/OMM2/showroom_mgmt', {
    //         headers: {
    //             Authorization: `Token ${token}` // Include the token in the request headers
    //         }
    //     }).then(
    //         (response) => {
    //             setShowroomnames(response.data);
    //             //console.log('edition', response.data);
    //         },
    //         (error) => {
    //             console.log(error);
    //         }
    //     );
    // }, []);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setShowroomnames(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts
            setShowroomnames([]);
        };
    }, []);

    //const [location, setLocation] = useState('');

    const [name, setName] = useState('');
    const [url, setURL] = useState('');
    const [grade, setGrade] = useState('');
    const [urlError, setUrlError] = useState(false);
    //const [responseMessage, setResponseMessage] = useState('');
    const handleChange = (event) => {
        setURL(event.target.value);

        // Regex pattern to validate URL
        // const regex = `/^(ftp|http|https):\/\/[^ "]+$/`;
        if (event.target.value && !isWebUri(event.target.value)) {
            setUrlError(true);
        } else {
            setUrlError(false);
        }
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token'); // Retrieve the token from localStorage
        const userID = localStorage.getItem('id'); // Retrieve the id from localStorage

        Axios.post(
            DegreeImageapi,
            {
                name: location,
                url: url,
                grade: grade,
                created_by: userID,
                modified_by: userID
            },
            {
                headers: {
                    Authorization: `Token ${token}` // Include the token in the request headers
                }
            }
        ).then(
            (response) => {
                setResponseMessage('SuccesssFully 360 Floordiagarm Created');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
                console.log(response);
                //console.log(response);
                // handle success response
            },
            (error) => {
                console.log(error);
                // handle error response
            }
        );
    };
    // const handleSubmit = (e) => {
    //     e.preventDefault();
    //     Axios.post('http://localhost:1212/api/v1/OMM2/degreeimage_mgnt ', {
    //         // id: id,
    //         name: location,
    //         url: url,
    //         grade: grade
    //     }).then(
    //         (response) => {
    //             // enqueueSnackbar('Data Entry Successful', {
    //             //     variant: 'success',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(response);
    //             // history.push('/dashboard/bomat_table2');
    //             // setTimeout(() => {
    //             //     window.location.reload();
    //             // }, 1000);
    //         },
    //         (error) => {
    //             // enqueueSnackbar('Check Data and Try Again', {
    //             //     variant: 'Error',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(error);
    //         }
    //     );
    // };
    return (
        // <MainCard title="360 Degree Floor Diagram">
        <div>
            <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}
            {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        onClick={handleOpen}
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        360 Floor Diagram
                    </Button>
                </Stack> */}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    360 Floor Diagram
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>

                    {isMobile ? (
                        <Fab color="primary" aria-label="add" size="medium" className={classes.fabbutton} onClick={handleOpen}>
                            <AddIcon sx={{ color: 'white' }} />
                        </Fab>
                    ) : (
                        <Button
                            className={classes.Button}
                            variant="contained"
                            //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                            // //onClick={handleOpen}
                            // href="/hoardingform"
                            onClick={handleOpen}
                            startIcon={<AddCircleOutlinedIcon />}
                        >
                            360 Floor Diagram
                        </Button>
                    )}
                </Stack>
            </Card>
            <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                <Box sx={style}>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <List sx={{ width: '100%', maxWidth: 360 }}>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar className={classes.Button} sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                        F
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    <Typography variant="h3">Add 360 Floor Diagram</Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="location-select-label">
                                    Showroom Location
                                </InputLabel>
                                <Select
                                    labelid="location-select-label"
                                    id="name"
                                    value={location}
                                    onChange={(e) => setLocation(e.target.value)}
                                    label="Showroom Location"
                                    // InputLabelProps={{
                                    //     shrink: true,
                                    //     classes: {
                                    //         //root: classes.label,
                                    //         focused: classes.label
                                    //     }
                                    // }}
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                    focused="true"
                                >
                                    <MenuItem value="">
                                        <em>Select a location</em>
                                    </MenuItem>
                                    {showroomnames && showroomnames !== undefined
                                        ? showroomnames.map((option, index) => (
                                              <MenuItem key={index} value={option.id}>
                                                  {option.name}
                                              </MenuItem>
                                          ))
                                        : 'No Data'}
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="URL"
                                id="url"
                                value={url}
                                //onChange={(e) => setURL(e.target.value)}
                                fullWidth
                                type="url"
                                variant="outlined"
                                onChange={handleChange}
                                error={urlError}
                                helperText={urlError ? 'Invalid URL' : ''}
                                className={classes.input}
                                InputLabelProps={{
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="grade-select-label">
                                    Grade
                                </InputLabel>
                                <Select
                                    labelid="grade-select-label"
                                    id="grade"
                                    value={grade}
                                    onChange={(e) => setGrade(e.target.value)}
                                    label="Grade"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="">
                                        <em>Select a Grade</em>
                                    </MenuItem>
                                    <MenuItem value="A">A</MenuItem>
                                    <MenuItem value="A+">A+</MenuItem>
                                    <MenuItem value="B">B</MenuItem>
                                    <MenuItem value="C">C</MenuItem>
                                    <MenuItem value="D">D</MenuItem>
                                    <MenuItem value="E">E</MenuItem>
                                    <MenuItem value="F">F</MenuItem>
                                    <MenuItem value="G">G</MenuItem>
                                    <MenuItem value="H">H</MenuItem>
                                    <MenuItem value="I">I</MenuItem>
                                    <MenuItem value="K">K</MenuItem>
                                    {/* <MenuItem value="C">C</MenuItem> */}
                                </Select>
                            </FormControl>
                        </Grid>

                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                                    onClick={handleSubmit}
                                    startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Add
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Modal>
            <br></br>
            <Table />
        </div>

        // </MainCard>
    );
};

export default withAuth(SamplePage);
