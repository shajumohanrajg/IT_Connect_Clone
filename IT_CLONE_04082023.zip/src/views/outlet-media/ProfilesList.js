import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardHeader from '@mui/material/CardHeader';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

function ProfilesList({ title, profiles, shadow }) {
    const renderProfiles = profiles.map(({ image, name, description, action }) => (
        <ListItem key={name} alignItems="center" disableGutters>
            <ListItemAvatar>
                <Avatar src={image} alt="something here" />
            </ListItemAvatar>
            <ListItemText
                primary={name}
                secondary={description}
                primaryTypographyProps={{ variant: 'button', fontWeight: 'medium' }}
                secondaryTypographyProps={{ variant: 'caption', color: 'text' }}
            />
            <Button
                component={action.type === 'internal' ? Link : 'a'}
                to={action.route}
                href={action.route}
                target={action.type === 'internal' ? undefined : '_blank'}
                rel={action.type === 'internal' ? undefined : 'noreferrer'}
                variant="text"
                color={action.type === 'internal' ? 'info' : action.color}
            >
                {action.label}
            </Button>
        </ListItem>
    ));

    return (
        <Card sx={{ height: '100%', boxShadow: !shadow && 'none' }}>
            <CardHeader
                title={
                    <Typography variant="h6" fontWeight="medium" textTransform="capitalize">
                        {title}
                    </Typography>
                }
            />
            <CardContent>
                <List sx={{ p: 0 }}>{renderProfiles}</List>
            </CardContent>
        </Card>
    );
}

ProfilesList.defaultProps = {
    shadow: true
};

ProfilesList.propTypes = {
    title: PropTypes.string.isRequired,
    profiles: PropTypes.arrayOf(
        PropTypes.shape({
            image: PropTypes.string.isRequired,
            name: PropTypes.string.isRequired,
            description: PropTypes.string.isRequired,
            action: PropTypes.shape({
                type: PropTypes.oneOf(['internal', 'external']).isRequired,
                route: PropTypes.string.isRequired,
                label: PropTypes.string.isRequired,
                color: PropTypes.string
            }).isRequired
        })
    ).isRequired,
    shadow: PropTypes.bool
};

export default ProfilesList;
