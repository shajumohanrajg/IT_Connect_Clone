//import { Typography } from 'tabler-icons-react';
//import CloseIcon from '@mui/icons-material/Close';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
import TripOriginTwoToneIcon from '@mui/icons-material/TripOriginTwoTone';
import { Box, Card, Link, Stack, Typography, useMediaQuery, useTheme } from '@mui/material';
// material-ui

//import React, { FormControl, Grid, InputAdornment, InputLabel, MenuItem, Select, TextField } from 'react';
//import { makeStyles } from '@mui/styles';
import {
    Fab,
    // Typography,
    Grid
} from '@mui/material';
import Avatar from '@mui/material/Avatar';
//import Avatar from '@mui/material/Avatar';
import AddIcon from '@mui/icons-material/Add';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
// import ListItemText from '@mui/material/ListItemText';
//import Pagination from '@mui/material/Pagination';
import { makeStyles } from '@mui/styles';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import Branding1 from '../../../src/assets/images/branding1.png';
import Branding2 from '../../../src/assets/images/branding2.png';
import ApiComponent from '../apicomp/ApiComponent';
import {
    AddAdvertisementFormapi,
    Brandapi,
    OutletMediaFormapi,
    OutletMediaListapi,
    Showroomapi,
    Statusapi,
    Vendorapi
} from '../apicomp/Apiurls';
import withAuth from '../pages/authentication/authentication3/withAuth';

//import useStyles from '../styles/styles';

//import { useNavigate } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
    tableContainer: {
        marginTop: theme.spacing(2),
        [theme.breakpoints.down('sm')]: {
            marginTop: theme.spacing(1)
        }
    },
    searchField: {
        marginBottom: theme.spacing(2),
        [theme.breakpoints.down('sm')]: {
            marginBottom: theme.spacing(1)
        }
    },
    pagination: {
        marginTop: theme.spacing(2),
        display: 'flex',
        justifyContent: 'center'
    },
    cardst: {
        // width: 200,
        // height: 200,
        // background: 'lightblue',
        borderRadius: 10,
        boxShadow: '2px 2px 5px rgba(0, 0, 0, 0.2)',
        transition: 'transform 0.3s ease-in-out',
        '&:hover': {
            transform: 'scale(0.9)'
        }
    },
    fabbutton: {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        zIndex: 999
    }
}));
function DataTable() {
    // const classes = useStyles();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const navigate = useNavigate();
    const [nestopen, setnestOpen] = useState(false);
    // const theme = useTheme();
    //const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    const handlenestOpen = () => {
        setnestOpen(true);
    };

    const handlenestClose = () => {
        setnestOpen(false);
    };

    const columns1 = [
        {
            field: 'name',
            headerName: 'Showroom',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 100 : 120
        },
        {
            field: 'branding_type',
            headerName: 'Total',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'branding_location',
            headerName: 'Active',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'brand',
            headerName: 'Expired',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        },
        {
            field: 'brandi',
            headerName: 'Empty',
            // valueFormatter: ({ value }) => "PO" + value,
            // cellClassName: "name-column--cell",
            //flex: 0.2
            width: isMobile ? 80 : 120
        }
    ];

    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };
    const handleConfirmSubmit = () => {
        // Perform the API request and update logic here
        handleOpenDialog();
    };

    const [openDialogdelete, setOpenDialogdelete] = useState(false);
    const [selectedRowIddel, setSelectedRowIddel] = React.useState(null);
    const handleDeleteSubmit = (id) => {
        //e.preventDefault();
        //setSelectedRowIddel(id);
        // Open the confirmation dialog
        handleOpenDialogdelete(id);
    };

    // const handleOpenDialogdelete = () => {
    //     setOpenDialogdelete(true);
    // };

    const handleOpenDialogdelete = (id) => {
        setSelectedRowIddel(id);
        setOpenDialogdelete(true);
    };

    const handleCloseDialogdelete = () => {
        setOpenDialogdelete(false);
    };
    const handleConfirmDelete = () => {
        // Perform the API request and update logic here
        //handleOpenDialogdelete();
        setOpenDialogdelete(true);
    };

    const deleteBrand = () => {
        const token = localStorage.getItem('token');
        //setLoading(true);
        Axios.delete(`${OutletMediaFormapi}${selectedRowIddel}`, {
            headers: {
                Authorization: `Token ${token}` // Include the token in the request headers
            }
        })
            .then(() => {
                handleCloseDialogdelete();
                setResponseMessage('SuccesssFully Light Type Deleted');
                //navigate('/brand');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            })
            .catch((err) => {
                //setLoading(true);
                console.log(err);
            });
    };

    const rowClassName = (params) => {
        return {
            backgroundColor: params.rowIndex % 2 === 0 ? '#f5f5f5' : 'inherit'
        };
    };
    const [showroomnames, setShowroomnames] = React.useState([]);
    const [showroomlocation, setShowroomlocation] = React.useState('');
    const [classname, setClassname] = useState('');
    const [classvalue, setClassvalue] = useState('');
    const [width, setWidth] = useState('');
    const [height, setHeight] = useState('');
    const [modelname, setModelname] = useState('');
    const [brandname, setBrandname] = useState('');
    const [brandvalue, setBrandvalue] = useState('');
    const [brandtype, setBrandtype] = useState('');
    const [brandtypevalue, setBrandtypevalue] = useState('');
    const [vendor, setVendor] = useState('');
    const [vendorvalue, setVendorvalue] = useState('');
    const [brandlocation, setBrandlocation] = useState('');
    const [brandlocationvalue, setBrandlocationvalue] = useState('');
    const [lighttype, setLighttype] = useState('');
    const [lighttypevalue, setLighttypevalue] = useState('');
    const [material, setMaterial] = useState('');
    const [materialvalue, setMaterialvalue] = useState('');
    const [expirevalue, setExpirevalue] = useState('');
    const [image, setImage] = useState([]);
    const [status, setStatus] = useState('');
    const [comments, setComments] = useState('');

    const handleImageChange = (event) => {
        setImage(event.target.files[0]);
    };

    const handleSubmit = async (e) => {
        const token = localStorage.getItem('token');
        const userID = localStorage.getItem('id');
        e.preventDefault();

        const formData = new FormData();
        //formData.append('name', classvalue);
        formData.append('outlet_media', selectedRowId);
        formData.append('asset_image', image);

        formData.append('ad_status', status);
        formData.append('comment', comments);
        formData.append('model_product_name', modelname);

        formData.append('brand', brandvalue);

        formData.append('vendor', vendorvalue);
        formData.append('expiry_on', expirevalue);
        formData.append('created_by', userID);
        formData.append('modified_by', userID);

        try {
            const response = await Axios.post(AddAdvertisementFormapi, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    Authorization: `Token ${token}`
                }
            });
            console.log(response.data);
            setResponseMessage('SuccesssFully Brand Type Created');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            //console.log(response);
        } catch (error) {
            console.error(error);
        }
    };

    const [selectedRowId, setSelectedRowId] = React.useState(null);
    const handleEditClick = (id) => {
        const token = localStorage.getItem('token');
        setSelectedRowId(id);

        Axios.get(`${OutletMediaFormapi}${id}`, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}` // Include the token in the request headers,
            }
        })
            .then((response) => {
                const data = response.data;
                // Update your state or perform any necessary actions with the fetched data
                // For example, you can set the fetched data to a state variable
                //setMatData(data);
                setnestOpen(true);
                //console.log(data);
            })
            .catch((error) => {
                console.log('Error fetching data:', error);
            });
    };
    const [selectedImage, setSelectedImage] = React.useState(null);
    const [modalOpen, setModalOpen] = React.useState(false);

    const handleImageClick = (imageUrl) => {
        setSelectedImage(imageUrl);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setSelectedImage(null);
        setModalOpen(false);
    };

    const viewShowrooms = (id) => {
        // console.log(id)
        navigate(`/outletupdate/${id}`);
        window.location.reload();
    };

    const handleImageKeyDown = (event, imageUrl) => {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            handleImageClick(imageUrl);
        }
    };

    //const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    //const [loading, setLoading] = React.useState(false);
    const [hoarding, setHoarding] = React.useState([]);

    useEffect(() => {
        const handleDataFetched = (data) => {
            setBrandname(data);
            setShowroomnames(data);
            setVendor(data);
            setStatus(data);
            setHoarding(data);
        };

        // Clean up the effect when the component unmounts
        return () => {
            // Reset the floordiadata when the component unmounts

            setStatus([]);
            setShowroomnames([]);
            setBrandname([]);
            setVendor([]);
            setHoarding([]);
        };
    }, []);

    React.useEffect(() => {
        const token = localStorage.getItem('token');
        Axios.get(OutletMediaListapi, {
            headers: {
                'Content-Type': 'multipart/form-data',
                Authorization: `Token ${token}`
            }
        }).then(
            (response) => {
                // console.log("edition",response.data);
                //const districts = response.data;
                setHoarding(response.data);
                console.log('edition', response.data);
            },
            (error) => {
                console.log(error);
            }
        );
    }, []);

    // const [searchQuery, setSearchQuery] = useState('');
    // const [filteredShowrooms, setFilteredShowrooms] = useState(showroomnames);

    // const handleSearchInputChange = (event) => {
    //     const query = event.target.value;
    //     setSearchQuery(query);

    //     const filteredResults = showroomnames.filter((item) => item.name.toLowerCase().includes(query.toLowerCase()));
    //     setFilteredShowrooms(filteredResults);
    // };

    // If no search query, display all data
    //const showroomsToDisplay = searchQuery ? filteredShowrooms : showroomnames;

    const itemsPerPage = 12;
    const [currentPage, setCurrentPage] = useState(1);
    const [searchQuery, setSearchQuery] = useState('');
    const [showGrid, setShowGrid] = useState(true);

    const handleSearchInputChange = (event) => {
        const query = event.target.value;
        setSearchQuery(query);
        setCurrentPage(1);
    };

    const handlePageChange = (event, page) => {
        setCurrentPage(page);
    };

    // Filter showrooms based on search query
    const filteredShowrooms = showroomnames.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()));

    const totalItems = filteredShowrooms.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const showroomsToDisplay = filteredShowrooms.slice(startIndex, endIndex);

    const handleToggleDisplay = () => {
        setShowGrid((prevShowGrid) => !prevShowGrid);
    };

    const Assetstatus = [
        {
            id: 1,
            title: 'Wall Branding 2',
            assetid: '11795',
            status: 'Expired',
            location: 'Entry Left',
            material: 'Vinyl With Sunboard',
            brand: 'Vivo',
            model: 'V27/Y100',
            img: Branding2,
            icon: <TripOriginTwoToneIcon sx={{ color: 'red' }} fontSize="medium" />
        },
        {
            id: 2,
            title: 'Name Board',
            assetid: '11786',
            status: 'Active',
            location: 'Outide Entrance',
            material: 'LED -Mono',
            brand: 'Vivo',
            model: 'Poorvika',
            img: Branding1,
            icon: <TripOriginTwoToneIcon sx={{ color: 'green' }} fontSize="medium" />
        },
        {
            id: 3,
            title: 'Wall Branding 2',
            assetid: '11795',
            status: 'Expired',
            location: 'Entry Left',
            material: 'Vinyl With Sunboard',
            brand: 'Vivo',
            model: 'V27/Y100',
            img: Branding2,
            icon: <TripOriginTwoToneIcon sx={{ color: 'red' }} fontSize="medium" />
        },
        {
            id: 4,
            title: 'Name Board',
            assetid: '11786',
            status: 'Active',
            location: 'Outide Entrance',
            material: 'LED -Mono',
            brand: 'Vivo',
            model: 'Poorvika',
            img: Branding1,
            icon: <TripOriginTwoToneIcon sx={{ color: 'green' }} fontSize="medium" />
        }
    ];
    const isSmallScreen = useMediaQuery('(max-width:600px)');
    return (
        <>
            {' '}
            {/* <Fab color="primary" aria-label="add" size="medium" className={classes.fabbutton} href="/addad">
                <AddIcon sx={{ color: 'white' }} />
            </Fab> */}
            <Box sx={{ m: isMobile ? -2 : 0 }}>
                {responseMessage &&
                    Swal.fire({
                        title: 'success',
                        text: responseMessage,
                        icon: 'success',
                        confirmButtonText: 'OK'
                        //onClose: handleClose
                    })}
                <ApiComponent apiUrl={OutletMediaListapi} onDataFetched={setHoarding} />
                <ApiComponent apiUrl={Brandapi} onDataFetched={setBrandname} />
                <ApiComponent apiUrl={Showroomapi} onDataFetched={setShowroomnames} />
                <ApiComponent apiUrl={Statusapi} onDataFetched={setStatus} />
                <ApiComponent apiUrl={Vendorapi} onDataFetched={setVendor} />{' '}
                <Card sx={{ width: '100%', boxShadow: 0 }}>
                    <Stack
                        direction={{ xs: 'column', sm: 'row' }}
                        // justifyContent="space-between"
                        // alignItems="center"
                        justifyContent="space-between"
                        alignItems="center"
                        spacing={2}
                        sx={{ padding: 1 }}
                    >
                        <List>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                        <StoreOutlinedIcon sx={{ color: 'white' }} />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    {' '}
                                    <Typography variant="h3" sx={{ color: '#444444', fontSize: isMobile ? 20 : 22 }}>
                                        Marketing Asset Status
                                    </Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        {isMobile ? (
                            <Fab color="primary" aria-label="add" size="medium" className={classes.fabbutton} href="/addad">
                                <AddIcon sx={{ color: 'white' }} />
                            </Fab>
                        ) : (
                            ''
                        )}
                        {/* <Box sx={{ '& button': { m: 1 } }}>
                            <div>
                                <Button variant="outlined" size="medium">
                                    Total - 4
                                </Button>
                                <Button variant="outlined" size="medium" sx={{ color: 'green', borderColor: 'green' }}>
                                    Active - 2
                                </Button>
                                <Button variant="outlined" size="medium" color="error">
                                    Expired - 1
                                </Button>
                                <Button variant="outlined" size="medium" color="info">
                                    Empty - 1
                                </Button>
                            </div>
                        </Box> */}
                        {/* <TextField
                           
                            value={searchQuery}
                            onChange={handleSearchInputChange}
                            placeholder="Search Store name.."
                            id="outlined-search"
                            label="Search"
                            type="search"
                            InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <SearchIcon />
                                    </InputAdornment>
                                )
                            }}
                        /> */}
                        {/* <IconButton onClick={handleToggleDisplay}>{showGrid ? <TableChartIcon /> : <ViewModuleIcon />}</IconButton> */}
                        {/* <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        // //onClick={handleOpen}
                        // href="/hoardingform"
                        onClick={handleOpen}
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Brand
                    </Button> */}
                    </Stack>
                </Card>
                <br></br>
                <Grid container spacing={2} sx={{ p: 0 }}>
                    {Assetstatus.map((item) => (
                        <Grid item sm={6} xs={12} md={6} lg={4} sx={{ p: 0 }} key={item.id}>
                            <Link href="/assetindstatus" underline="none" sx={{ textTransform: 'none' }}>
                                <Card sx={{ width: '100%', my: 0, border: '1px solid #ebebeb' }} className={classes.cardst}>
                                    <List>
                                        <ListItem>
                                            <ListItemText>
                                                {' '}
                                                <Typography variant="h5" sx={{ color: '#ff8b3d', fontWeight: 'bold' }}>
                                                    {item.title} <span style={{ color: 'gray' }}>({item.assetid})</span>
                                                </Typography>
                                                {/* <Typography
                                                    variant="caption"
                                                    sx={{ fontWeight: 'bold', display: 'flex', alignItems: 'center' }}
                                                    startIcon={item.icon}
                                                >
                                                    Expired
                                                </Typography> */}
                                                {/* <Typography variant="caption" sx={{ fontWeight: 'bold' }}>
                                                    <span>{item.icon}</span> Expired
                                                </Typography> */}
                                            </ListItemText>
                                        </ListItem>
                                    </List>
                                    <Card sx={{ boxShadow: 0, p: 0, borderTop: '1px solid #ebebeb' }}>
                                        <Grid container spacing={1} sx={{ p: 1 }}>
                                            <Grid
                                                item
                                                sm={5}
                                                xs={6}
                                                md={5}
                                                sx={{ p: 0 }}
                                                // display="flex"
                                                justifyContent="center"
                                                alignItems="center"
                                            >
                                                <Grid container direction="column" alignItems="center" spacing={1}>
                                                    <Grid item xs={12}>
                                                        <img
                                                            src={item.img}
                                                            alt="Yosfge"
                                                            style={{
                                                                width: '100%',
                                                                height: '110px',
                                                                border: '1px dashed #ebebeb'
                                                                //boxShadow: 3
                                                            }}
                                                        />
                                                    </Grid>
                                                    <Grid item xs={12}>
                                                        <Typography variant="subtitle2" align="center" style={{ color: 'gray' }}>
                                                            160" x 92"
                                                        </Typography>
                                                    </Grid>
                                                    <Grid item xs={12}>
                                                        <Divider>
                                                            <Box sx={{ border: '1px solid #ebebeb', p: 1, borderRadius: 3 }}>
                                                                <ListItem disablePadding align="center" color="primary">
                                                                    <ListItemIcon>{item.icon}</ListItemIcon>
                                                                    <ListItemText
                                                                        primary={
                                                                            <Typography variant="subtitle2" fontWeight="bold">
                                                                                {item.status}
                                                                            </Typography>
                                                                        }
                                                                        sx={{ fontWeight: 'bold' }}
                                                                    />
                                                                </ListItem>
                                                            </Box>
                                                        </Divider>
                                                    </Grid>
                                                </Grid>
                                                {/* <TripOriginTwoToneIcon sx={{ color: 'green' }} fontSize="medium" /> */}
                                            </Grid>
                                            <Grid item sm={7} xs={6} md={6}>
                                                <Grid container spacing={0}>
                                                    {/* <Grid item sm={12} xs={12} md={12}>
                                                        <ListItemText
                                                            primary="Location"
                                                            primaryTypographyProps={{
                                                                variant: 'subtitle1',
                                                                noWrap: true,
                                                                fontWeight: 'medium'
                                                            }}
                                                            secondary={item.location}
                                                            secondaryTypographyProps={{
                                                                variant: 'subtitle2',
                                                                noWrap: true
                                                            }}
                                                        />

                                                        <ListItemText
                                                            primary={<Typography variant="subtitle1">Location</Typography>}
                                                            secondary={<Typography variant="subtitle2">{item.location}</Typography>}
                                                        />
                                                    </Grid>
                                                    <Grid item sm={12} xs={12} md={12}>
                                                        <ListItemText
                                                            primary={<Typography variant="subtitle1">Material</Typography>}
                                                            secondary={<Typography variant="subtitle2">{item.material}</Typography>}
                                                        />
                                                    </Grid>
                                                    <Grid item sm={12} xs={12} md={12}>
                                                        <ListItemText
                                                            primary={<Typography variant="subtitle1">Brand</Typography>}
                                                            secondary={<Typography variant="subtitle2">{item.brand}</Typography>}
                                                        />
                                                    </Grid> */}

                                                    {/* <Grid item sm={12} xs={12} md={12}>
                                                        <ListItemText
                                                            primary={<Typography variant="subtitle1">Model</Typography>}
                                                            secondary={<Typography variant="subtitle2">{item.model}</Typography>}
                                                        />
                                                    </Grid> */}
                                                    <Grid item sm={12} xs={12} md={12}>
                                                        {/* <ListItem
                                                            secondaryAction={
                                                                <IconButton edge="end" aria-label="delete">
                                                                    <DeleteIcon />
                                                                </IconButton>
                                                            }
                                                            disableGutters
                                                        > */}
                                                        <ListItemText
                                                            primary="Location"
                                                            secondary={item.location}
                                                            primaryTypographyProps={{ variant: 'h5' }}
                                                            secondaryTypographyProps={{ variant: 'h6' }}
                                                        />
                                                        {/* </ListItem> */}
                                                    </Grid>
                                                    <Grid item sm={12} xs={12} md={12} justifyContent="">
                                                        <ListItemText
                                                            primary="Material"
                                                            secondary={item.material}
                                                            primaryTypographyProps={{ variant: 'h5' }}
                                                            secondaryTypographyProps={{ variant: 'h6' }}
                                                            //sx={{ backgroundColor: 'primary' }}
                                                        />
                                                    </Grid>
                                                    <Grid item sm={12} xs={12} md={12}>
                                                        <ListItemText
                                                            primary="Brand"
                                                            secondary={item.brand}
                                                            primaryTypographyProps={{ variant: 'h5' }}
                                                            secondaryTypographyProps={{ variant: 'h6' }}
                                                        />
                                                    </Grid>
                                                    <Grid item sm={12} xs={12} md={12}>
                                                        <ListItemText
                                                            primary="Model"
                                                            secondary={item.model}
                                                            primaryTypographyProps={{ variant: 'h5' }}
                                                            secondaryTypographyProps={{ variant: 'h6' }}
                                                        />
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </Card>
                                </Card>
                            </Link>
                        </Grid>
                    ))}
                </Grid>
            </Box>
        </>
    );
}

export default withAuth(DataTable);
