import { Typography } from '@material-ui/core';
// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import { Button, Card, FormControl, Grid, InputLabel, MenuItem, Select, Stack, TextField } from '@mui/material';
import Modal from '@mui/material/Modal';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';

import withAuth from '../pages/authentication/authentication3/withAuth';
import { Brandapi } from '../apicomp/Apiurls';
import useStyles from '../styles/styles';
//import Table from './classtable';
// import FormBox from './FormBox';
// import CustomList from './headercard';
// import CustomCard from './HeaderCustomCard';
// import CustomForm from './headerform';

// ==============================|| SAMPLE PAGE ||============================== //

const SamplePage = () => {
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    const [location, setLocation] = useState('');

    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };
    const [name, setName] = useState('');
    const [status, setStatus] = useState('');

    const handleSubmit = (e) => {
        const token = localStorage.getItem('token');
        const userID = localStorage.getItem('id');
        e.preventDefault();
        Axios.post(
            'http://localhost:1212/api/v1/OMM2/class_mgmt/',
            {
                // id: id,
                name: name,
                status: status,
                created_by: userID,
                modified_by: userID
            },
            {
                headers: {
                    Authorization: `Token ${token}` // Include the token in the request headers
                }
            }
        ).then(
            (response) => {
                // enqueueSnackbar('Data Entry Successful', {
                //     variant: 'success',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(response);

                //navigate('/success');
                // history.push('/dashboard/bomat_table2');
                // setTimeout(() => {
                //     window.location.reload();
                // }, 1000);
            },
            (error) => {
                // enqueueSnackbar('Check Data and Try Again', {
                //     variant: 'Error',
                //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
                // });
                console.log(error);
            }
        );
    };
    return (
        <div>
            <CustomCard>
                <CustomList icon={<StoreOutlinedIcon />} text="Not Done..." iconColor="#ffffff" variant="h3" />
                {/* <Button className={classes.Button} variant="contained" onClick={handleOpen} startIcon={<AddCircleOutlinedIcon />}>
                    Class
                </Button> */}
            </CustomCard>

            <br></br>

            <Typography variant="h3">Need Data For This Module.</Typography>
        </div>
    );
};

export default withAuth(SamplePage);
