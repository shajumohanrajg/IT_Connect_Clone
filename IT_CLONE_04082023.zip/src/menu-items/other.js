import BrushOutlinedIcon from '@mui/icons-material/BrushOutlined';
import { IconBrandChrome, IconHelp } from '@tabler/icons';
// assets
import PermMediaOutlinedIcon from '@mui/icons-material/PermMediaOutlined';

import SecurityUpdateGoodOutlinedIcon from '@mui/icons-material/SecurityUpdateGoodOutlined';
const icons = { IconBrandChrome, IconHelp, BrushOutlinedIcon, PermMediaOutlinedIcon, SecurityUpdateGoodOutlinedIcon };

// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //

const other = {
    id: 'sample-docs-roadmap',
    type: 'group',
    children: [
        {
            id: 'hoarding',
            title: 'Hoarding',
            type: 'item',
            url: '/hoardinglist',
            icon: icons.BrushOutlinedIcon,
            breadcrumbs: false
        }
        // {
        //     id: 'media-research',
        //     title: 'Media Research',
        //     type: 'item',
        //     url: '/',
        //     icon: icons.PermMediaOutlinedIcon,
        //     external: true,
        //     target: true
        // }
        // {
        //     id: 'mobile-app',
        //     title: 'Mobile App',
        //     type: 'item',
        //     url: '/sample-page',
        //     icon: icons.SecurityUpdateGoodOutlinedIcon,
        //     breadcrumbs: false
        // }
    ]
};

export default other;
