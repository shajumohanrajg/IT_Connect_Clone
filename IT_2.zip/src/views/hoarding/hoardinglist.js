// project imports
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import { Button, Card, Stack, Typography } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
//import React from 'react';

import withAuth from '../pages/authentication/authentication3/withAuth';
import { Brandapi } from '../apicomp/Apiurls';
import useStyles from '../styles/styles';
import Hoardingtable1 from './hoardingtable';
import style from '../styles/Boxstyle';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';

// const useStyles = makeStyles((theme) => ({
//     root: {
//         width: '100%'
//     },
//     stepper: {
//         backgroundColor: 'transparent', // set your desired background color
//         // padding: "16px", // adjust the padding as needed
//         // borderRadius: "8px", // adjust the border radius as needed
//         [theme.breakpoints.down('sm')]: {
//             padding: theme.spacing(1)
//         }
//     },
//     Button: {
//         borderRadius: 8,
//         //backgroundColor: '#1a5f7a',
//         background: 'linear-gradient(to right bottom, #1a5f7a, #0b3442)',
//         color: 'white',
//         '&:hover': {
//             backgroundColor: '#1a5f7a',
//             color: 'white'
//             //boxShadow: 24
//         }
//     },
//     input: {
//         borderRadius: 50,
//         //padding: "0.75rem",
//         //height: "1.4375em",

//         animationDuration: '10ms',
//         '& .MuiOutlinedInput-root': {
//             '& fieldset': {
//                 //borderColor: "#ccc",
//                 borderRadius: 8,
//                 //borderColor: "black",
//                 //border: "2px dashed grey",
//                 //height: "1.4375em",
//                 //padding: "1rem",
//                 color: 'white'
//             },
//             '&:hover fieldset': {
//                 borderColor: '#999'
//             },
//             '&.Mui-focused fieldset': {
//                 borderColor: '#1a5f7a'
//             }
//         }
//     },
//     fw: {
//         fontWeight: 'bold'
//     },
//     label: {
//         //color: "red",
//         '&.Mui-focused': {
//             color: '#1a5f7a'
//         }
//     },
//     focusedLabel: {
//         color: '#1a5f7a'
//     },
//     select: {
//         size: 'small',
//         borderRadius: 10,
//         backgroundColor: '#fff',
//         '& .MuiOutlinedInput-root': {
//             '& fieldset': {
//                 //borderColor: "#ccc",
//                 borderRadius: 8,
//                 //borderColor: "black",
//                 //border: "2px solid grey",
//                 backgroundColor: '#fff'
//             },
//             '&:hover fieldset': {
//                 borderColor: '#999'
//             },
//             '&.Mui-focused fieldset': {
//                 borderColor: '#1a5f7a'
//             },
//             '&.Mui-focused': {
//                 color: '#1a5f7a'
//             }
//         },
//         '& .MuiSelect-icon': {
//             color: '#333'
//         }
//     },
//     select1: {
//         size: 'small',
//         borderRadius: 10,
//         backgroundColor: '#fff',
//         '& .MuiOutlinedInput-root': {
//             '& fieldset': {
//                 //borderColor: "#ccc",
//                 borderRadius: 8
//                 //borderColor: "black",
//                 //border: "2px solid grey",
//                 //backgroundColor: '#fff'
//             },
//             '&:hover fieldset': {
//                 borderColor: '#999'
//             },
//             '&.Mui-focused fieldset': {
//                 borderColor: '#1a5f7a'
//             },
//             '&.Mui-focused': {
//                 color: '#1a5f7a'
//             }
//         },
//         '& .MuiSelect-icon': {
//             color: '#333'
//         }
//     },
//     accordion: {
//         marginTop: theme.spacing(2)
//     },
//     formControl: {
//         minWidth: 200,
//         marginTop: theme.spacing(2)
//     }
// }));

const SamplePage = () => {
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    return (
        // <MainCard title="Hoarding">
        <div>
            {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                <Button
                    className={classes.Button}
                    variant="contained"
                    //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                    //onClick={handleOpen}
                    href="/hoardingform"
                    startIcon={<AddCircleOutlinedIcon />}
                >
                    Hoarding
                </Button>
            </Stack> */}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Hoarding Table
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        //onClick={handleOpen}
                        href="/hoardingform"
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Hoarding
                    </Button>
                </Stack>
            </Card>
            <br></br>
            <Hoardingtable1 />
        </div>
        // </MainCard>
    );
};

export default withAuth(SamplePage);
