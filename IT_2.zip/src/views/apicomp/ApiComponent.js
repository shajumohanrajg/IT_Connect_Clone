import Axios from 'axios';
import React, { useEffect } from 'react';

const ApiComponent = ({ apiUrl, onDataFetched }) => {
    useEffect(() => {
        const fetchData = async () => {
            try {
                const token = localStorage.getItem('token');
                const response = await Axios.get(apiUrl, {
                    headers: {
                        Authorization: `Token ${token}`
                    }
                });

                onDataFetched(response.data);
                console.log('TableData:', response.data);
            } catch (error) {
                console.log(error);
            }
        };

        fetchData();
    }, [apiUrl, onDataFetched]);

    // Render component content
    // ...
};

export default ApiComponent;
