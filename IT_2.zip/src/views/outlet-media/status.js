//import { makeStyles } from '@material-ui/core/styles';
// import { DropzoneArea } from 'material-ui-dropzone';
// import 'react-dropzone-uploader/dist/styles.css';

// project imports
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import AddCircleOutlinedIcon from '@mui/icons-material/AddCircleOutlined';
import StoreOutlinedIcon from '@mui/icons-material/StoreOutlined';
// material-ui

import { Box, Button, Card, FormControl, Grid, InputLabel, MenuItem, Select, Stack, TextField, Typography } from '@mui/material';
import Avatar from '@mui/material/Avatar';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import ListItemText from '@mui/material/ListItemText';
import Modal from '@mui/material/Modal';
import Axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Swal from 'sweetalert2';

import withAuth from '../pages/authentication/authentication3/withAuth';
import useStyles from '../styles/styles';
import { Brandapi } from '../apicomp/Apiurls';
import style from '../styles/Boxstyle';
import Table from './statustable';

// ==============================|| SAMPLE PAGE ||============================== //
// const useStyles = makeStyles((theme) => ({
//     formControl: {
//         margin: theme.spacing(1),
//         minWidth: 120
//     },
//     selectEmpty: {
//         marginTop: theme.spacing(2)
//     }
// }));

const SamplePage = () => {
    useEffect(() => {
        const token = localStorage.getItem('token');
        // Or retrieve token from Redux store or any other storage location

        // Perform authentication using the token
        if (token) {
            // Make API requests, validate the token, or perform any other necessary actions
            console.log('Token:', token);
        } else {
            // Redirect or display an error message if the token is not available
            console.error('Token not found');
            // Perform the necessary action, such as redirecting to the login page
        }
    }, []);
    const navigate = useNavigate();
    const classes = useStyles();
    const [loading, setLoading] = React.useState(false);
    const [responseMessage, setResponseMessage] = useState('');
    const [location, setLocation] = useState('');
    const [images, setImages] = useState([]);
    const [photo, setPhoto] = useState([]);
    const [photo1, setPhoto1] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    function getPhoto(event) {
        setPhoto(URL.createObjectURL(event.target.files[0]));
        setPhoto1(event.target.files[0]);
    }
    const handleLocationChange = (event) => {
        setLocation(event.target.value);
    };

    const handleImagesChange = (event) => {
        setImages(event.target.files);
    };

    const [name, setName] = useState('');
    const [status, setStatus] = useState('');
    const [visibility, setVisibility] = useState('');
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const token = localStorage.getItem('token');
            // or retrieve token from Redux store: const token = getState().token;

            // Construct the form data
            const formData = {
                name,
                status,
                visibility,
                created_by: 1,
                modified_by: 1
            };

            // Make the form submission with the authentication token and form data
            const response = await Axios.post('http://localhost:1212/api/v1/OMM2/status/', formData, {
                headers: {
                    Authorization: `Token ${token}`
                }
            });
            //console.log('Form submission successful:', token);
            // Handle the response as needed
            console.log('Form submission successful:', response.data);
            setResponseMessage('SuccesssFully Status Created');
            //navigate('/brand');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            console.log(response);
        } catch (error) {
            console.error('Form submission failed:', error);
        }
    };
    // const handleSubmit = (e) => {
    //     e.preventDefault();
    //     Axios.post('http://localhost:1212/api/v1/OMM2/status/', {
    //         // id: id,
    //         name: name,
    //         status: status,
    //         visibility: visibility
    //     }).then(
    //         (response) => {
    //             // enqueueSnackbar('Data Entry Successful', {
    //             //     variant: 'success',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(response);
    //             // history.push('/dashboard/bomat_table2');
    //             // setTimeout(() => {
    //             //     window.location.reload();
    //             // }, 1000);
    //         },
    //         (error) => {
    //             // enqueueSnackbar('Check Data and Try Again', {
    //             //     variant: 'Error',
    //             //     anchorOrigin: { horizontal: 'right', vertical: 'top' }
    //             // });
    //             console.log(error);
    //         }
    //     );
    // };
    return (
        // <MainCard title="Status">
        <div>
            {responseMessage &&
                Swal.fire({
                    title: 'success',
                    text: responseMessage,
                    icon: 'success',
                    confirmButtonText: 'OK'
                    //onClose: handleClose
                })}
            {/* <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        onClick={handleOpen}
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Status
                    </Button>
                </Stack> */}
            <Card sx={{ width: '100%', boxShadow: 0 }}>
                <Stack
                    direction={{ xs: 'column', sm: 'row' }}
                    justifyContent="space-between"
                    alignItems="center"
                    spacing={2}
                    sx={{ padding: 1 }}
                >
                    <List>
                        <ListItem>
                            <ListItemAvatar>
                                <Avatar sx={{ background: 'linear-gradient(to right bottom, #fb6340, #fbb140)' }}>
                                    <StoreOutlinedIcon sx={{ color: 'white' }} />
                                </Avatar>
                            </ListItemAvatar>
                            <ListItemText>
                                {' '}
                                <Typography variant="h3" sx={{ color: '#444444' }}>
                                    Status
                                </Typography>
                            </ListItemText>
                        </ListItem>
                    </List>
                    <Button
                        className={classes.Button}
                        variant="contained"
                        //sx={{ color: 'white', bgcolor: '#1a5f7a', fontWeight: 'bold' }}
                        // //onClick={handleOpen}
                        // href="/hoardingform"
                        onClick={handleOpen}
                        startIcon={<AddCircleOutlinedIcon />}
                    >
                        Status
                    </Button>
                </Stack>
            </Card>
            <Modal open={open} onClose={handleClose} aria-labelledby="modal-modal-title" aria-describedby="modal-modal-description">
                <Box sx={style}>
                    <Grid container spacing={2} justifyContent="center" alignItems="center">
                        <List sx={{ width: '100%', maxWidth: 360 }}>
                            <ListItem>
                                <ListItemAvatar>
                                    <Avatar className={classes.Button} sx={{ bgcolor: '#1a5f7a', color: 'white' }}>
                                        <AddAPhotoOutlinedIcon />
                                    </Avatar>
                                </ListItemAvatar>
                                <ListItemText>
                                    <Typography variant="h3">Create Status</Typography>
                                </ListItemText>
                            </ListItem>
                        </List>
                        <Grid item xs={12} md={12} xl={12}>
                            <TextField
                                //size="small"
                                label="Name"
                                id="name"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                fullWidth
                                //type="number"
                                variant="outlined"
                                className={classes.input}
                                InputLabelProps={{
                                    shrink: 'true',
                                    classes: {
                                        //root: classes.label,
                                        focused: classes.label
                                    }
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="status-select-label">
                                    Status
                                </InputLabel>
                                <Select
                                    labelId="status-select-label"
                                    id="status-select"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                    label="Status"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="" disabled>
                                        Select a Status
                                    </MenuItem>
                                    <MenuItem value="Active">Active</MenuItem>
                                    <MenuItem value="Inactive">Inactive</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        <Grid item xs={12} md={12} xl={12}>
                            <FormControl fullWidth className={classes.select}>
                                <InputLabel className={classes.label} id="visibility-select-label">
                                    Visibility
                                </InputLabel>
                                <Select
                                    labelId="visibility-select-label"
                                    id="visibility"
                                    value={visibility}
                                    onChange={(e) => setVisibility(e.target.value)}
                                    label="Visibility"
                                    //displayEmpty
                                    //className={classes.selectEmpty}
                                    //className={classes.select}
                                >
                                    <MenuItem value="" disabled>
                                        Select For Visibility
                                    </MenuItem>
                                    <MenuItem value="Vendor">Vendor</MenuItem>
                                    <MenuItem value="Assets">Assets</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>
                        {/* <Grid item xs={12} md={12} xl={12}>
                                <FormControl sx={{ m: 3 }} component="fieldset" variant="outlined" className={classes.select}>
                                    <FormLabel component="legend">Visibility</FormLabel>
                                    <FormGroup labelId="visibility-select-label">
                                        <FormControlLabel control={<Checkbox />} label="Assets" />
                                        <FormControlLabel control={<Checkbox />} label="Vendor" />
                                    </FormGroup>
                                </FormControl>
                            </Grid> */}
                        <Grid item xs={12} md={12} xl={12} sx={{ mt: 3 }}>
                            <Stack direction="row" justifyContent="flex-end" alignItems="flex-end">
                                {' '}
                                <Button
                                    className={classes.Button}
                                    variant="contained"
                                    onClick={handleSubmit}
                                    //startIcon={<FileUploadOutlinedIcon />}
                                >
                                    Create
                                </Button>
                            </Stack>
                        </Grid>
                    </Grid>
                </Box>
            </Modal>
            <br></br>
            <Table />
        </div>
    );
};

export default withAuth(SamplePage);
