import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';

const navigate = useNavigate();
const classes = useStyles();
const [loading, setLoading] = React.useState(false);
const [responseMessage, setResponseMessage] = useState('');

setResponseMessage('SuccesssFully Brand Created');
navigate('/brand');
setTimeout(() => {
    window.location.reload();
}, 1000);

{responseMessage &&
    Swal.fire({
        title: 'success',
        text: responseMessage,
        icon: 'success',
        confirmButtonText: 'OK'
        //onClose: handleClose
    })}